--
-- PostgreSQL database dump
--

\restrict aQ004uh0CFEh20WZO8iTuHBUUHFi08gwMv3ttIfjCBYDE1g3D6btShD0z4nBM6e

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: application_actions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.application_actions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    officer_id character varying NOT NULL,
    action character varying(50) NOT NULL,
    previous_status character varying(50),
    new_status character varying(50),
    feedback text,
    issues_found jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.application_actions OWNER TO postgres;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying,
    action character varying(100) NOT NULL,
    details jsonb,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: certificates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.certificates (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    certificate_number character varying(50) NOT NULL,
    certificate_type character varying(50) DEFAULT 'homestay_registration'::character varying,
    issued_date timestamp without time zone NOT NULL,
    valid_from timestamp without time zone NOT NULL,
    valid_upto timestamp without time zone NOT NULL,
    property_name character varying(255) NOT NULL,
    category character varying(20) NOT NULL,
    address text NOT NULL,
    district character varying(100) NOT NULL,
    owner_name character varying(255) NOT NULL,
    owner_mobile character varying(15) NOT NULL,
    certificate_pdf_url text,
    qr_code_data text,
    digital_signature text,
    issued_by character varying,
    status character varying(50) DEFAULT 'active'::character varying,
    revocation_reason text,
    revoked_by character varying,
    revoked_date timestamp without time zone,
    renewal_reminder_sent boolean DEFAULT false,
    renewal_application_id character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.certificates OWNER TO postgres;

--
-- Name: clarifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clarifications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    objection_id character varying NOT NULL,
    application_id character varying NOT NULL,
    submitted_by character varying NOT NULL,
    submitted_date timestamp without time zone NOT NULL,
    clarification_text text NOT NULL,
    supporting_documents jsonb,
    reviewed_by character varying,
    reviewed_date timestamp without time zone,
    review_status character varying(50),
    review_notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.clarifications OWNER TO postgres;

--
-- Name: ddo_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ddo_codes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    district character varying(100) NOT NULL,
    ddo_code character varying(20) NOT NULL,
    ddo_description text NOT NULL,
    treasury_code character varying(10) NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ddo_codes OWNER TO postgres;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.documents (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    document_type character varying(100) NOT NULL,
    file_name character varying(255) NOT NULL,
    file_path text NOT NULL,
    file_size integer NOT NULL,
    mime_type character varying(100) NOT NULL,
    upload_date timestamp without time zone DEFAULT now(),
    ai_verification_status character varying(50),
    ai_confidence_score numeric(5,2),
    ai_notes text,
    is_verified boolean DEFAULT false,
    verification_status character varying(50) DEFAULT 'pending'::character varying,
    verified_by character varying,
    verification_date timestamp without time zone,
    verification_notes text
);


ALTER TABLE public.documents OWNER TO postgres;

--
-- Name: himkosh_transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.himkosh_transactions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    dept_ref_no character varying(45) NOT NULL,
    app_ref_no character varying(20) NOT NULL,
    total_amount integer NOT NULL,
    tender_by character varying(70) NOT NULL,
    merchant_code character varying(15),
    dept_id character varying(10),
    service_code character varying(5),
    ddo character varying(12),
    head1 character varying(14),
    amount1 integer,
    head2 character varying(14),
    amount2 integer,
    head3 character varying(14),
    amount3 integer,
    head4 character varying(14),
    amount4 integer,
    head10 character varying(50),
    amount10 integer,
    period_from character varying(10),
    period_to character varying(10),
    encrypted_request text,
    request_checksum character varying(32),
    ech_txn_id character varying(10),
    bank_cin character varying(20),
    bank_name character varying(10),
    payment_date character varying(14),
    status character varying(70),
    status_cd character varying(1),
    response_checksum character varying(32),
    is_double_verified boolean DEFAULT false,
    double_verification_date timestamp without time zone,
    double_verification_data jsonb,
    challan_print_url text,
    portal_base_url text,
    transaction_status character varying(50) DEFAULT 'initiated'::character varying,
    initiated_at timestamp without time zone DEFAULT now(),
    responded_at timestamp without time zone,
    verified_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.himkosh_transactions OWNER TO postgres;

--
-- Name: homestay_applications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.homestay_applications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    application_number character varying(50) NOT NULL,
    application_kind character varying(30) DEFAULT 'new_registration'::character varying NOT NULL,
    parent_application_id character varying,
    parent_application_number character varying(50),
    parent_certificate_number character varying(50),
    inherited_certificate_valid_upto timestamp without time zone,
    service_context jsonb,
    service_notes text,
    service_requested_at timestamp without time zone,
    property_name character varying(255) NOT NULL,
    category character varying(20) NOT NULL,
    location_type character varying(10) NOT NULL,
    total_rooms integer NOT NULL,
    district character varying(100) NOT NULL,
    district_other character varying(100),
    tehsil character varying(100) NOT NULL,
    tehsil_other character varying(100),
    block character varying(100),
    block_other character varying(100),
    gram_panchayat character varying(100),
    gram_panchayat_other character varying(100),
    urban_body character varying(200),
    urban_body_other character varying(200),
    ward character varying(50),
    address text NOT NULL,
    pincode character varying(10) NOT NULL,
    telephone character varying(20),
    fax character varying(20),
    latitude numeric(10,8),
    longitude numeric(11,8),
    owner_name character varying(255) NOT NULL,
    owner_gender character varying(10) NOT NULL,
    owner_mobile character varying(15) NOT NULL,
    owner_email character varying(255),
    guardian_name character varying(255),
    owner_aadhaar character varying(12) NOT NULL,
    property_ownership character varying(10) DEFAULT 'owned'::character varying NOT NULL,
    proposed_room_rate numeric(10,2),
    project_type character varying(20) NOT NULL,
    property_area numeric(10,2) NOT NULL,
    single_bed_rooms integer DEFAULT 0,
    single_bed_beds integer DEFAULT 1,
    single_bed_room_size numeric(10,2),
    single_bed_room_rate numeric(10,2),
    double_bed_rooms integer DEFAULT 0,
    double_bed_beds integer DEFAULT 2,
    double_bed_room_size numeric(10,2),
    double_bed_room_rate numeric(10,2),
    family_suites integer DEFAULT 0,
    family_suite_beds integer DEFAULT 4,
    family_suite_size numeric(10,2),
    family_suite_rate numeric(10,2),
    attached_washrooms integer NOT NULL,
    gstin character varying(15),
    selected_category character varying(20),
    average_room_rate numeric(10,2),
    highest_room_rate numeric(10,2),
    lowest_room_rate numeric(10,2),
    certificate_validity_years integer DEFAULT 1,
    is_pangi_sub_division boolean DEFAULT false,
    distance_airport numeric(10,2),
    distance_railway numeric(10,2),
    distance_city_center numeric(10,2),
    distance_shopping numeric(10,2),
    distance_bus_stand numeric(10,2),
    lobby_area numeric(10,2),
    dining_area numeric(10,2),
    parking_area text,
    eco_friendly_facilities text,
    differently_abled_facilities text,
    fire_equipment_details text,
    nearest_hospital character varying(255),
    amenities jsonb,
    rooms jsonb,
    base_fee numeric(10,2),
    total_before_discounts numeric(10,2),
    validity_discount numeric(10,2) DEFAULT '0'::numeric,
    female_owner_discount numeric(10,2) DEFAULT '0'::numeric,
    pangi_discount numeric(10,2) DEFAULT '0'::numeric,
    total_discount numeric(10,2) DEFAULT '0'::numeric,
    total_fee numeric(10,2),
    per_room_fee numeric(10,2),
    gst_amount numeric(10,2),
    status character varying(50) DEFAULT 'draft'::character varying,
    current_stage character varying(50),
    current_page integer DEFAULT 1,
    district_officer_id character varying,
    district_review_date timestamp without time zone,
    district_notes text,
    da_id character varying,
    da_review_date timestamp without time zone,
    da_forwarded_date timestamp without time zone,
    da_remarks text,
    state_officer_id character varying,
    state_review_date timestamp without time zone,
    state_notes text,
    dtdo_id character varying,
    dtdo_review_date timestamp without time zone,
    correction_submission_count integer DEFAULT 0 NOT NULL,
    dtdo_remarks text,
    rejection_reason text,
    clarification_requested text,
    site_inspection_scheduled_date timestamp without time zone,
    site_inspection_completed_date timestamp without time zone,
    site_inspection_officer_id character varying,
    site_inspection_notes text,
    site_inspection_outcome character varying(50),
    site_inspection_findings jsonb,
    ownership_proof_url text,
    aadhaar_card_url text,
    pan_card_url text,
    gst_certificate_url text,
    fire_safety_noc_url text,
    pollution_clearance_url text,
    building_plan_url text,
    property_photos_urls jsonb,
    documents jsonb,
    certificate_number character varying(50),
    certificate_issued_date timestamp without time zone,
    certificate_expiry_date timestamp without time zone,
    submitted_at timestamp without time zone,
    approved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    payment_status character varying(20) DEFAULT 'pending'::character varying,
    payment_id character varying(100),
    payment_amount numeric(10,2),
    payment_date timestamp without time zone,
    refund_date timestamp without time zone,
    refund_reason text,
    nearby_attractions jsonb,
    revert_count integer DEFAULT 0 NOT NULL,
    adventure_sports_data jsonb,
    water_sports_data jsonb,
    application_type character varying(50) DEFAULT 'homestay'::character varying
);


ALTER TABLE public.homestay_applications OWNER TO postgres;

--
-- Name: inspection_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inspection_orders (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    scheduled_by character varying NOT NULL,
    scheduled_date timestamp without time zone NOT NULL,
    assigned_to character varying NOT NULL,
    assigned_date timestamp without time zone NOT NULL,
    inspection_date timestamp without time zone NOT NULL,
    inspection_address text NOT NULL,
    special_instructions text,
    status character varying(50) DEFAULT 'scheduled'::character varying,
    dtdo_notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.inspection_orders OWNER TO postgres;

--
-- Name: inspection_reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inspection_reports (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    inspection_order_id character varying NOT NULL,
    application_id character varying NOT NULL,
    submitted_by character varying NOT NULL,
    submitted_date timestamp without time zone NOT NULL,
    actual_inspection_date timestamp without time zone NOT NULL,
    room_count_verified boolean NOT NULL,
    actual_room_count integer,
    category_meets_standards boolean NOT NULL,
    recommended_category character varying(20),
    mandatory_checklist jsonb,
    mandatory_remarks text,
    desirable_checklist jsonb,
    desirable_remarks text,
    amenities_verified jsonb,
    amenities_issues text,
    fire_safety_compliant boolean,
    fire_safety_issues text,
    structural_safety boolean,
    structural_issues text,
    overall_satisfactory boolean NOT NULL,
    recommendation character varying(50) NOT NULL,
    detailed_findings text NOT NULL,
    inspection_photos jsonb,
    report_document_url text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.inspection_reports OWNER TO postgres;

--
-- Name: lgd_blocks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lgd_blocks (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    block_name character varying(100) NOT NULL,
    district_id character varying NOT NULL,
    tehsil_id character varying,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_blocks OWNER TO postgres;

--
-- Name: lgd_districts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lgd_districts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    district_name character varying(100) NOT NULL,
    division_name character varying(100),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_districts OWNER TO postgres;

--
-- Name: lgd_gram_panchayats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lgd_gram_panchayats (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    gram_panchayat_name character varying(100) NOT NULL,
    district_id character varying NOT NULL,
    block_id character varying,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_gram_panchayats OWNER TO postgres;

--
-- Name: lgd_tehsils; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lgd_tehsils (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    tehsil_name character varying(100) NOT NULL,
    district_id character varying NOT NULL,
    tehsil_type character varying(50) DEFAULT 'tehsil'::character varying,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_tehsils OWNER TO postgres;

--
-- Name: lgd_urban_bodies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lgd_urban_bodies (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    lgd_code character varying(20),
    urban_body_name character varying(200) NOT NULL,
    district_id character varying NOT NULL,
    body_type character varying(50) NOT NULL,
    number_of_wards integer,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lgd_urban_bodies OWNER TO postgres;

--
-- Name: login_otp_challenges; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.login_otp_challenges (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    otp_hash character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    consumed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.login_otp_challenges OWNER TO postgres;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    application_id character varying,
    type character varying(100) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    channels jsonb,
    is_read boolean DEFAULT false,
    read_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: objections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.objections (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    inspection_report_id character varying,
    raised_by character varying NOT NULL,
    raised_date timestamp without time zone NOT NULL,
    objection_type character varying(50) NOT NULL,
    objection_title character varying(255) NOT NULL,
    objection_description text NOT NULL,
    severity character varying(20) NOT NULL,
    response_deadline timestamp without time zone,
    status character varying(50) DEFAULT 'pending'::character varying,
    resolution_notes text,
    resolved_by character varying,
    resolved_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.objections OWNER TO postgres;

--
-- Name: password_reset_challenges; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_reset_challenges (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    channel character varying(32) NOT NULL,
    recipient character varying(255),
    otp_hash character varying(255) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    consumed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.password_reset_challenges OWNER TO postgres;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    payment_type character varying(50) NOT NULL,
    amount numeric(10,2) NOT NULL,
    payment_gateway character varying(50),
    gateway_transaction_id character varying(255),
    payment_method character varying(50),
    payment_status character varying(50) DEFAULT 'pending'::character varying,
    payment_link text,
    qr_code_url text,
    payment_link_expiry_date timestamp without time zone,
    initiated_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    receipt_number character varying(100),
    receipt_url text
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: production_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.production_stats (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    total_applications integer NOT NULL,
    approved_applications integer NOT NULL,
    rejected_applications integer NOT NULL,
    pending_applications integer NOT NULL,
    scraped_at timestamp without time zone DEFAULT now(),
    source_url text
);


ALTER TABLE public.production_stats OWNER TO postgres;

--
-- Name: reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reviews (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    application_id character varying NOT NULL,
    user_id character varying NOT NULL,
    rating integer NOT NULL,
    review_text text,
    is_verified_stay boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.reviews OWNER TO postgres;

--
-- Name: session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.session OWNER TO postgres;

--
-- Name: storage_objects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.storage_objects (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    object_key text NOT NULL,
    storage_provider character varying(20) DEFAULT 'local'::character varying NOT NULL,
    file_type character varying(100) NOT NULL,
    category character varying(100) DEFAULT 'general'::character varying,
    mime_type character varying(100) DEFAULT 'application/octet-stream'::character varying,
    size_bytes integer DEFAULT 0 NOT NULL,
    checksum_sha256 character varying(128),
    uploaded_by character varying,
    application_id character varying,
    document_id character varying,
    created_at timestamp without time zone DEFAULT now(),
    last_accessed_at timestamp without time zone
);


ALTER TABLE public.storage_objects OWNER TO postgres;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_settings (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    setting_key character varying(100) NOT NULL,
    setting_value jsonb NOT NULL,
    description text,
    category character varying(50) DEFAULT 'general'::character varying,
    updated_by character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.system_settings OWNER TO postgres;

--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_profiles (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    full_name character varying(255) NOT NULL,
    gender character varying(10) NOT NULL,
    aadhaar_number character varying(12),
    mobile character varying(15) NOT NULL,
    email character varying(255),
    district character varying(100),
    tehsil character varying(100),
    block character varying(100),
    gram_panchayat character varying(100),
    urban_body character varying(200),
    ward character varying(50),
    address text,
    pincode character varying(10),
    telephone character varying(20),
    fax character varying(20),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_profiles OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    mobile character varying(15) NOT NULL,
    full_name text NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    username character varying(50),
    email character varying(255),
    alternate_phone character varying(15),
    designation character varying(100),
    department character varying(100),
    employee_id character varying(50),
    office_address text,
    office_phone character varying(15),
    role character varying(50) DEFAULT 'property_owner'::character varying NOT NULL,
    aadhaar_number character varying(12),
    district character varying(100),
    password text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    sso_id character varying(50)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: application_actions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.application_actions (id, application_id, officer_id, action, previous_status, new_status, feedback, issues_found, created_at) FROM stdin;
5ae5a0d6-c859-466f-bc67-b5109aee9370	ee6d41b1-3ed6-41b2-ac77-7bebf0ffa061	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	payment_verified	draft	paid_pending_submit	Registration fee paid via HimKosh (CIN: A25L209798). Awaiting manual submission.	\N	2025-12-12 10:49:47.376673
99b002fb-11ec-4dff-8799-d3c451e39a77	ee6d41b1-3ed6-41b2-ac77-7bebf0ffa061	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	submitted	paid_pending_submit	submitted	Manual submission confirmed by applicant after upfront payment.	\N	2025-12-12 10:50:10.750318
5158f4a9-7779-4c21-b8d1-838fbf8fb1ae	ee6d41b1-3ed6-41b2-ac77-7bebf0ffa061	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	start_scrutiny	submitted	under_scrutiny	\N	\N	2025-12-12 11:01:17.470657
c1e6d06a-00a4-4b0f-b106-10ed471d4967	ee6d41b1-3ed6-41b2-ac77-7bebf0ffa061	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Inspection	\N	2025-12-12 11:21:15.618155
875005d5-5df2-4c8f-a8b8-1e9fe60cffe2	ee6d41b1-3ed6-41b2-ac77-7bebf0ffa061	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	dtdo_accept	forwarded_to_dtdo	dtdo_review	inspection	\N	2025-12-12 11:21:45.354939
47831c2e-f67c-46ce-9013-56ed9e4e2d05	ee6d41b1-3ed6-41b2-ac77-7bebf0ffa061	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	inspection_scheduled	dtdo_review	inspection_scheduled	Inspection scheduled for 2025-12-15T06:00:00.000Z by DA Shimla	\N	2025-12-12 11:21:57.115745
5e13e2e8-d575-4619-bbd2-082a0c0ac75f	ee6d41b1-3ed6-41b2-ac77-7bebf0ffa061	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	inspection_acknowledged	inspection_scheduled	inspection_scheduled	Auto-acknowledged after inspection completion.	\N	2025-12-12 11:22:39.885917
ed07da0c-5736-489f-9fd4-abc2bfe7e32e	ee6d41b1-3ed6-41b2-ac77-7bebf0ffa061	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	inspection_completed	inspection_scheduled	inspection_under_review	Findings & Recommendation\nOverall Inspection Summary *\nCapture the key highlights of this visit (minimum 20 characters). This summary is stored with the RC.	\N	2025-12-12 11:22:39.89222
b8d0f4ed-c0dc-4cb1-ac9c-b75788797b65	ee6d41b1-3ed6-41b2-ac77-7bebf0ffa061	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	verified_for_payment	inspection_under_review	verified_for_payment	Approved	\N	2025-12-12 11:23:05.19696
06319f28-00f1-4ce5-a28d-939877f1c7c5	44b8281c-c332-476c-9f9c-14766a4a208a	e52010b9-7546-42a1-882e-4334de63c8ca	payment_verified	draft	paid_pending_submit	Registration fee paid via HimKosh (CIN: A25L211911). Awaiting manual submission.	\N	2025-12-12 15:53:47.948603
a32bc032-634c-462c-88bd-863112ac3c8b	44b8281c-c332-476c-9f9c-14766a4a208a	e52010b9-7546-42a1-882e-4334de63c8ca	submitted	paid_pending_submit	submitted	Manual submission confirmed by applicant after upfront payment.	\N	2025-12-12 15:54:02.592641
ebc826d3-fb67-43e7-aafc-06acaafedde2	44b8281c-c332-476c-9f9c-14766a4a208a	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	start_scrutiny	submitted	under_scrutiny	\N	\N	2025-12-12 15:55:36.084136
36491f08-ecc3-4d4d-959f-c768791510b7	44b8281c-c332-476c-9f9c-14766a4a208a	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Add your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.	\N	2025-12-12 16:10:28.152723
5c3636cc-c8a2-4ccf-8a1c-f36b3e853402	44b8281c-c332-476c-9f9c-14766a4a208a	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	dtdo_accept	forwarded_to_dtdo	dtdo_review	Inspection Schedule	\N	2025-12-12 16:11:01.44804
64d154bf-4e02-447b-a17b-28bf3b3e5d7a	44b8281c-c332-476c-9f9c-14766a4a208a	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	inspection_scheduled	dtdo_review	inspection_scheduled	Inspection scheduled for 2025-12-15T04:30:00.000Z by DA Shimla	\N	2025-12-12 16:11:14.149168
f0ac2ff4-b8c9-4628-861d-ce66f11d32b4	44b8281c-c332-476c-9f9c-14766a4a208a	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	inspection_acknowledged	inspection_scheduled	inspection_scheduled	Auto-acknowledged after inspection completion.	\N	2025-12-12 16:13:43.880699
00e13c9b-e822-430c-8fca-942b36f2c5eb	44b8281c-c332-476c-9f9c-14766a4a208a	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	inspection_completed	inspection_scheduled	inspection_under_review	Findings & Recommendation\nOverall Inspection Summary *\nCapture the key highlights of this visit (minimum 20 characters). This summary is stored with the RC.	\N	2025-12-12 16:13:43.885918
c2ba9fed-d507-4df3-a8a8-d0ada190ba2f	44b8281c-c332-476c-9f9c-14766a4a208a	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	approved	inspection_under_review	approved	Certificate HP-HST-2025-40807 issued. Payment was already completed upfront.	\N	2025-12-12 16:14:11.334783
0bac9a88-6cc2-4179-8670-1cde846fa30c	cefe6037-d38c-4923-a2d4-cdac09d844c6	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	legacy_rc_verified	legacy_rc_review	approved	approved	\N	2025-12-12 20:28:12.774451
ad735b44-7afc-49d8-8d86-9e828f142c37	ba1a9a91-3dd0-4daf-b16b-c338b3d9ccb5	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	payment_verified	draft	submitted	Registration fee paid via HimKosh (CIN: A25L243556). Application submitted.	\N	2025-12-17 06:51:44.98731
5b22b848-0d16-476f-b631-467ac3564cb4	ba1a9a91-3dd0-4daf-b16b-c338b3d9ccb5	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	start_scrutiny	submitted	under_scrutiny	\N	\N	2025-12-17 08:45:50.984815
68c6b353-c1b3-464c-a70b-d8891738559c	ba1a9a91-3dd0-4daf-b16b-c338b3d9ccb5	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	forwarded_to_dtdo	under_scrutiny	forwarded_to_dtdo	Approve	\N	2025-12-17 08:46:04.267785
18846730-ec73-43d8-af9e-6662257f1570	ba1a9a91-3dd0-4daf-b16b-c338b3d9ccb5	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	dtdo_accept	forwarded_to_dtdo	dtdo_review	Inspection	\N	2025-12-17 09:15:12.117161
82c2e1f6-0dd9-4559-95d8-d67d7295fbd4	ba1a9a91-3dd0-4daf-b16b-c338b3d9ccb5	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	inspection_scheduled	dtdo_review	inspection_scheduled	Inspection scheduled for 2025-12-20T07:00:00.000Z by DA Shimla	\N	2025-12-17 09:15:24.34729
1f3ff0ba-2ca1-40d9-97c3-a6e67550e381	ba1a9a91-3dd0-4daf-b16b-c338b3d9ccb5	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	inspection_acknowledged	inspection_scheduled	inspection_scheduled	Auto-acknowledged after inspection completion.	\N	2025-12-17 09:39:07.094487
5db0fce6-7821-48bd-8aae-360614f440d0	ba1a9a91-3dd0-4daf-b16b-c338b3d9ccb5	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	inspection_completed	inspection_scheduled	inspection_under_review	Findings & Recommendation\nOverall Inspection Summary *	\N	2025-12-17 09:39:07.103322
8d7607c1-bb45-45fb-bd16-5632acd4cb08	ba1a9a91-3dd0-4daf-b16b-c338b3d9ccb5	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	approved	inspection_under_review	approved	Certificate HP-HST-2025-51418 issued. Payment was already completed upfront.	\N	2025-12-17 09:39:28.019941
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, user_id, action, details, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: certificates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.certificates (id, application_id, certificate_number, certificate_type, issued_date, valid_from, valid_upto, property_name, category, address, district, owner_name, owner_mobile, certificate_pdf_url, qr_code_data, digital_signature, issued_by, status, revocation_reason, revoked_by, revoked_date, renewal_reminder_sent, renewal_application_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: clarifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clarifications (id, objection_id, application_id, submitted_by, submitted_date, clarification_text, supporting_documents, reviewed_by, reviewed_date, review_status, review_notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ddo_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ddo_codes (id, district, ddo_code, ddo_description, treasury_code, is_active, created_at, updated_at) FROM stdin;
aa2e868a-014f-4c97-bad0-89c4de8670a2	Chamba	CHM00-532	D.T.D.O. CHAMBA	CHM00	t	2025-12-11 10:57:28.124346	2025-12-11 10:57:28.124346
18c2d373-80d8-40ad-9221-7fc642b404c7	Bharmour	CHM01-001	S.D.O.(CIVIL) BHARMOUR	CHM01	t	2025-12-11 10:57:28.128671	2025-12-11 10:57:28.128671
159565d8-d46e-4c20-a0df-12bedd30844b	Shimla (Central)	CTO00-068	A.C. (TOURISM) SHIMLA	CTO00	t	2025-12-11 10:57:28.132006	2025-12-11 10:57:28.132006
e9881bd0-380f-4cd7-8f2f-0e36a69f37c4	Hamirpur	HMR00-053	DISTRICT TOURISM DEVELOPMENT OFFICE HAMIRPUR (UNA)	HMR00	t	2025-12-11 10:57:28.13585	2025-12-11 10:57:28.13585
62398392-43cf-4db4-9f89-49b26e6a8152	Una	HMR00-053	DISTRICT TOURISM DEVELOPMENT OFFICE HAMIRPUR (UNA)	HMR00	t	2025-12-11 10:57:28.138309	2025-12-11 10:57:28.138309
200f4d2d-1e3a-44e7-bfe6-4b588a83d1d5	Kullu (Dhalpur)	KLU00-532	DEPUTY DIRECTOR TOURISM AND CIVIL AVIATION KULLU DHALPUR	KLU00	t	2025-12-11 10:57:28.140323	2025-12-11 10:57:28.140323
9527bd00-c182-4a23-8eac-f2b77a4ef95a	Kangra	KNG00-532	DIV.TOURISM DEV.OFFICER(DTDO) DHARAMSALA	KNG00	t	2025-12-11 10:57:28.142095	2025-12-11 10:57:28.142095
236f96eb-5833-47c0-bd61-199ec84e65ef	Kinnaur	KNR00-031	DISTRICT TOURISM DEVELOPMENT OFFICER KINNAUR AT RECKONG PEO	KNR00	t	2025-12-11 10:57:28.145343	2025-12-11 10:57:28.145343
3e700356-e31b-492c-9094-78253eab1ef8	Lahaul-Spiti (Kaza)	KZA00-011	PO ITDP KAZA	KZA00	t	2025-12-11 10:57:28.147757	2025-12-11 10:57:28.147757
cc8a66de-0be6-44e3-a45b-943a48cb37ec	Lahaul	LHL00-017	DISTRICT TOURISM DEVELOPMENT OFFICER	LHL00	t	2025-12-11 10:57:28.149534	2025-12-11 10:57:28.149534
2ad67dc9-b983-4354-919c-436e41636a74	Mandi	MDI00-532	DIV. TOURISM DEV. OFFICER MANDI	MDI00	t	2025-12-11 10:57:28.151818	2025-12-11 10:57:28.151818
9be6480d-03ac-44a1-bd0f-1c9d7b9bd501	Pangi	PNG00-003	PROJECT OFFICER ITDP PANGI	PNG00	t	2025-12-11 10:57:28.153916	2025-12-11 10:57:28.153916
583743e9-67b6-4e40-ab53-f05fcb3ce379	Shimla	SML00-532	DIVISIONAL TOURISM OFFICER SHIMLA	SML00	t	2025-12-11 10:57:28.156174	2025-12-11 10:57:28.156174
ab932954-8e96-46d7-bc85-02548bf473d9	Sirmour	SMR00-055	DISTRICT TOURISM DEVELOPMENT OFFICE NAHAN	SMR00	t	2025-12-11 10:57:28.159049	2025-12-11 10:57:28.159049
6cd1529a-cfc2-426a-81ad-6d6a5df6b498	Solan	SOL00-046	DTDO SOLAN	SOL00	t	2025-12-11 10:57:28.161421	2025-12-11 10:57:28.161421
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.documents (id, application_id, document_type, file_name, file_path, file_size, mime_type, upload_date, ai_verification_status, ai_confidence_score, ai_notes, is_verified, verification_status, verified_by, verification_date, verification_notes) FROM stdin;
197ac14d-c2e4-4e54-9406-b868522a735b	ee6d41b1-3ed6-41b2-ac77-7bebf0ffa061	revenue_papers	Test_Doc01-Hindi.pdf	/api/local-object/download/dff9d713-5794-4ff6-aacc-a027134644ae?type=revenue-papers	61398	application/pdf	2025-12-12 11:07:55.80286	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 11:21:07.049	\N
ac58229b-3f4f-4a24-9bd1-6b92f963b3d4	ee6d41b1-3ed6-41b2-ac77-7bebf0ffa061	affidavit_section_29	Test_Doc01-Hindi.pdf	/api/local-object/download/1fe3a58d-d7a4-48a9-96c3-83d76969e1c0?type=affidavit-section29	61398	application/pdf	2025-12-12 11:07:55.80286	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 11:21:07.051	\N
dc61052c-7267-400d-af26-698c9df1500d	ee6d41b1-3ed6-41b2-ac77-7bebf0ffa061	undertaking_form_c	Test_Doc01-Hindi.pdf	/api/local-object/download/73705ddf-acdc-476f-a07d-82342ea0ca25?type=undertaking-form-c	61398	application/pdf	2025-12-12 11:07:55.80286	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 11:21:07.053	\N
f5748638-169a-4fce-9b1d-0076fcc5b246	ee6d41b1-3ed6-41b2-ac77-7bebf0ffa061	commercial_electricity_bill	Test_Doc01-Hindi.pdf	/api/local-object/download/8e0e0e11-8dff-4b78-b9d7-742056453b4d?type=commercial-electricity-bill	61398	application/pdf	2025-12-12 11:07:55.80286	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 11:21:07.055	\N
7990954b-9797-45dd-bc2c-0f35fc5f2054	ee6d41b1-3ed6-41b2-ac77-7bebf0ffa061	commercial_water_bill	Test_Doc01-Hindi.pdf	/api/local-object/download/bf3a6629-d377-4974-90e3-b6bb5b6471cc?type=commercial-water-bill	61398	application/pdf	2025-12-12 11:07:55.80286	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 11:21:07.057	\N
45fc21d7-99d6-4e06-890b-1f11b70d1e19	ee6d41b1-3ed6-41b2-ac77-7bebf0ffa061	property_photo	519109575.jpg	/api/local-object/download/b4e34401-b8ae-49ff-a27b-88629cdd811d?type=property-photo	96524	image/jpeg	2025-12-12 11:07:55.80286	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 11:21:07.058	\N
2cf9788a-432c-46f7-9e80-dde888fb3e3b	ee6d41b1-3ed6-41b2-ac77-7bebf0ffa061	property_photo	529253340.jpg	/api/local-object/download/4c48d44d-51e1-4574-8582-2acb0b34945d?type=property-photo	13584	image/jpeg	2025-12-12 11:07:55.80286	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 11:21:07.059	\N
cec4482d-3da9-4660-b669-0c1075890a0d	44b8281c-c332-476c-9f9c-14766a4a208a	revenue_papers	Test_Doc01-Hindi.pdf	/api/local-object/download/e0742dab-7c19-4ff5-b57d-1e540540b50b?type=revenue-papers	61398	application/pdf	2025-12-12 15:58:47.319286	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 16:10:18.558	\N
f4419d02-13f3-4166-9c31-40d7322a6bbf	44b8281c-c332-476c-9f9c-14766a4a208a	affidavit_section_29	Test_Doc01-Hindi.pdf	/api/local-object/download/74187c67-f680-42ab-9423-036ec7dd0fb8?type=affidavit-section29	61398	application/pdf	2025-12-12 15:58:47.319286	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 16:10:18.56	\N
ebf5e256-706c-4a5c-8683-a8b1d44b8996	44b8281c-c332-476c-9f9c-14766a4a208a	undertaking_form_c	Test_Doc01-Hindi.pdf	/api/local-object/download/bee6932a-b107-40eb-889c-9383174b4150?type=undertaking-form-c	61398	application/pdf	2025-12-12 15:58:47.319286	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 16:10:18.565	\N
e29bc47a-f532-4030-8288-34940a6587ee	44b8281c-c332-476c-9f9c-14766a4a208a	property_photo	519109575.jpg	/api/local-object/download/21c5b2d5-9cb7-485e-abfa-e86d823d87ec?type=property-photo	96524	image/jpeg	2025-12-12 15:58:47.319286	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 16:10:18.567	\N
f5bd7629-fa99-4f7f-b71f-922f31b4a8f9	44b8281c-c332-476c-9f9c-14766a4a208a	property_photo	529253340.jpg	/api/local-object/download/12caf16a-89b5-4879-8636-f69cb1387a9d?type=property-photo	13584	image/jpeg	2025-12-12 15:58:47.319286	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 16:10:18.57	\N
88e670e6-ae40-413b-812a-de7473d68f54	cefe6037-d38c-4923-a2d4-cdac09d844c6	owner_identity_proof	Test_Doc01-Hindi.pdf	/api/local-object/download/8ce66739-04b9-49e7-a433-b62c76bdec98?type=document	61398	application/pdf	2025-12-12 20:27:02.261174	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 20:28:01.395	\N
6b7df36a-2f25-45c1-b023-095ddab6db94	cefe6037-d38c-4923-a2d4-cdac09d844c6	legacy_certificate	Test_Doc01-Hindi.pdf	/api/local-object/download/2ec85148-b3c0-4605-9229-721d4a45565e?type=document	61398	application/pdf	2025-12-12 20:27:02.25653	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 20:28:01.398	\N
2d0f2c0c-e4c5-4c35-8b1a-c53015a32ef3	cefe6037-d38c-4923-a2d4-cdac09d844c6	owner_identity_proof	Test_Doc01-Hindi.pdf	/api/local-object/download/8ce66739-04b9-49e7-a433-b62c76bdec98?type=document	61398	application/pdf	2025-12-12 20:27:00.572992	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 20:28:01.399	\N
2d55efca-815a-48f3-b58f-62c18aabaf3d	cefe6037-d38c-4923-a2d4-cdac09d844c6	legacy_certificate	Test_Doc01-Hindi.pdf	/api/local-object/download/2ec85148-b3c0-4605-9229-721d4a45565e?type=document	61398	application/pdf	2025-12-12 20:27:00.566828	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 20:28:01.401	\N
54bd2b89-117f-4613-a4a9-cd0b60311ccb	ba1a9a91-3dd0-4daf-b16b-c338b3d9ccb5	revenue_papers	Test_Doc01-Hindi.pdf	/api/local-object/download/013e11ad-845b-447d-885c-926f3067f4cc?type=revenue-papers	61398	application/pdf	2025-12-17 06:51:44.993986	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-17 08:45:53.685	\N
590a9212-b7ce-4558-9f9b-bfa564ec9a74	ba1a9a91-3dd0-4daf-b16b-c338b3d9ccb5	affidavit_section_29	Test_Doc01-Hindi.pdf	/api/local-object/download/565ef2ce-ca03-4edc-8454-d90d78e3e9d1?type=affidavit-section29	61398	application/pdf	2025-12-17 06:51:44.993986	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-17 08:45:53.689	\N
2dbd9d2c-c71c-41e1-81d8-7e88f3cc4417	ba1a9a91-3dd0-4daf-b16b-c338b3d9ccb5	undertaking_form_c	Test_Doc01-Hindi.pdf	/api/local-object/download/9a6b2fc0-eb31-44cf-9e4f-e4935d4ef03d?type=undertaking-form-c	61398	application/pdf	2025-12-17 06:51:44.993986	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-17 08:45:53.691	\N
b7a13396-fc70-4300-84d6-c88589264cd0	ba1a9a91-3dd0-4daf-b16b-c338b3d9ccb5	commercial_electricity_bill	Test_Doc01-Hindi.pdf	/api/local-object/download/02f0fb1f-f89b-46ef-ad4a-6ba1c58b38df?type=commercial-electricity-bill	61398	application/pdf	2025-12-17 06:51:44.993986	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-17 08:45:53.693	\N
c8abdc2e-d1dd-4343-ac00-1b08933ce64f	ba1a9a91-3dd0-4daf-b16b-c338b3d9ccb5	commercial_water_bill	Test_Doc01-Hindi.pdf	/api/local-object/download/8667a2d6-ce4d-4f57-8cc6-fbae38534505?type=commercial-water-bill	61398	application/pdf	2025-12-17 06:51:44.993986	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-17 08:45:53.695	\N
1ba580e7-8e47-47bd-8987-8607b8f8c8fd	ba1a9a91-3dd0-4daf-b16b-c338b3d9ccb5	property_photo	519109575.jpg	/api/local-object/download/9e3a5565-8184-4c45-b3d6-08154794dfc8?type=property-photo	96524	image/jpeg	2025-12-17 06:51:44.993986	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-17 08:45:53.697	\N
ab98001f-13a4-4bf4-86ea-d106efe5005c	ba1a9a91-3dd0-4daf-b16b-c338b3d9ccb5	property_photo	529253340.jpg	/api/local-object/download/b8043eca-7018-41fb-844c-92cb7838cdc2?type=property-photo	13584	image/jpeg	2025-12-17 06:51:44.993986	\N	\N	\N	t	verified	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-17 08:45:53.7	\N
\.


--
-- Data for Name: himkosh_transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.himkosh_transactions (id, application_id, dept_ref_no, app_ref_no, total_amount, tender_by, merchant_code, dept_id, service_code, ddo, head1, amount1, head2, amount2, head3, amount3, head4, amount4, head10, amount10, period_from, period_to, encrypted_request, request_checksum, ech_txn_id, bank_cin, bank_name, payment_date, status, status_cd, response_checksum, is_double_verified, double_verification_date, double_verification_data, challan_print_url, portal_base_url, transaction_status, initiated_at, responded_at, verified_at, created_at, updated_at) FROM stdin;
b716ef21-4cdc-4fdb-a5f5-5257df90218a	ee6d41b1-3ed6-41b2-ac77-7bebf0ffa061	HP-HS-2025-SML-000001	HPT1765536506589gffz	1	Test AAAA	HIMKOSH230	230	TSM	SML00-532	1452-00-800-01	1	\N	\N	\N	\N	\N	\N	\N	\N	12-12-2025	12-12-2025	FdkGGiidekvpm0UUibJM5FgEEJcR9UfPa9WuxgDsr2pIaC6AQljy0Ght98ImRA3kJI4eDx4WbkFFTi5PvSI1FySVIq/lWt7G6s9wmVQwXp46r8VNe6WgvTXPvwYfPLLXHvMaS0PuV607hwpvUmNZC+mHwjbOx543wLUJPDqOshBj6o/sFiUPNPljknbGgEVXtB3MPLOpneTE/52RiB3BMIHVRPCoZ/k4oOA0mnOny4jE376duYYelL/dPkYGfkYKTUS+R8ZeagGP65cIlqI78bGuyq9V04INRJmWViJyAk3UyECWjcDP3YhfSBDj/JLB4SRf/U9Kays8dM0YY58xWZQq2gafuviJNNeWrbMCGZ+uCABg9snrBNgnqoeNMqNY9GquJQSbmzIA7XJSH3klYSf4ntNSYqryvYfy1rrG2js=	46e261a2d45ba1ad78bd80551cc8948e	A25L209798	CPAFZYHHH4	SBI	12122025161944	Completed successfully.	1	1aecd6a015a968e3d7399ebc896a24a0	f	\N	\N	https://himkosh.hp.nic.in/eChallan/challan_reports/reportViewer.aspx?reportName=PaidChallan&TransId=A25L209798	https://dev.osipl.dev	success	2025-12-12 10:48:26.597888	2025-12-12 10:49:47.367	\N	2025-12-12 10:48:26.597888	2025-12-12 10:48:26.597888
659ec6a9-4f08-440c-9d4f-57db814daea7	44b8281c-c332-476c-9f9c-14766a4a208a	HP-HS-2025-SML-000002	HPT17655547471144DYL	1	Test XXX	HIMKOSH230	230	TSM	SML00-532	1452-00-800-01	1	\N	\N	\N	\N	\N	\N	\N	\N	12-12-2025	12-12-2025	FdkGGiidekvpm0UUibJM5FgEEJcR9UfPa9WuxgDsr2r/37yM5ai2Pyi+c4ASucch0dCF/FhYjhslDjaLnZ+AdywO+Sb1J2a+kEKmjPZ5MRMTAE1d8nFBsKPNAIfeYN1AVJWuKL0Rcyk8Mx1KfC2AXmPSs1EYD89tNMe5hvF9LQ6JTHoUljuZvi8EDODGBj/NaSwHGu5gi4GHXfiK0Z9qqnFZIUAEiCIpyrYrHUnzioAJ9GWgmI0/R1oC3/+mUARpsBv5ZZNdDkjQPXHNCHNutFc/SlgwDK0RdXX6VzlFBL4oxxbl1RsWAH2QGlKJw/OL1Bn73CgS1Hca+5xR/j7aNT00jam4GtvppYHxTlCL1aqaGVE5jlYk5fn4E+fS8U6AnqgVfWuThxf6Djmvym68nYZsgVYZnddCRmAlQmx6u58=	28d3233bdf2e04bc3118383dd64000e8	A25L211911	CPAFZZIJU4	SBI	12122025212346	Completed successfully.	1	50f40f03a868451a652f6849409b7eaa	f	\N	\N	https://himkosh.hp.nic.in/eChallan/challan_reports/reportViewer.aspx?reportName=PaidChallan&TransId=A25L211911	https://dev.osipl.dev	success	2025-12-12 15:52:27.122663	2025-12-12 15:53:47.937	\N	2025-12-12 15:52:27.122663	2025-12-12 15:52:27.122663
cf2819d3-08ab-46fc-b4f1-22801337c92f	ba1a9a91-3dd0-4daf-b16b-c338b3d9ccb5	HP-HS-2025-SML-000047	HPT1765954169810_KHY	1	Test AAAA	HIMKOSH230	230	TSM	SML00-532	1452-00-800-01	1	\N	\N	\N	\N	\N	\N	\N	\N	17-12-2025	17-12-2025	FdkGGiidekvpm0UUibJM5FgEEJcR9UfPa9WuxgDsr2oPo0MALe340Xy89VYU2Pg8hHtyI+QI7s0+7DjXgoJsR970jhmaebeeruYvBqN94bDOCsOktvxBXxkmtkLFF+nSQAD6rNSsRhpPGzVXqKu335Nnf76vP1HRcspBvRGX8Z+O8Wper3WiYG+NKj/LQLEMerFttN/SQlO+/dJGuKhxwJDYUpavCIgoDX009QHrsB2r6gGyJd+Gta6KhFbdBI67kNBNo7VEqa6K6YbgYmvPTZxLUA0xMsHXVA0xm9a8Ikksd7jZVaTfCIc3AheQn64ZIFlJQrfCgoo0ouux75YwtbnPN7DSCx99YwN2Euk4wVawTLj5VXexdcaD/VfwOKV//xPjP+q57FaDZqditWO94eEFeUnN2EhkNVY7I5aJrbM=	fe3204eaf8f4b30010d28c1be4ede77d	A25L243556	CPAGANLRR5	SBI	17122025122144	Completed successfully.	1	eab9fe698d9eb0cc11ef89306203238c	f	\N	\N	https://himkosh.hp.nic.in/eChallan/challan_reports/reportViewer.aspx?reportName=PaidChallan&TransId=A25L243556	https://dev.osipl.dev	success	2025-12-17 06:49:29.817923	2025-12-17 06:51:44.976	\N	2025-12-17 06:49:29.817923	2025-12-17 06:49:29.817923
\.


--
-- Data for Name: homestay_applications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.homestay_applications (id, user_id, application_number, application_kind, parent_application_id, parent_application_number, parent_certificate_number, inherited_certificate_valid_upto, service_context, service_notes, service_requested_at, property_name, category, location_type, total_rooms, district, district_other, tehsil, tehsil_other, block, block_other, gram_panchayat, gram_panchayat_other, urban_body, urban_body_other, ward, address, pincode, telephone, fax, latitude, longitude, owner_name, owner_gender, owner_mobile, owner_email, guardian_name, owner_aadhaar, property_ownership, proposed_room_rate, project_type, property_area, single_bed_rooms, single_bed_beds, single_bed_room_size, single_bed_room_rate, double_bed_rooms, double_bed_beds, double_bed_room_size, double_bed_room_rate, family_suites, family_suite_beds, family_suite_size, family_suite_rate, attached_washrooms, gstin, selected_category, average_room_rate, highest_room_rate, lowest_room_rate, certificate_validity_years, is_pangi_sub_division, distance_airport, distance_railway, distance_city_center, distance_shopping, distance_bus_stand, lobby_area, dining_area, parking_area, eco_friendly_facilities, differently_abled_facilities, fire_equipment_details, nearest_hospital, amenities, rooms, base_fee, total_before_discounts, validity_discount, female_owner_discount, pangi_discount, total_discount, total_fee, per_room_fee, gst_amount, status, current_stage, current_page, district_officer_id, district_review_date, district_notes, da_id, da_review_date, da_forwarded_date, da_remarks, state_officer_id, state_review_date, state_notes, dtdo_id, dtdo_review_date, correction_submission_count, dtdo_remarks, rejection_reason, clarification_requested, site_inspection_scheduled_date, site_inspection_completed_date, site_inspection_officer_id, site_inspection_notes, site_inspection_outcome, site_inspection_findings, ownership_proof_url, aadhaar_card_url, pan_card_url, gst_certificate_url, fire_safety_noc_url, pollution_clearance_url, building_plan_url, property_photos_urls, documents, certificate_number, certificate_issued_date, certificate_expiry_date, submitted_at, approved_at, created_at, updated_at, payment_status, payment_id, payment_amount, payment_date, refund_date, refund_reason, nearby_attractions, revert_count, adventure_sports_data, water_sports_data, application_type) FROM stdin;
ee6d41b1-3ed6-41b2-ac77-7bebf0ffa061	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	HP-HS-2025-SML-000001	new_registration	\N	\N	\N	\N	\N	\N	\N	Dreamland Resorts	gold	gp	1	Shimla	\N	Chaupal	\N			Village AAA					Shiva Apartment L 2 Checkrail, Near I VY School, Shimla,	171001		\N	\N	\N	Test AAAA	male	8091441005	test@test.com	\N	666666666671	owned	0.00	new_project	0.00	1	1	0.00	3500.00	0	2	0.00	0.00	0	4	0.00	0.00	1	121212121212121	gold	0.00	0.00	0.00	1	f	0.00	0.00	0.00	0.00	0.00	0.00	0.00						{"cctv": true, "fireSafety": true}	\N	6000.00	6000.00	0.00	0.00	0.00	0.00	6000.00	0.00	0.00	approved	inspection_completed	6	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	2025-12-12 11:23:05.192	Approved	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 11:21:15.611	2025-12-12 11:21:15.611	Inspection	\N	\N	\N	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	2025-12-12 11:21:45.35	0	inspection	\N	\N	2025-12-15 06:00:00	2025-12-12 11:22:39.887	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	Findings & Recommendation\nOverall Inspection Summary *\nCapture the key highlights of this visit (minimum 20 characters). This summary is stored with the RC.	recommended	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "b8a33541-e370-4330-af84-732a4ce3cc6a", "url": "/api/local-object/download/dff9d713-5794-4ff6-aacc-a027134644ae?type=revenue-papers", "name": "Test_Doc01-Hindi.pdf", "type": "revenue_papers", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/dff9d713-5794-4ff6-aacc-a027134644ae?type=revenue-papers", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "f526724f-dc40-4642-809d-44574cc0cfd7", "url": "/api/local-object/download/1fe3a58d-d7a4-48a9-96c3-83d76969e1c0?type=affidavit-section29", "name": "Test_Doc01-Hindi.pdf", "type": "affidavit_section_29", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/1fe3a58d-d7a4-48a9-96c3-83d76969e1c0?type=affidavit-section29", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "e83a4ea4-c0c1-462e-908c-ed0b564a8469", "url": "/api/local-object/download/73705ddf-acdc-476f-a07d-82342ea0ca25?type=undertaking-form-c", "name": "Test_Doc01-Hindi.pdf", "type": "undertaking_form_c", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/73705ddf-acdc-476f-a07d-82342ea0ca25?type=undertaking-form-c", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "adc2dc79-97cc-4379-8090-960f6c4bf6df", "url": "/api/local-object/download/8e0e0e11-8dff-4b78-b9d7-742056453b4d?type=commercial-electricity-bill", "name": "Test_Doc01-Hindi.pdf", "type": "commercial_electricity_bill", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/8e0e0e11-8dff-4b78-b9d7-742056453b4d?type=commercial-electricity-bill", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "commercial_electricity_bill"}, {"id": "1817d767-8674-4d1a-8fae-3604cba6ca6f", "url": "/api/local-object/download/bf3a6629-d377-4974-90e3-b6bb5b6471cc?type=commercial-water-bill", "name": "Test_Doc01-Hindi.pdf", "type": "commercial_water_bill", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/bf3a6629-d377-4974-90e3-b6bb5b6471cc?type=commercial-water-bill", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "commercial_water_bill"}, {"id": "78693b03-0121-465d-bfc6-609e5697966f", "url": "/api/local-object/download/b4e34401-b8ae-49ff-a27b-88629cdd811d?type=property-photo", "name": "519109575.jpg", "type": "property_photo", "fileName": "519109575.jpg", "filePath": "/api/local-object/download/b4e34401-b8ae-49ff-a27b-88629cdd811d?type=property-photo", "fileSize": 96524, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "7b4b1c99-c17d-46bd-9fd7-621ed55190bc", "url": "/api/local-object/download/4c48d44d-51e1-4574-8582-2acb0b34945d?type=property-photo", "name": "529253340.jpg", "type": "property_photo", "fileName": "529253340.jpg", "filePath": "/api/local-object/download/4c48d44d-51e1-4574-8582-2acb0b34945d?type=property-photo", "fileSize": 13584, "mimeType": "image/jpeg", "documentType": "property_photo"}]	HP-HST-2025-75313	2025-12-12 11:29:05.141273	2026-12-12 11:29:05.141273	2025-12-12 10:50:10.744	2025-12-12 11:29:05.141273	2025-12-12 04:42:47.138174	2025-12-12 11:23:05.192	paid	A25L209798	1.00	2025-12-12 00:00:00	\N	\N	{"waterfall": true, "hotSprings": true, "pineForest": true, "fishingSpot": true, "riverStream": true, "historicFort": true, "appleOrchards": true, "campingGround": true, "mountainBiking": true, "buddhistMonastery": true}	0	\N	\N	homestay
44b8281c-c332-476c-9f9c-14766a4a208a	e52010b9-7546-42a1-882e-4334de63c8ca	HP-HS-2025-SML-000002	new_registration	\N	\N	\N	\N	\N	\N	\N	Draft Homestay	silver	gp	1	Shimla	\N	Chaupal	\N			Village BBB					Test Property  \nAddress	171001	08091441005	\N	\N	\N	Test XXX	male	6666666681	microaistudio@gmail.com	\N	666666666681	owned	0.00	new_project	0.00	1	1	1000.00	2600.00	0	2	0.00	0.00	0	4	0.00	0.00	1		silver	0.00	0.00	0.00	1	f	0.00	0.00	0.00	0.00	0.00	0.00	0.00						{"cctv": true, "fireSafety": true}	\N	3000.00	3000.00	0.00	0.00	0.00	0.00	3000.00	0.00	0.00	approved	inspection_completed	6	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	2025-12-12 16:14:11.33	Verify for Payment\nThe owner will be allowed to proceed with payment.	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 16:10:28.146	2025-12-12 16:10:28.146	Add your overall scrutiny remarks before forwarding this application to the District Tourism Development Officer.	\N	\N	\N	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	2025-12-12 16:11:01.443	0	Inspection Schedule	\N	\N	2025-12-15 04:30:00	2025-12-12 16:13:43.881	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	Findings & Recommendation\nOverall Inspection Summary *\nCapture the key highlights of this visit (minimum 20 characters). This summary is stored with the RC.	recommended	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "4fdc5ab8-1b55-49e0-b3aa-6208b6edb4c0", "url": "/api/local-object/download/e0742dab-7c19-4ff5-b57d-1e540540b50b?type=revenue-papers", "name": "Test_Doc01-Hindi.pdf", "type": "revenue_papers", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/e0742dab-7c19-4ff5-b57d-1e540540b50b?type=revenue-papers", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "fd84acfd-c77a-4e5d-885f-8496839e029f", "url": "/api/local-object/download/74187c67-f680-42ab-9423-036ec7dd0fb8?type=affidavit-section29", "name": "Test_Doc01-Hindi.pdf", "type": "affidavit_section_29", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/74187c67-f680-42ab-9423-036ec7dd0fb8?type=affidavit-section29", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "f0d3deb4-895f-4c74-98ec-6fe804a73e11", "url": "/api/local-object/download/bee6932a-b107-40eb-889c-9383174b4150?type=undertaking-form-c", "name": "Test_Doc01-Hindi.pdf", "type": "undertaking_form_c", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/bee6932a-b107-40eb-889c-9383174b4150?type=undertaking-form-c", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "f0b2ce8c-94cd-4d1a-b235-b8b93d7a10c2", "url": "/api/local-object/download/21c5b2d5-9cb7-485e-abfa-e86d823d87ec?type=property-photo", "name": "519109575.jpg", "type": "property_photo", "fileName": "519109575.jpg", "filePath": "/api/local-object/download/21c5b2d5-9cb7-485e-abfa-e86d823d87ec?type=property-photo", "fileSize": 96524, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "ad4b06b7-d3cd-4f82-9b7e-4c3a62b725cf", "url": "/api/local-object/download/12caf16a-89b5-4879-8636-f69cb1387a9d?type=property-photo", "name": "529253340.jpg", "type": "property_photo", "fileName": "529253340.jpg", "filePath": "/api/local-object/download/12caf16a-89b5-4879-8636-f69cb1387a9d?type=property-photo", "fileSize": 13584, "mimeType": "image/jpeg", "documentType": "property_photo"}]	HP-HST-2025-40807	2025-12-12 16:14:11.33	2026-12-12 16:14:11.33	2025-12-12 15:54:02.586	2025-12-12 16:14:11.33	2025-12-12 15:50:26.958263	2025-12-12 16:14:11.33	paid	A25L211911	1.00	2025-12-12 00:00:00	\N	\N	{"pineForest": true, "historicFort": true, "campingGround": true, "buddhistMonastery": true}	0	\N	\N	homestay
cefe6037-d38c-4923-a2d4-cdac09d844c6	62bed697-2b04-4591-a351-82d7611368f9	LG-HS-2025-SML-000001	renewal	\N	18-1558/2025-DTDO-SML	18-1558/2025-DTDO-SML	\N	{"requestedRooms": {"total": 1}, "requiresPayment": false, "legacyOnboarding": true, "legacyGuardianName": "Sh. Durga Singh Thakur", "inheritsCertificateExpiry": "2026-12-09T00:00:00.000Z"}	Existing owner onboarding request captured on 12/12/2025 with RC #18-1558/2025-DTDO-SML.	\N	Draft Homestay	silver	gp	1	Shimla	\N	Chaupal	\N	\N	\N	\N	\N	\N	\N	\N	Sondh Niwas, Near Saw Mill,\nLower Lakkar Bazar,	171001	\N	\N	\N	\N	Test HHH	other	6666666682	microaistudio@gmail.com	Sh. Durga Singh Thakur	666666666682	owned	\N	existing_property	50.00	1	1	\N	\N	0	2	\N	\N	0	4	\N	\N	1	\N	\N	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"size": 0, "count": 1, "roomType": "Declared Rooms"}]	\N	\N	0.00	0.00	0.00	0.00	\N	\N	\N	approved	final	1	\N	\N	\N	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 20:28:12.768	\N	approved	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	18-1558/2025-DTDO-SML	2025-12-10 00:00:00	2026-12-09 00:00:00	2025-12-12 20:27:02.248	2025-12-12 20:28:12.768	2025-12-12 20:08:45.36	2025-12-12 20:28:12.768	pending	\N	\N	\N	\N	\N	\N	0	\N	\N	homestay
51d001ef-5f57-479f-84fa-4a07c69c410f	e0e74d53-cd5a-4746-a125-8951e18e7764	ADV-1765742513952-2WUHXO	new_registration	\N	\N	\N	\N	\N	\N	\N	New Application	gold	gp	0		\N		\N	\N	\N	\N	\N	\N	\N	\N			\N	\N	\N	\N	Test  XXX	male	6666666683	microaistudio@gmail.com	\N	666666666683	owned	\N	new_property	0.00	0	1	\N	\N	0	2	\N	\N	0	4	\N	\N	0	\N	\N	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0.00	0.00	0.00	0.00	\N	\N	\N	draft	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-12-14 20:01:53.956822	2025-12-14 20:01:53.956822	pending	\N	\N	\N	\N	\N	\N	0	{"activity": "paddle_boat", "district": "", "manpower": [], "equipment": [], "activities": [], "activityType": "non_motorized", "operatorName": "", "operatorType": "individual", "trainedStaff": [], "waterBodyName": "", "totalAnnualFee": 0, "areaOfOperation": "", "insurancePolicy": {"provider": "", "validFrom": "", "validUpto": "", "policyNumber": "", "coverageAmount": 0}, "safetyEquipment": [], "activityCategory": "water_sports", "emergencyProtocols": {"rescueTeamAvailable": false, "medicalFacilityTieup": "", "emergencyContactNumber": "", "evacuationPlanUploaded": false, "medicalFacilityDistance": 0, "weatherMonitoringSystem": false}, "localOfficeAddress": "", "operatingLocations": [], "minimumInsuranceRequired": 0}	\N	adventure_sports
12312844-8422-4921-9a19-cc7253d9d6eb	e0e74d53-cd5a-4746-a125-8951e18e7764	ADV-1765742546762-YPI7T8	new_registration	\N	\N	\N	\N	\N	\N	\N	Test	gold	gp	0	Shimla	\N		\N	\N	\N	\N	\N	\N	\N	\N	House 112		\N	\N	\N	\N	Test  XXX	male	6666666683	microaistudio@gmail.com	\N	666666666683	owned	\N	new_property	0.00	0	1	\N	\N	0	2	\N	\N	0	4	\N	\N	0	\N	\N	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0.00	0.00	0.00	0.00	\N	\N	\N	draft	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-12-14 20:02:26.765958	2025-12-14 20:02:26.765958	pending	\N	\N	\N	\N	\N	\N	0	{"activity": "paddle_boat", "district": "Shimla", "manpower": [], "equipment": [], "activities": [], "activityType": "non_motorized", "operatorName": "Test", "operatorType": "individual", "trainedStaff": [], "waterBodyName": "Test Lake", "totalAnnualFee": 0, "areaOfOperation": "Test test", "insurancePolicy": {"provider": "", "validFrom": "", "validUpto": "", "policyNumber": "", "coverageAmount": 0}, "safetyEquipment": [], "activityCategory": "water_sports", "emergencyProtocols": {"rescueTeamAvailable": false, "medicalFacilityTieup": "", "emergencyContactNumber": "", "evacuationPlanUploaded": false, "medicalFacilityDistance": 0, "weatherMonitoringSystem": false}, "localOfficeAddress": "House 112", "operatingLocations": [], "minimumInsuranceRequired": 0}	\N	adventure_sports
fc6118a8-dd8f-46a9-83ce-5fb121496b4b	e0e74d53-cd5a-4746-a125-8951e18e7764	ADV-1765742566855-KAAKD7	new_registration	\N	\N	\N	\N	\N	\N	\N	Test	gold	gp	0	Shimla	\N		\N	\N	\N	\N	\N	\N	\N	\N	House 112		\N	\N	\N	\N	Test  XXX	male	6666666683	microaistudio@gmail.com	\N	666666666683	owned	\N	new_property	0.00	0	1	\N	\N	0	2	\N	\N	0	4	\N	\N	0	\N	\N	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0.00	0.00	0.00	0.00	\N	\N	\N	draft	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-12-14 20:02:46.857546	2025-12-14 20:02:46.857546	pending	\N	\N	\N	\N	\N	\N	0	{"activity": "paddle_boat", "district": "Shimla", "manpower": [], "equipment": [{"type": "paddle_boat", "manufacturer": "", "safetyEquipment": {"lifebuoys": 2, "firstAidKit": true, "lifeJackets": 4}, "identificationNo": "", "yearOfManufacture": "2025"}, {"type": "paddle_boat", "manufacturer": "", "safetyEquipment": {"lifebuoys": 2, "firstAidKit": true, "lifeJackets": 4}, "identificationNo": "", "yearOfManufacture": "2025"}, {"type": "paddle_boat", "manufacturer": "", "safetyEquipment": {"lifebuoys": 2, "firstAidKit": true, "lifeJackets": 4}, "identificationNo": "", "yearOfManufacture": "2025"}], "activities": [], "activityType": "non_motorized", "operatorName": "Test", "operatorType": "individual", "trainedStaff": [], "waterBodyName": "Test Lake", "totalAnnualFee": 0, "areaOfOperation": "Test test", "insurancePolicy": {"provider": "", "validFrom": "", "validUpto": "", "policyNumber": "", "coverageAmount": 0}, "safetyEquipment": [], "activityCategory": "water_sports", "emergencyProtocols": {"rescueTeamAvailable": false, "medicalFacilityTieup": "", "emergencyContactNumber": "", "evacuationPlanUploaded": false, "medicalFacilityDistance": 0, "weatherMonitoringSystem": false}, "localOfficeAddress": "House 112", "operatingLocations": [], "minimumInsuranceRequired": 0}	\N	adventure_sports
5cdd06c3-2fd5-48bc-b300-54bd4d4537bb	7b64dd49-04e2-4afe-86bb-2fa6c2d17816	HP-HS-2025-SML-000003	new_registration	\N	\N	\N	\N	\N	\N	\N	Draft Homestay	gold	mc	1	Shimla	\N	Deha	\N					Shimla			Sondh Niwas, Near Saw Mill,\nLower Lakkar Bazar,	171001	08091441005	\N	\N	\N	Subhash Thakur	male	8091443005	subhash.thakur2010@gmail.com	\N	666666665682	owned	0.00	new_project	0.00	1	1	0.00	3550.00	0	2	0.00	0.00	0	4	0.00	0.00	1	111111111111133	gold	0.00	0.00	0.00	1	f	0.00	0.00	0.00	0.00	0.00	0.00	0.00						{"cctv": true, "parking": true, "hotWater": true, "fireSafety": true, "restaurant": true}	\N	12000.00	12000.00	0.00	0.00	0.00	0.00	12000.00	0.00	0.00	draft	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "aa880c7d-1041-432d-bfb5-f5572560700d", "url": "/api/local-object/download/e7830124-53be-4b0c-9ee0-4e4228829426?type=revenue-papers", "name": "01.pdf", "type": "revenue_papers", "fileName": "01.pdf", "filePath": "/api/local-object/download/e7830124-53be-4b0c-9ee0-4e4228829426?type=revenue-papers", "fileSize": 304514, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "5f8197ce-ae0e-4753-b6d4-0c5c0463a354", "url": "/api/local-object/download/c4c6e0d6-cd95-4d59-8dd0-3c5194d4375b?type=affidavit-section29", "name": "01.pdf", "type": "affidavit_section_29", "fileName": "01.pdf", "filePath": "/api/local-object/download/c4c6e0d6-cd95-4d59-8dd0-3c5194d4375b?type=affidavit-section29", "fileSize": 304514, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "5cf59495-8a4b-4714-978e-2a460094169e", "url": "/api/local-object/download/0039a457-6f8f-4b81-b326-48077d2aa17d?type=undertaking-form-c", "name": "01.pdf", "type": "undertaking_form_c", "fileName": "01.pdf", "filePath": "/api/local-object/download/0039a457-6f8f-4b81-b326-48077d2aa17d?type=undertaking-form-c", "fileSize": 304514, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "55235c54-c1b1-4a04-b50a-9f5aa459bc7d", "url": "/api/local-object/download/af5dae27-4eca-45a9-8db0-dc5b3f0b0ac9?type=commercial-electricity-bill", "name": "01.pdf", "type": "commercial_electricity_bill", "fileName": "01.pdf", "filePath": "/api/local-object/download/af5dae27-4eca-45a9-8db0-dc5b3f0b0ac9?type=commercial-electricity-bill", "fileSize": 304514, "mimeType": "application/pdf", "documentType": "commercial_electricity_bill"}, {"id": "fb709290-56d4-42ae-9deb-54c7d686ae32", "url": "/api/local-object/download/b3ee96ee-30fd-42ac-8e8d-691ee2953327?type=commercial-water-bill", "name": "01.pdf", "type": "commercial_water_bill", "fileName": "01.pdf", "filePath": "/api/local-object/download/b3ee96ee-30fd-42ac-8e8d-691ee2953327?type=commercial-water-bill", "fileSize": 304514, "mimeType": "application/pdf", "documentType": "commercial_water_bill"}, {"id": "48a4ffc3-10eb-470d-a90d-0a127df84bbe", "url": "/api/local-object/download/2cbb1f92-8a33-43e8-8141-5442c09c8796?type=property-photo", "name": "01.pdf", "type": "property_photo", "fileName": "01.pdf", "filePath": "/api/local-object/download/2cbb1f92-8a33-43e8-8141-5442c09c8796?type=property-photo", "fileSize": 304514, "mimeType": "application/pdf", "documentType": "property_photo"}, {"id": "4c933cb1-9699-4bdc-9129-4d387056f712", "url": "/api/local-object/download/7a2fada3-1d12-4e2d-8cda-090557cc93e6?type=property-photo", "name": "01.pdf", "type": "property_photo", "fileName": "01.pdf", "filePath": "/api/local-object/download/7a2fada3-1d12-4e2d-8cda-090557cc93e6?type=property-photo", "fileSize": 304514, "mimeType": "application/pdf", "documentType": "property_photo"}]	\N	\N	\N	\N	\N	2025-12-13 11:35:03.835708	2025-12-13 11:37:15.875	pending	\N	\N	\N	\N	\N	{"viewpoint": true, "waterfall": true, "pineForest": true, "fishingSpot": true, "hikingTrail": true, "riverStream": true, "historicFort": true, "historicTemple": true, "paraglidingSite": true, "handicraftMarket": true, "buddhistMonastery": true}	0	\N	\N	homestay
0db595cb-2a27-4297-872a-c3237fc7d8a1	e0e74d53-cd5a-4746-a125-8951e18e7764	ADV-1765742508980-GW66AE	new_registration	\N	\N	\N	\N	\N	\N	\N	New Application	gold	gp	0		\N		\N	\N	\N	\N	\N	\N	\N	\N			\N	\N	\N	\N	Test  XXX	male	6666666683	microaistudio@gmail.com	\N	666666666683	owned	\N	new_property	0.00	0	1	\N	\N	0	2	\N	\N	0	4	\N	\N	0	\N	\N	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0.00	0.00	0.00	0.00	\N	\N	\N	draft	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-12-14 20:01:48.985759	2025-12-14 20:01:48.985759	pending	\N	\N	\N	\N	\N	\N	0	{"activity": "paddle_boat", "district": "", "manpower": [], "equipment": [], "activities": [], "activityType": "non_motorized", "operatorName": "", "operatorType": "individual", "trainedStaff": [], "waterBodyName": "", "totalAnnualFee": 0, "areaOfOperation": "", "insurancePolicy": {"provider": "", "validFrom": "", "validUpto": "", "policyNumber": "", "coverageAmount": 0}, "safetyEquipment": [], "activityCategory": "water_sports", "emergencyProtocols": {"rescueTeamAvailable": false, "medicalFacilityTieup": "", "emergencyContactNumber": "", "evacuationPlanUploaded": false, "medicalFacilityDistance": 0, "weatherMonitoringSystem": false}, "localOfficeAddress": "", "operatingLocations": [], "minimumInsuranceRequired": 0}	\N	adventure_sports
884b1f97-cc3e-411b-ba32-12adc0b4878a	e0e74d53-cd5a-4746-a125-8951e18e7764	ADV-1765742633978-NYA5OX	new_registration	\N	\N	\N	\N	\N	\N	\N	Test	gold	gp	0	Shimla	\N		\N	\N	\N	\N	\N	\N	\N	\N	House 112		\N	\N	\N	\N	Test  XXX	male	6666666683	microaistudio@gmail.com	\N	666666666683	owned	\N	new_property	0.00	0	1	\N	\N	0	2	\N	\N	0	4	\N	\N	0	\N	\N	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0.00	0.00	0.00	0.00	\N	\N	\N	draft	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-12-14 20:03:53.982676	2025-12-14 20:03:53.982676	pending	\N	\N	\N	\N	\N	\N	0	{"activity": "paddle_boat", "district": "Shimla", "manpower": [{"dob": "2000-01-01", "name": "Test", "role": "boatman", "registrationNo": "", "firstAidCertified": true}], "equipment": [{"type": "paddle_boat", "manufacturer": "", "safetyEquipment": {"lifebuoys": 2, "firstAidKit": true, "lifeJackets": 4}, "identificationNo": "", "yearOfManufacture": "2025"}, {"type": "paddle_boat", "manufacturer": "", "safetyEquipment": {"lifebuoys": 2, "firstAidKit": true, "lifeJackets": 4}, "identificationNo": "", "yearOfManufacture": "2025"}, {"type": "paddle_boat", "manufacturer": "", "safetyEquipment": {"lifebuoys": 2, "firstAidKit": true, "lifeJackets": 4}, "identificationNo": "", "yearOfManufacture": "2025"}], "activities": [], "activityType": "non_motorized", "operatorName": "Test", "operatorType": "individual", "trainedStaff": [], "waterBodyName": "Test Lake", "totalAnnualFee": 0, "areaOfOperation": "Test test", "insurancePolicy": {"provider": "", "validFrom": "", "validUpto": "", "policyNumber": "", "coverageAmount": 0}, "safetyEquipment": [], "activityCategory": "water_sports", "emergencyProtocols": {"rescueTeamAvailable": false, "medicalFacilityTieup": "", "emergencyContactNumber": "", "evacuationPlanUploaded": false, "medicalFacilityDistance": 0, "weatherMonitoringSystem": false}, "localOfficeAddress": "House 112", "operatingLocations": [], "minimumInsuranceRequired": 0}	\N	adventure_sports
639f05ba-04fc-4d42-9d6c-5cff7bd5c812	e0e74d53-cd5a-4746-a125-8951e18e7764	ADV-1765742635090-2U5C46	new_registration	\N	\N	\N	\N	\N	\N	\N	Test	gold	gp	0	Shimla	\N		\N	\N	\N	\N	\N	\N	\N	\N	House 112		\N	\N	\N	\N	Test  XXX	male	6666666683	microaistudio@gmail.com	\N	666666666683	owned	\N	new_property	0.00	0	1	\N	\N	0	2	\N	\N	0	4	\N	\N	0	\N	\N	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0.00	0.00	0.00	0.00	\N	\N	\N	draft	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-12-14 20:03:55.093899	2025-12-14 20:03:55.093899	pending	\N	\N	\N	\N	\N	\N	0	{"activity": "paddle_boat", "district": "Shimla", "manpower": [{"dob": "2000-01-01", "name": "Test", "role": "boatman", "registrationNo": "", "firstAidCertified": true}], "equipment": [{"type": "paddle_boat", "manufacturer": "", "safetyEquipment": {"lifebuoys": 2, "firstAidKit": true, "lifeJackets": 4}, "identificationNo": "", "yearOfManufacture": "2025"}, {"type": "paddle_boat", "manufacturer": "", "safetyEquipment": {"lifebuoys": 2, "firstAidKit": true, "lifeJackets": 4}, "identificationNo": "", "yearOfManufacture": "2025"}, {"type": "paddle_boat", "manufacturer": "", "safetyEquipment": {"lifebuoys": 2, "firstAidKit": true, "lifeJackets": 4}, "identificationNo": "", "yearOfManufacture": "2025"}], "activities": [], "activityType": "non_motorized", "operatorName": "Test", "operatorType": "individual", "trainedStaff": [], "waterBodyName": "Test Lake", "totalAnnualFee": 0, "areaOfOperation": "Test test", "insurancePolicy": {"provider": "", "validFrom": "", "validUpto": "", "policyNumber": "", "coverageAmount": 0}, "safetyEquipment": [], "activityCategory": "water_sports", "emergencyProtocols": {"rescueTeamAvailable": false, "medicalFacilityTieup": "", "emergencyContactNumber": "", "evacuationPlanUploaded": false, "medicalFacilityDistance": 0, "weatherMonitoringSystem": false}, "localOfficeAddress": "House 112", "operatingLocations": [], "minimumInsuranceRequired": 0}	\N	adventure_sports
d7c03c91-c966-4910-90e7-a3a43adac3a1	e0e74d53-cd5a-4746-a125-8951e18e7764	ADV-1765742673660-PEIMJ6	new_registration	\N	\N	\N	\N	\N	\N	\N	Test	gold	gp	0	Shimla	\N		\N	\N	\N	\N	\N	\N	\N	\N	House 112		\N	\N	\N	\N	Test  XXX	male	6666666683	microaistudio@gmail.com	\N	666666666683	owned	\N	new_property	0.00	0	1	\N	\N	0	2	\N	\N	0	4	\N	\N	0	\N	\N	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0.00	0.00	0.00	0.00	\N	\N	\N	draft	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-12-14 20:04:33.663223	2025-12-14 20:04:33.663223	pending	\N	\N	\N	\N	\N	\N	0	{"activity": "paddle_boat", "district": "Shimla", "manpower": [{"dob": "2000-01-01", "name": "Test", "role": "boatman", "registrationNo": "", "firstAidCertified": true}], "equipment": [{"type": "paddle_boat", "manufacturer": "", "safetyEquipment": {"lifebuoys": 2, "firstAidKit": true, "lifeJackets": 4}, "identificationNo": "", "yearOfManufacture": "2025"}, {"type": "paddle_boat", "manufacturer": "", "safetyEquipment": {"lifebuoys": 2, "firstAidKit": true, "lifeJackets": 4}, "identificationNo": "", "yearOfManufacture": "2025"}, {"type": "paddle_boat", "manufacturer": "", "safetyEquipment": {"lifebuoys": 2, "firstAidKit": true, "lifeJackets": 4}, "identificationNo": "", "yearOfManufacture": "2025"}], "activities": [], "activityType": "non_motorized", "operatorName": "Test", "operatorType": "individual", "trainedStaff": [], "waterBodyName": "Test Lake", "totalAnnualFee": 0, "areaOfOperation": "Test test", "insurancePolicy": {"provider": "", "validFrom": "", "validUpto": "", "policyNumber": "", "coverageAmount": 0}, "safetyEquipment": [], "activityCategory": "water_sports", "emergencyProtocols": {"rescueTeamAvailable": false, "medicalFacilityTieup": "", "emergencyContactNumber": "", "evacuationPlanUploaded": false, "medicalFacilityDistance": 0, "weatherMonitoringSystem": false}, "localOfficeAddress": "House 112", "operatingLocations": [], "minimumInsuranceRequired": 0}	\N	adventure_sports
9c5ac53d-61b7-4b8c-bfee-e7d0fa66bd42	e0e74d53-cd5a-4746-a125-8951e18e7764	ADV-1765743819433-OYAQG6	new_registration	\N	\N	\N	\N	\N	\N	\N	Test	gold	gp	0	Shimla	\N		\N	\N	\N	\N	\N	\N	\N	\N	Local Office Address 		\N	\N	\N	\N	Test  XXX	male	6666666683	microaistudio@gmail.com	\N	666666666683	owned	\N	new_property	0.00	0	1	\N	\N	0	2	\N	\N	0	4	\N	\N	0	\N	\N	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0.00	0.00	0.00	0.00	\N	\N	\N	draft	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-12-14 20:23:39.437972	2025-12-14 20:23:39.437972	pending	\N	\N	\N	\N	\N	\N	0	{"activity": "paddle_boat", "district": "Shimla", "manpower": [], "equipment": [], "activities": [], "activityType": "non_motorized", "operatorName": "Test", "operatorType": "individual", "trainedStaff": [], "waterBodyName": "Test Lake", "totalAnnualFee": 0, "areaOfOperation": "Specific Area of Operation", "insurancePolicy": {"provider": "", "validFrom": "", "validUpto": "", "policyNumber": "", "coverageAmount": 0}, "safetyEquipment": [], "activityCategory": "water_sports", "emergencyProtocols": {"rescueTeamAvailable": false, "medicalFacilityTieup": "", "emergencyContactNumber": "", "evacuationPlanUploaded": false, "medicalFacilityDistance": 0, "weatherMonitoringSystem": false}, "localOfficeAddress": "Local Office Address ", "operatingLocations": [], "minimumInsuranceRequired": 0}	\N	adventure_sports
bb6da122-d11d-41fc-b553-fd9160e353b9	e0e74d53-cd5a-4746-a125-8951e18e7764	ADV-1765743845010-WYVS4V	new_registration	\N	\N	\N	\N	\N	\N	\N	Test	gold	gp	0	Shimla	\N		\N	\N	\N	\N	\N	\N	\N	\N	Local Office Address 		\N	\N	\N	\N	Test  XXX	male	6666666683	microaistudio@gmail.com	\N	666666666683	owned	\N	new_property	0.00	0	1	\N	\N	0	2	\N	\N	0	4	\N	\N	0	\N	\N	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0.00	0.00	0.00	0.00	\N	\N	\N	draft	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-12-14 20:24:05.012034	2025-12-14 20:24:05.012034	pending	\N	\N	\N	\N	\N	\N	0	{"activity": "paddle_boat", "district": "Shimla", "manpower": [{"dob": "2025-12-04", "name": "Test", "role": "boatman", "registrationNo": "", "firstAidCertified": true}], "equipment": [{"type": "paddle_boat", "manufacturer": "", "safetyEquipment": {"lifebuoys": 2, "firstAidKit": true, "lifeJackets": 4}, "identificationNo": "", "yearOfManufacture": "2025"}, {"type": "paddle_boat", "manufacturer": "", "safetyEquipment": {"lifebuoys": 2, "firstAidKit": true, "lifeJackets": 4}, "identificationNo": "", "yearOfManufacture": "2025"}, {"type": "paddle_boat", "manufacturer": "", "safetyEquipment": {"lifebuoys": 2, "firstAidKit": true, "lifeJackets": 4}, "identificationNo": "", "yearOfManufacture": "2025"}], "activities": [], "activityType": "non_motorized", "operatorName": "Test", "operatorType": "individual", "trainedStaff": [], "waterBodyName": "Test Lake", "totalAnnualFee": 0, "areaOfOperation": "Specific Area of Operation", "insurancePolicy": {"provider": "", "validFrom": "", "validUpto": "", "policyNumber": "", "coverageAmount": 0}, "safetyEquipment": [], "activityCategory": "water_sports", "emergencyProtocols": {"rescueTeamAvailable": false, "medicalFacilityTieup": "", "emergencyContactNumber": "", "evacuationPlanUploaded": false, "medicalFacilityDistance": 0, "weatherMonitoringSystem": false}, "localOfficeAddress": "Local Office Address ", "operatingLocations": [], "minimumInsuranceRequired": 0}	\N	adventure_sports
217d5a95-b9e2-4a4a-bdb1-46656a74b3c4	e0e74d53-cd5a-4746-a125-8951e18e7764	ADV-1765743847417-V2H2XE	new_registration	\N	\N	\N	\N	\N	\N	\N	Test	gold	gp	0	Shimla	\N		\N	\N	\N	\N	\N	\N	\N	\N	Local Office Address 		\N	\N	\N	\N	Test  XXX	male	6666666683	microaistudio@gmail.com	\N	666666666683	owned	\N	new_property	0.00	0	1	\N	\N	0	2	\N	\N	0	4	\N	\N	0	\N	\N	\N	\N	\N	1	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0.00	0.00	0.00	0.00	\N	\N	\N	submitted	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-12-14 20:24:07.422358	2025-12-14 20:24:07.465	pending	\N	\N	\N	\N	\N	\N	0	{"activity": "paddle_boat", "district": "Shimla", "manpower": [{"dob": "2025-12-04", "name": "Test", "role": "boatman", "registrationNo": "", "firstAidCertified": true}], "equipment": [{"type": "paddle_boat", "manufacturer": "", "safetyEquipment": {"lifebuoys": 2, "firstAidKit": true, "lifeJackets": 4}, "identificationNo": "", "yearOfManufacture": "2025"}, {"type": "paddle_boat", "manufacturer": "", "safetyEquipment": {"lifebuoys": 2, "firstAidKit": true, "lifeJackets": 4}, "identificationNo": "", "yearOfManufacture": "2025"}, {"type": "paddle_boat", "manufacturer": "", "safetyEquipment": {"lifebuoys": 2, "firstAidKit": true, "lifeJackets": 4}, "identificationNo": "", "yearOfManufacture": "2025"}], "activities": [], "activityType": "non_motorized", "operatorName": "Test", "operatorType": "individual", "trainedStaff": [], "waterBodyName": "Test Lake", "totalAnnualFee": 0, "areaOfOperation": "Specific Area of Operation", "insurancePolicy": {"provider": "", "validFrom": "", "validUpto": "", "policyNumber": "", "coverageAmount": 0}, "safetyEquipment": [], "activityCategory": "water_sports", "emergencyProtocols": {"rescueTeamAvailable": false, "medicalFacilityTieup": "", "emergencyContactNumber": "", "evacuationPlanUploaded": false, "medicalFacilityDistance": 0, "weatherMonitoringSystem": false}, "localOfficeAddress": "Local Office Address ", "operatingLocations": [], "minimumInsuranceRequired": 0}	\N	adventure_sports
ba1a9a91-3dd0-4daf-b16b-c338b3d9ccb5	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	HP-HS-2025-SML-000047	add_rooms	ee6d41b1-3ed6-41b2-ac77-7bebf0ffa061	HP-HS-2025-SML-000001	HP-HST-2025-75313	\N	\N	\N	\N	Dreamland Resorts	gold	gp	3	Shimla	\N	Chaupal	\N			Village AAA					Shiva Apartment L 2 Checkrail, Near I VY School, Shimla,	171001		\N	\N	\N	Test AAAA	male	8091441005	test@test.com	\N	666666666671	owned	0.00	new_project	0.00	3	1	0.00	3500.00	0	2	0.00	0.00	0	4	0.00	0.00	3	111111111111112	gold	0.00	0.00	0.00	1	f	0.00	0.00	0.00	0.00	0.00	0.00	0.00						{"cctv": true, "fireSafety": true}	\N	6000.00	6000.00	0.00	0.00	0.00	0.00	6000.00	0.00	0.00	approved	inspection_completed	6	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	2025-12-17 09:39:28.009	Verify for Payment\nThe owner will be allowed to proceed with payment.	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-17 08:46:04.263	2025-12-17 08:46:04.263	Approve	\N	\N	\N	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	2025-12-17 09:15:12.111	0	Inspection	\N	\N	2025-12-20 07:00:00	2025-12-17 09:39:07.097	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	Findings & Recommendation\nOverall Inspection Summary *	recommended	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"id": "dd995b61-5fe5-44ba-b02c-9313c1f6abcb", "url": "/api/local-object/download/013e11ad-845b-447d-885c-926f3067f4cc?type=revenue-papers", "name": "Test_Doc01-Hindi.pdf", "type": "revenue_papers", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/013e11ad-845b-447d-885c-926f3067f4cc?type=revenue-papers", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "revenue_papers"}, {"id": "09d539e8-4534-4372-918b-289d21740dfe", "url": "/api/local-object/download/565ef2ce-ca03-4edc-8454-d90d78e3e9d1?type=affidavit-section29", "name": "Test_Doc01-Hindi.pdf", "type": "affidavit_section_29", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/565ef2ce-ca03-4edc-8454-d90d78e3e9d1?type=affidavit-section29", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "affidavit_section_29"}, {"id": "b9cc5a95-2ebc-44df-9fb1-d3260b1f801a", "url": "/api/local-object/download/9a6b2fc0-eb31-44cf-9e4f-e4935d4ef03d?type=undertaking-form-c", "name": "Test_Doc01-Hindi.pdf", "type": "undertaking_form_c", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/9a6b2fc0-eb31-44cf-9e4f-e4935d4ef03d?type=undertaking-form-c", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "undertaking_form_c"}, {"id": "ece73286-0ddd-4b83-b710-360797b3c642", "url": "/api/local-object/download/02f0fb1f-f89b-46ef-ad4a-6ba1c58b38df?type=commercial-electricity-bill", "name": "Test_Doc01-Hindi.pdf", "type": "commercial_electricity_bill", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/02f0fb1f-f89b-46ef-ad4a-6ba1c58b38df?type=commercial-electricity-bill", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "commercial_electricity_bill"}, {"id": "33ffc7b5-ef36-427b-b6e4-f41928872a95", "url": "/api/local-object/download/8667a2d6-ce4d-4f57-8cc6-fbae38534505?type=commercial-water-bill", "name": "Test_Doc01-Hindi.pdf", "type": "commercial_water_bill", "fileName": "Test_Doc01-Hindi.pdf", "filePath": "/api/local-object/download/8667a2d6-ce4d-4f57-8cc6-fbae38534505?type=commercial-water-bill", "fileSize": 61398, "mimeType": "application/pdf", "documentType": "commercial_water_bill"}, {"id": "82a9386e-9b04-4f54-8239-938645d0a6b7", "url": "/api/local-object/download/9e3a5565-8184-4c45-b3d6-08154794dfc8?type=property-photo", "name": "519109575.jpg", "type": "property_photo", "fileName": "519109575.jpg", "filePath": "/api/local-object/download/9e3a5565-8184-4c45-b3d6-08154794dfc8?type=property-photo", "fileSize": 96524, "mimeType": "image/jpeg", "documentType": "property_photo"}, {"id": "ad818d93-bc24-4db6-8081-2d381539ed6a", "url": "/api/local-object/download/b8043eca-7018-41fb-844c-92cb7838cdc2?type=property-photo", "name": "529253340.jpg", "type": "property_photo", "fileName": "529253340.jpg", "filePath": "/api/local-object/download/b8043eca-7018-41fb-844c-92cb7838cdc2?type=property-photo", "fileSize": 13584, "mimeType": "image/jpeg", "documentType": "property_photo"}]	HP-HST-2025-51418	2025-12-17 09:39:28.009	2026-12-17 09:39:28.009	2025-12-17 06:51:44.983	2025-12-17 09:39:28.009	2025-12-17 06:43:12.705363	2025-12-17 09:39:28.009	paid	A25L243556	1.00	2025-12-17 00:00:00	\N	\N	{"snowPoint": true, "viewpoint": true, "lakeBoating": true, "riverStream": true, "appleOrchards": true, "campingGround": true, "historicTemple": true, "handicraftMarket": true, "buddhistMonastery": true}	0	\N	\N	homestay
1ad86745-e4d9-4099-ab73-7434ff2d425e	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	HP-HS-2025-SML-000048	change_category	ee6d41b1-3ed6-41b2-ac77-7bebf0ffa061	HP-HS-2025-SML-000001	HP-HST-2025-75313	\N	\N	\N	\N	Dreamland Resorts	gold	gp	1	Shimla	\N	Chaupal	\N			Village AAA					Shiva Apartment L 2 Checkrail, Near I VY School, Shimla,	171001		\N	\N	\N	Test AAAA	other	8091441005	test@test.com	\N	666666666671	owned	\N	new_project	0.00	1	1	0.00	3500.00	0	2	0.00	0.00	0	4	0.00	0.00	1		gold	0.00	0.00	0.00	1	f	0.00	0.00	0.00	0.00	0.00	0.00	0.00						\N	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	draft	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	[]	\N	\N	\N	\N	\N	2025-12-17 18:39:02.501866	2025-12-17 18:39:02.501866	pending	\N	\N	\N	\N	\N	\N	0	\N	\N	homestay
\.


--
-- Data for Name: inspection_orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inspection_orders (id, application_id, scheduled_by, scheduled_date, assigned_to, assigned_date, inspection_date, inspection_address, special_instructions, status, dtdo_notes, created_at, updated_at) FROM stdin;
1b30f000-cf74-4624-9118-64f53b8a1de7	ee6d41b1-3ed6-41b2-ac77-7bebf0ffa061	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	2025-12-12 11:21:57.104	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 11:21:57.104	2025-12-15 06:00:00	Shiva Apartment L 2 Checkrail, Near I VY School, Shimla,	\N	completed	\N	2025-12-12 11:21:57.105527	2025-12-12 11:22:39.882
6882ee24-c2d8-420c-8b77-50077d52a9bf	44b8281c-c332-476c-9f9c-14766a4a208a	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	2025-12-12 16:11:14.141	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 16:11:14.141	2025-12-15 04:30:00	Test Property  \nAddress	\N	completed	\N	2025-12-12 16:11:14.142247	2025-12-12 16:13:43.878
71d7e29b-f2fb-4ecc-9fb1-3a580777ca47	ba1a9a91-3dd0-4daf-b16b-c338b3d9ccb5	3b2fa85b-806a-44b8-93ce-07ad7aa8a842	2025-12-17 09:15:24.337	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-17 09:15:24.337	2025-12-20 07:00:00	Shiva Apartment L 2 Checkrail, Near I VY School, Shimla,	\N	completed	\N	2025-12-17 09:15:24.338025	2025-12-17 09:39:07.089
\.


--
-- Data for Name: inspection_reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inspection_reports (id, inspection_order_id, application_id, submitted_by, submitted_date, actual_inspection_date, room_count_verified, actual_room_count, category_meets_standards, recommended_category, mandatory_checklist, mandatory_remarks, desirable_checklist, desirable_remarks, amenities_verified, amenities_issues, fire_safety_compliant, fire_safety_issues, structural_safety, structural_issues, overall_satisfactory, recommendation, detailed_findings, inspection_photos, report_document_url, created_at, updated_at) FROM stdin;
83173430-d249-49de-99b8-19377249311c	1b30f000-cf74-4624-9118-64f53b8a1de7	ee6d41b1-3ed6-41b2-ac77-7bebf0ffa061	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 11:22:39.876	2025-12-11 00:00:00	t	\N	t	\N	{"roomSize": true, "documents": true, "cleanRooms": true, "cctvCameras": true, "visitorBook": true, "cleanKitchen": true, "doctorDetails": true, "fireEquipment": true, "guestRegister": true, "onlinePayment": true, "wasteDisposal": true, "waterFacility": true, "wellMaintained": true, "applicationForm": true, "cutleryCrockery": true, "luggageAssistance": true, "comfortableBedding": true, "energySavingLights": true}	Early inspection override: Conducted 4 days before the scheduled date (December 15th, 2025). Reason: Log Earlier Visit\nEnable if the physical inspection happened up to 7 days before the scheduled date.	{"lounge": false, "laundry": false, "parking": false, "storage": false, "wardrobe": false, "furniture": false, "diningArea": false, "luggageHelp": false, "safeStorage": false, "hotColdWater": false, "refrigerator": false, "securityGuard": false, "heatingCooling": false, "himachaliCrafts": false, "toiletAmenities": false, "attachedBathroom": false, "waterConservation": false, "rainwaterHarvesting": false}	\N	\N	\N	f	\N	f	\N	t	approve	Findings & Recommendation\nOverall Inspection Summary *\nCapture the key highlights of this visit (minimum 20 characters). This summary is stored with the RC.	\N	\N	2025-12-12 11:22:39.879854	2025-12-12 11:22:39.879854
f615ed73-141a-4735-ad37-23d825a812d0	6882ee24-c2d8-420c-8b77-50077d52a9bf	44b8281c-c332-476c-9f9c-14766a4a208a	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-12 16:13:43.872	2025-12-10 00:00:00	t	\N	t	\N	{"roomSize": true, "documents": true, "cleanRooms": true, "cctvCameras": true, "visitorBook": true, "cleanKitchen": true, "doctorDetails": true, "fireEquipment": true, "guestRegister": true, "onlinePayment": true, "wasteDisposal": true, "waterFacility": true, "wellMaintained": true, "applicationForm": true, "cutleryCrockery": true, "luggageAssistance": true, "comfortableBedding": true, "energySavingLights": true}	Early inspection override: Conducted 5 days before the scheduled date (December 15th, 2025). Reason: Log Earlier Visit\nEnable if the physical inspection happened up to 7 days before the scheduled date.	{"lounge": false, "laundry": false, "parking": false, "storage": false, "wardrobe": false, "furniture": false, "diningArea": false, "luggageHelp": false, "safeStorage": false, "hotColdWater": false, "refrigerator": false, "securityGuard": false, "heatingCooling": false, "himachaliCrafts": false, "toiletAmenities": false, "attachedBathroom": false, "waterConservation": false, "rainwaterHarvesting": false}	\N	\N	\N	f	\N	f	\N	t	approve	Findings & Recommendation\nOverall Inspection Summary *\nCapture the key highlights of this visit (minimum 20 characters). This summary is stored with the RC.	\N	\N	2025-12-12 16:13:43.875973	2025-12-12 16:13:43.875973
4c9dafda-62be-4d00-83b5-35846fec7ce6	71d7e29b-f2fb-4ecc-9fb1-3a580777ca47	ba1a9a91-3dd0-4daf-b16b-c338b3d9ccb5	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	2025-12-17 09:39:07.079	2025-12-16 00:00:00	t	\N	t	\N	{"roomSize": true, "documents": true, "cleanRooms": true, "cctvCameras": true, "visitorBook": true, "cleanKitchen": true, "doctorDetails": true, "fireEquipment": true, "guestRegister": true, "onlinePayment": true, "wasteDisposal": true, "waterFacility": true, "wellMaintained": true, "applicationForm": true, "cutleryCrockery": true, "luggageAssistance": true, "comfortableBedding": true, "energySavingLights": true}	Early inspection override: Conducted 4 days before the scheduled date (December 20th, 2025). Reason: Log Earlier Visit\nEnable if the physical inspection happened up to 7 days before the scheduled date.	{"lounge": false, "laundry": false, "parking": false, "storage": false, "wardrobe": false, "furniture": false, "diningArea": false, "luggageHelp": false, "safeStorage": false, "hotColdWater": false, "refrigerator": false, "securityGuard": false, "heatingCooling": false, "himachaliCrafts": false, "toiletAmenities": false, "attachedBathroom": false, "waterConservation": false, "rainwaterHarvesting": false}	\N	\N	\N	f	\N	f	\N	t	approve	Findings & Recommendation\nOverall Inspection Summary *	\N	\N	2025-12-17 09:39:07.084321	2025-12-17 09:39:07.084321
\.


--
-- Data for Name: lgd_blocks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lgd_blocks (id, lgd_code, block_name, district_id, tehsil_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_districts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lgd_districts (id, lgd_code, district_name, division_name, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_gram_panchayats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lgd_gram_panchayats (id, lgd_code, gram_panchayat_name, district_id, block_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_tehsils; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lgd_tehsils (id, lgd_code, tehsil_name, district_id, tehsil_type, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lgd_urban_bodies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lgd_urban_bodies (id, lgd_code, urban_body_name, district_id, body_type, number_of_wards, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: login_otp_challenges; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.login_otp_challenges (id, user_id, otp_hash, expires_at, consumed_at, created_at) FROM stdin;
8b959858-5e74-41e3-aeb3-cf8e7988d803	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	$2b$10$aY3dVqs1gdXmkkomu7QgjenMGezdJJcL1fUH2UNLlZxw0l.h/tq0i	2025-12-11 20:38:18.253	2025-12-11 20:28:32.619	2025-12-11 20:28:18.257929
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, user_id, application_id, type, title, message, channels, is_read, read_at, created_at) FROM stdin;
5a6f369b-5651-4d40-84d5-878f32fef539	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	\N	inspection_assigned	New Inspection Assigned	You have been assigned an inspection for application HP-HS-2025-SML-000001 on 15 Dec 2025	{"inapp": true}	f	\N	2025-12-12 11:21:57.123054
5e77142e-6e26-48ac-9d67-35739bf36a06	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	\N	inspection_assigned	New Inspection Assigned	You have been assigned an inspection for application HP-HS-2025-SML-000002 on 15 Dec 2025	{"inapp": true}	f	\N	2025-12-12 16:11:14.155578
e5e6b712-f034-4f0f-bc8f-08e8e5a051d1	486a4663-dcc8-49fb-8c4c-9aeafef4bb97	\N	inspection_assigned	New Inspection Assigned	You have been assigned an inspection for application HP-HS-2025-SML-000047 on 20 Dec 2025	{"inapp": true}	f	\N	2025-12-17 09:15:24.352787
\.


--
-- Data for Name: objections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.objections (id, application_id, inspection_report_id, raised_by, raised_date, objection_type, objection_title, objection_description, severity, response_deadline, status, resolution_notes, resolved_by, resolved_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: password_reset_challenges; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_reset_challenges (id, user_id, channel, recipient, otp_hash, expires_at, consumed_at, created_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, application_id, payment_type, amount, payment_gateway, gateway_transaction_id, payment_method, payment_status, payment_link, qr_code_url, payment_link_expiry_date, initiated_at, completed_at, receipt_number, receipt_url) FROM stdin;
\.


--
-- Data for Name: production_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.production_stats (id, total_applications, approved_applications, rejected_applications, pending_applications, scraped_at, source_url) FROM stdin;
f57c36d2-908c-46d6-9cd6-6b26fd9a3129	4	4	4	4	2025-12-11 11:35:28.622262	https://eservices.himachaltourism.gov.in/
a9734bfc-adb2-432c-8b0d-a020d0f46b94	4	4	4	4	2025-12-11 12:35:28.639809	https://eservices.himachaltourism.gov.in/
6fd7f768-8eda-4155-b09a-fc229e52f7c6	4	4	4	4	2025-12-11 13:35:28.615156	https://eservices.himachaltourism.gov.in/
5ded5b32-ca6b-4a92-b4fe-413b59ce6d9f	4	4	4	4	2025-12-11 14:35:28.636386	https://eservices.himachaltourism.gov.in/
1d70279b-d8fc-46a1-8a6c-a193531d09fd	4	4	4	4	2025-12-11 15:35:28.595179	https://eservices.himachaltourism.gov.in/
426a11d3-281b-452d-8a3a-9433c40475af	4	4	4	4	2025-12-11 16:35:28.610253	https://eservices.himachaltourism.gov.in/
68eac4da-daf9-42e8-ae8c-55e7d04913ba	4	4	4	4	2025-12-11 17:35:28.614239	https://eservices.himachaltourism.gov.in/
8a9e8542-62bf-4223-976f-166c5a1f3329	4	4	4	4	2025-12-11 18:35:28.616999	https://eservices.himachaltourism.gov.in/
dad4d2ea-f9b3-4710-b527-78a7892ab185	4	4	4	4	2025-12-11 19:35:28.596146	https://eservices.himachaltourism.gov.in/
98f3428a-a345-4cb3-b9ea-1d9c4b24ce9d	4	4	4	4	2025-12-11 20:00:14.901908	https://eservices.himachaltourism.gov.in/
6d439101-a930-4d41-bf58-0fb49893a11a	4	4	4	4	2025-12-11 21:00:14.837613	https://eservices.himachaltourism.gov.in/
377c036f-aa6f-42c9-b75b-1acf9e584dd5	4	4	4	4	2025-12-11 22:00:14.837728	https://eservices.himachaltourism.gov.in/
eb40dcf9-8f75-4bb6-88f7-cab5cfde4776	4	4	4	4	2025-12-11 23:00:14.831331	https://eservices.himachaltourism.gov.in/
13d62295-9de2-4c21-9af0-9199088aa10a	4	4	4	4	2025-12-12 00:00:14.891522	https://eservices.himachaltourism.gov.in/
ad1bf456-7b8b-408f-a6b7-6b315c668f5b	4	4	4	4	2025-12-12 01:00:14.870015	https://eservices.himachaltourism.gov.in/
fe31ae44-6303-4566-86b3-ed90210cb068	4	4	4	4	2025-12-12 02:00:14.86043	https://eservices.himachaltourism.gov.in/
2a2eaf72-15fa-45a4-8e37-4894e00a7d7a	4	4	4	4	2025-12-12 03:00:14.845569	https://eservices.himachaltourism.gov.in/
5da2dafd-0727-456a-8871-a754439946d9	4	4	4	4	2025-12-12 03:21:36.783435	https://eservices.himachaltourism.gov.in/
2dd67f6b-ffe8-4738-a1e3-7110ec13315e	4	4	4	4	2025-12-12 03:21:55.197582	https://eservices.himachaltourism.gov.in/
1e792475-24f4-4b31-b619-13558fee2384	4	4	4	4	2025-12-12 03:24:27.905315	https://eservices.himachaltourism.gov.in/
19ce2576-4c4c-46a7-9100-1e0d4b4ece84	4	4	4	4	2025-12-12 03:26:39.02943	https://eservices.himachaltourism.gov.in/
544bf8c6-edc1-49d6-b521-30d4abf847ec	4	4	4	4	2025-12-12 03:26:41.637849	https://eservices.himachaltourism.gov.in/
a197a26a-c2dc-4c14-8db9-e04183191d70	4	4	4	4	2025-12-12 03:26:45.571155	https://eservices.himachaltourism.gov.in/
3188a6e7-6009-4e9c-875c-cee0b22e14b2	4	4	4	4	2025-12-12 03:26:48.504676	https://eservices.himachaltourism.gov.in/
26ab6205-41f2-4420-b30b-1257912b8ee2	4	4	4	4	2025-12-12 03:28:32.562989	https://eservices.himachaltourism.gov.in/
128f4010-452d-4545-8c48-576a29ef59a8	4	4	4	4	2025-12-12 03:28:46.512692	https://eservices.himachaltourism.gov.in/
3d5369a7-403a-4739-971d-2cac695d7d60	4	4	4	4	2025-12-12 03:28:50.218291	https://eservices.himachaltourism.gov.in/
a12d6dc8-3530-41d7-91d9-074b653f1768	4	4	4	4	2025-12-12 03:29:02.235177	https://eservices.himachaltourism.gov.in/
8d032faf-9a89-4592-9deb-9ae90a948c67	4	4	4	4	2025-12-12 03:29:04.495149	https://eservices.himachaltourism.gov.in/
c462e98b-4310-4d9c-8483-2ac6f7ebcd4d	4	4	4	4	2025-12-12 03:29:15.571199	https://eservices.himachaltourism.gov.in/
f318a9e2-4b11-47d8-a758-251a18cde190	4	4	4	4	2025-12-12 03:30:38.834029	https://eservices.himachaltourism.gov.in/
44a4fd8e-2423-42f1-a9fa-63cf2191edf4	4	4	4	4	2025-12-12 03:30:40.816869	https://eservices.himachaltourism.gov.in/
b0f66976-7a3b-4724-8a21-416bfba09533	4	4	4	4	2025-12-12 03:30:50.304486	https://eservices.himachaltourism.gov.in/
de110b26-4df6-4339-9879-684fc74f8832	4	4	4	4	2025-12-12 03:30:55.199878	https://eservices.himachaltourism.gov.in/
597f4fa4-22d4-4080-9de7-37e0582e3ae1	4	4	4	4	2025-12-12 03:30:59.155563	https://eservices.himachaltourism.gov.in/
04dc6efd-f676-4eaa-9a78-a8fbfcb2022f	4	4	4	4	2025-12-12 03:31:01.033138	https://eservices.himachaltourism.gov.in/
2fbf5566-e28d-4d85-8bf0-a0ad7cbdb63d	4	4	4	4	2025-12-12 03:31:06.474581	https://eservices.himachaltourism.gov.in/
b3fa0f2b-84e0-481e-ba4c-c6073b1e16d9	4	4	4	4	2025-12-12 03:31:14.189927	https://eservices.himachaltourism.gov.in/
63545717-22b2-4c47-8b0e-6cb37de81536	4	4	4	4	2025-12-12 03:31:18.013268	https://eservices.himachaltourism.gov.in/
4ddc475a-0fc4-4bc9-b494-422cc5a52cf7	4	4	4	4	2025-12-12 03:31:35.614223	https://eservices.himachaltourism.gov.in/
9d68df5f-11bc-4394-a1d3-088008f63fef	4	4	4	4	2025-12-12 03:32:25.897124	https://eservices.himachaltourism.gov.in/
fdb2bdad-4ecd-4d98-b07d-d9dacc8ea9c1	4	4	4	4	2025-12-12 03:32:27.75184	https://eservices.himachaltourism.gov.in/
0826c5b1-1958-48c0-b592-18618482a46f	4	4	4	4	2025-12-12 03:33:59.57813	https://eservices.himachaltourism.gov.in/
6cd17cd6-c7c9-46fb-9213-82248530669c	4	4	4	4	2025-12-12 03:39:59.036458	https://eservices.himachaltourism.gov.in/
d3a5603f-9bdd-49a2-95f3-e91521faae44	4	4	4	4	2025-12-12 04:39:59.046464	https://eservices.himachaltourism.gov.in/
80343f77-ecf1-4ba2-afa3-54e71e80e5ce	4	4	4	4	2025-12-12 04:46:34.322882	https://eservices.himachaltourism.gov.in/
3a132f86-5846-4796-83ec-0979263ebdf6	4	4	4	4	2025-12-12 04:51:39.123795	https://eservices.himachaltourism.gov.in/
390471f9-87a1-40d6-8821-46174b953a23	4	4	4	4	2025-12-12 04:59:54.740988	https://eservices.himachaltourism.gov.in/
047e6c3d-b242-4894-a0cf-82338c7da5bf	4	4	4	4	2025-12-12 05:59:55.434898	https://eservices.himachaltourism.gov.in/
b34aa6c4-0473-4e7f-a91c-c2561526e9dd	4	4	4	4	2025-12-12 06:59:54.735174	https://eservices.himachaltourism.gov.in/
a813dc1d-c8ac-4b5e-8d53-1df927664933	4	4	4	4	2025-12-12 07:59:25.596244	https://eservices.himachaltourism.gov.in/
881cbde8-74ab-4d07-a19b-006a326bac20	4	4	4	4	2025-12-12 08:18:59.697284	https://eservices.himachaltourism.gov.in/
63127c41-76bb-4df8-8590-1267899a09ab	4	4	4	4	2025-12-12 09:18:59.786867	https://eservices.himachaltourism.gov.in/
ce4609ac-6912-4ddd-af8f-e18e81ebdc37	4	4	4	4	2025-12-12 09:24:20.109746	https://eservices.himachaltourism.gov.in/
3553e539-5ea1-4264-a573-071b135eb507	4	4	4	4	2025-12-12 09:36:53.613523	https://eservices.himachaltourism.gov.in/
c1b6b4cb-5078-43d1-ba58-b4ded9194ab4	4	4	4	4	2025-12-12 09:56:26.98512	https://eservices.himachaltourism.gov.in/
148e66b5-7db1-452d-8186-4d4f37e29597	4	4	4	4	2025-12-12 10:17:09.286244	https://eservices.himachaltourism.gov.in/
7f387501-3b63-4083-b995-2cb89f92d205	4	4	4	4	2025-12-12 10:58:07.936729	https://eservices.himachaltourism.gov.in/
11781a1b-8141-48c6-8b5a-51f8dd42a5ff	4	4	4	4	2025-12-12 11:07:07.845709	https://eservices.himachaltourism.gov.in/
a8832ff0-167c-4f83-a0b0-919b657af86b	4	4	4	4	2025-12-12 11:29:23.911432	https://eservices.himachaltourism.gov.in/
26ccc113-daf1-4ec9-995c-2379511cc516	4	4	4	4	2025-12-12 12:29:23.904694	https://eservices.himachaltourism.gov.in/
88d219fd-e9ea-48d6-a539-bc1a5c3a7b24	4	4	4	4	2025-12-12 13:29:23.916131	https://eservices.himachaltourism.gov.in/
1fa17449-3875-430b-a127-91870d83bed2	4	4	4	4	2025-12-12 14:29:23.950738	https://eservices.himachaltourism.gov.in/
93d31ed7-14e6-4379-af8e-cacea0987e3d	4	4	4	4	2025-12-12 15:29:23.942504	https://eservices.himachaltourism.gov.in/
7cdfd333-ca87-40f0-8d0e-e623fff2dc56	4	4	4	4	2025-12-12 16:01:59.611172	https://eservices.himachaltourism.gov.in/
055917bd-3658-46e2-bcf4-d0bbba8e1cb6	4	4	4	4	2025-12-12 17:01:59.640972	https://eservices.himachaltourism.gov.in/
4ed2e4e7-6284-4e57-bbf4-fd07236ff8eb	4	4	4	4	2025-12-12 18:01:59.580047	https://eservices.himachaltourism.gov.in/
1712fd01-445b-4b55-9f34-d80adb210d8f	4	4	4	4	2025-12-12 19:01:59.670871	https://eservices.himachaltourism.gov.in/
70c060f5-9f30-4cae-bc4b-d0ac7968f3bd	4	4	4	4	2025-12-12 19:21:15.343379	https://eservices.himachaltourism.gov.in/
6cba0cab-4cfe-4d8a-8ebf-e6c050aecb79	4	4	4	4	2025-12-12 19:28:07.497946	https://eservices.himachaltourism.gov.in/
965637ee-767b-4e96-b0d8-e2c80baadcf5	4	4	4	4	2025-12-12 19:31:38.679296	https://eservices.himachaltourism.gov.in/
7e8c0ce8-d262-441c-8f58-137f4c7ddefe	4	4	4	4	2025-12-12 20:08:23.809908	https://eservices.himachaltourism.gov.in/
79663d1d-30c9-4693-a599-862225226bf4	4	4	4	4	2025-12-12 20:15:37.529301	https://eservices.himachaltourism.gov.in/
6734957d-7801-4d67-8363-2c37bfc531b7	4	4	4	4	2025-12-12 21:15:37.481415	https://eservices.himachaltourism.gov.in/
128ecd39-87bf-4383-81f2-cc89c2b74481	4	4	4	4	2025-12-12 22:15:37.500282	https://eservices.himachaltourism.gov.in/
c5f7bf3a-c0ff-4c80-80c6-e281084504db	4	4	4	4	2025-12-12 23:15:37.543584	https://eservices.himachaltourism.gov.in/
814905e0-a574-46bb-9b31-26a07dac3f7d	4	4	4	4	2025-12-13 00:15:37.504034	https://eservices.himachaltourism.gov.in/
0a83c44b-10a5-44d1-bbaf-0349251684a7	4	4	4	4	2025-12-13 01:15:37.516511	https://eservices.himachaltourism.gov.in/
d535a5d6-c5fd-4ddb-b4bf-3be28aa7f8d6	4	4	4	4	2025-12-13 02:15:37.527626	https://eservices.himachaltourism.gov.in/
7b9cc2bd-dd16-44f7-ae57-6c51123dd701	4	4	4	4	2025-12-13 04:15:41.708831	https://eservices.himachaltourism.gov.in/
0885f040-308b-456b-9a75-c07720cf0843	4	4	4	4	2025-12-13 04:29:13.975032	https://eservices.himachaltourism.gov.in/
380c41c9-6e1c-4207-9a4a-aa74e1e86b14	4	4	4	4	2025-12-13 04:38:35.212077	https://eservices.himachaltourism.gov.in/
6c515659-f6b3-4146-9d11-a4cabaa446af	4	4	4	4	2025-12-13 04:50:18.655666	https://eservices.himachaltourism.gov.in/
94d8945b-a91e-4996-8267-7b722214f335	4	4	4	4	2025-12-13 05:05:29.460519	https://eservices.himachaltourism.gov.in/
6f6dce6c-50a2-4199-8b68-909f4f1d57f2	4	4	4	4	2025-12-13 05:23:55.168369	https://eservices.himachaltourism.gov.in/
af48c283-e8f3-4bbb-8a8f-e6f6e0b24780	4	4	4	4	2025-12-13 06:23:55.141798	https://eservices.himachaltourism.gov.in/
373b2250-b044-4535-8d6b-f0ecfb7e5b6f	4	4	4	4	2025-12-13 07:23:55.186018	https://eservices.himachaltourism.gov.in/
67644b02-69c0-46dc-a9b6-cb34e9339459	4	4	4	4	2025-12-13 08:23:55.145976	https://eservices.himachaltourism.gov.in/
1a6dd574-54e4-4b43-b23c-d48c28e793c6	4	4	4	4	2025-12-13 09:23:55.18029	https://eservices.himachaltourism.gov.in/
ac17bcf2-73aa-45ea-9e02-60398b0c8292	4	4	4	4	2025-12-13 10:23:55.168807	https://eservices.himachaltourism.gov.in/
678a464e-f121-4fa0-b763-95e62d28d579	4	4	4	4	2025-12-13 11:23:55.181344	https://eservices.himachaltourism.gov.in/
bbbb0a42-0f28-4889-b5c2-b251708fc9a2	4	4	4	4	2025-12-13 12:23:55.210362	https://eservices.himachaltourism.gov.in/
0f698a5c-3bde-4434-8930-eed898db51c4	4	4	4	4	2025-12-13 13:23:55.177093	https://eservices.himachaltourism.gov.in/
1f157e20-cd54-4f45-a0d5-dd455c5ebdb4	4	4	4	4	2025-12-13 14:23:55.147841	https://eservices.himachaltourism.gov.in/
bf624d71-245f-4e10-874a-684e8824fd88	4	4	4	4	2025-12-13 15:23:55.149165	https://eservices.himachaltourism.gov.in/
3eb223e3-9487-41a1-8c03-e3b1d9364292	4	4	4	4	2025-12-13 16:23:55.207555	https://eservices.himachaltourism.gov.in/
b2ce09a0-3a00-44b6-a27f-21e684f74511	4	4	4	4	2025-12-13 17:23:55.163917	https://eservices.himachaltourism.gov.in/
e5b26bc9-6d6f-425b-9ea9-6d436e877b03	4	4	4	4	2025-12-13 18:23:55.163227	https://eservices.himachaltourism.gov.in/
eaf81de8-121b-4176-bb40-4592f1f0f4db	4	4	4	4	2025-12-13 19:23:55.152457	https://eservices.himachaltourism.gov.in/
93ed1848-aaa6-4cd3-b053-15899e8aa347	4	4	4	4	2025-12-13 20:23:55.172897	https://eservices.himachaltourism.gov.in/
93549e99-909e-4c62-b332-c1263812b083	4	4	4	4	2025-12-13 21:23:55.170682	https://eservices.himachaltourism.gov.in/
02a5c734-5efe-4e54-9e55-2616bd652c15	4	4	4	4	2025-12-13 22:23:55.162757	https://eservices.himachaltourism.gov.in/
09f4789d-0de5-48c1-baf0-1e271458cea8	4	4	4	4	2025-12-13 23:23:55.204357	https://eservices.himachaltourism.gov.in/
43f39c43-acf5-4997-be2f-c13338892742	4	4	4	4	2025-12-14 00:23:55.171384	https://eservices.himachaltourism.gov.in/
a9b4a33f-8d06-4690-a0a4-e2746a70f4d2	4	4	4	4	2025-12-14 01:23:55.138716	https://eservices.himachaltourism.gov.in/
fd122a5e-51e7-420a-9321-bdc3848acea9	4	4	4	4	2025-12-14 02:23:55.151018	https://eservices.himachaltourism.gov.in/
0d5ff80e-1a9b-4e90-9c39-43027298092b	4	4	4	4	2025-12-14 03:23:55.159514	https://eservices.himachaltourism.gov.in/
420f49eb-e466-4c1e-afc8-f0b1ca8ec362	4	4	4	4	2025-12-14 04:23:55.152387	https://eservices.himachaltourism.gov.in/
d2f94444-00a5-4854-9ed5-ee079e66689c	4	4	4	4	2025-12-14 05:23:55.161533	https://eservices.himachaltourism.gov.in/
a34bee53-5ba1-4a91-8d4d-be6bc48cca31	4	4	4	4	2025-12-14 06:23:55.168858	https://eservices.himachaltourism.gov.in/
e53c912d-27d6-4f41-b372-7644f84ade26	4	4	4	4	2025-12-14 07:23:55.151147	https://eservices.himachaltourism.gov.in/
10c72076-e229-4d3e-b78c-6dccbf694b09	4	4	4	4	2025-12-14 08:23:55.158665	https://eservices.himachaltourism.gov.in/
187385b5-e3b9-4568-959e-431226cf6c21	4	4	4	4	2025-12-14 09:23:55.200837	https://eservices.himachaltourism.gov.in/
8f7735a8-f004-422a-89d3-a0eba6902dd1	4	4	4	4	2025-12-14 10:23:55.17202	https://eservices.himachaltourism.gov.in/
191a6e8d-1b11-4d00-aeb3-51e4fffeb351	4	4	4	4	2025-12-14 11:23:55.154613	https://eservices.himachaltourism.gov.in/
a5314622-94b6-42b0-83d1-cf721c17e08e	4	4	4	4	2025-12-14 12:23:55.142569	https://eservices.himachaltourism.gov.in/
46fdb2d8-9989-4f56-bc4a-8d7d9afc7950	4	4	4	4	2025-12-14 13:23:55.169369	https://eservices.himachaltourism.gov.in/
19cd6a6a-4ca1-4188-acde-99f5519bb79e	4	4	4	4	2025-12-14 14:23:55.15411	https://eservices.himachaltourism.gov.in/
2bca3841-21ee-4cfd-890e-3d478d92bdff	4	4	4	4	2025-12-14 15:23:55.153973	https://eservices.himachaltourism.gov.in/
3b8eeab5-5f13-489f-8185-786a4b7e79b3	4	4	4	4	2025-12-14 16:23:55.15166	https://eservices.himachaltourism.gov.in/
9dd8adf2-1922-4b29-b74d-e34671ef7138	4	4	4	4	2025-12-14 16:55:32.186422	https://eservices.himachaltourism.gov.in/
a664ea78-357f-40fb-94e6-4109d17757e6	4	4	4	4	2025-12-14 16:56:30.343075	https://eservices.himachaltourism.gov.in/
fb26a0ab-5d83-4f31-88fe-587499008c7d	4	4	4	4	2025-12-14 17:03:13.049794	https://eservices.himachaltourism.gov.in/
062b09e3-c59b-4e21-98e2-47943ff5ddc2	4	4	4	4	2025-12-14 17:06:33.019441	https://eservices.himachaltourism.gov.in/
0abeaaa1-2266-466a-997b-3ab7eb0f57be	4	4	4	4	2025-12-14 17:56:07.889443	https://eservices.himachaltourism.gov.in/
e130faa8-7699-4017-965e-6383f02570ea	4	4	4	4	2025-12-14 18:06:33.806582	https://eservices.himachaltourism.gov.in/
1c38f8c6-b081-4e08-a0a7-010d8440bcbe	4	4	4	4	2025-12-14 18:07:17.480179	https://eservices.himachaltourism.gov.in/
3867909a-5c07-4d5d-9f11-843faa4235e9	4	4	4	4	2025-12-14 18:10:26.818894	https://eservices.himachaltourism.gov.in/
dcff327a-37f1-4d78-88d0-8cec79d1e5b0	4	4	4	4	2025-12-14 18:17:09.876037	https://eservices.himachaltourism.gov.in/
4ddd9e01-b4c2-4cb2-b5bb-5c964fd9ea19	4	4	4	4	2025-12-14 18:23:01.327374	https://eservices.himachaltourism.gov.in/
c810eb1b-bc56-4c3d-9902-0f7ff2fa59c8	4	4	4	4	2025-12-14 18:39:17.557324	https://eservices.himachaltourism.gov.in/
b7c5fef0-21c1-4b44-b1f8-b32c9803538e	4	4	4	4	2025-12-14 18:51:51.821358	https://eservices.himachaltourism.gov.in/
fa44b5fa-f700-4c7f-9b93-4aa7b98c13c1	4	4	4	4	2025-12-14 19:03:16.850307	https://eservices.himachaltourism.gov.in/
be2248ac-8273-4cc8-8a94-8627af358b80	4	4	4	4	2025-12-14 19:10:07.28543	https://eservices.himachaltourism.gov.in/
2ed4ec68-48af-4639-8d65-dcdb60f809ad	4	4	4	4	2025-12-14 19:18:07.36768	https://eservices.himachaltourism.gov.in/
2ae47e5a-2292-4ba6-89fe-5d57136bbd6f	4	4	4	4	2025-12-14 19:30:28.805352	https://eservices.himachaltourism.gov.in/
4cceeb61-69ab-4a2a-9641-5e729961adf2	4	4	4	4	2025-12-14 19:36:04.848544	https://eservices.himachaltourism.gov.in/
044562f1-1af7-44ac-a9c3-ee3dd864e625	4	4	4	4	2025-12-14 19:58:18.730745	https://eservices.himachaltourism.gov.in/
dce45b27-8337-4420-bad5-e4e7bfe95da0	4	4	4	4	2025-12-14 20:01:23.506146	https://eservices.himachaltourism.gov.in/
ba8ffc0e-b261-40c6-a367-0a58ab07e32d	4	4	4	4	2025-12-14 20:05:32.530771	https://eservices.himachaltourism.gov.in/
e07c43bc-67ac-41ea-b298-ca5ac6d3274c	4	4	4	4	2025-12-14 21:05:32.564448	https://eservices.himachaltourism.gov.in/
366bb173-3496-48c1-b66f-db62e072e1fc	4	4	4	4	2025-12-14 22:05:32.573233	https://eservices.himachaltourism.gov.in/
cd931e5e-dd44-4afc-9ef8-e4aea3dd74a0	4	4	4	4	2025-12-14 23:05:32.580387	https://eservices.himachaltourism.gov.in/
c87b85e8-cd5b-4b86-9972-f885441fa312	4	4	4	4	2025-12-15 00:05:32.631345	https://eservices.himachaltourism.gov.in/
11318c65-e252-44c6-96d9-58744fab0579	4	4	4	4	2025-12-15 01:05:32.578219	https://eservices.himachaltourism.gov.in/
ae98b3be-1b21-4ae3-b803-0f07adc43e0a	4	4	4	4	2025-12-15 02:05:32.584101	https://eservices.himachaltourism.gov.in/
ed3d4562-5a36-4417-bf4e-2c78f8c16ef1	4	4	4	4	2025-12-15 03:05:32.58305	https://eservices.himachaltourism.gov.in/
7935431e-516b-4caf-ae71-f03c8ad9e54a	4	4	4	4	2025-12-15 04:05:32.598209	https://eservices.himachaltourism.gov.in/
bd2950d6-4da7-40a3-8ff4-86f50e6e5758	4	4	4	4	2025-12-15 05:05:32.587951	https://eservices.himachaltourism.gov.in/
ea56918c-d4ba-4b86-ad65-69ce0cfb9c14	4	4	4	4	2025-12-15 06:05:32.582327	https://eservices.himachaltourism.gov.in/
50df79ea-970f-4a93-87a0-131f4e49775d	4	4	4	4	2025-12-15 07:05:32.577757	https://eservices.himachaltourism.gov.in/
6f915674-cb03-43e3-a146-16f5f139418f	4	4	4	4	2025-12-15 08:05:32.62855	https://eservices.himachaltourism.gov.in/
22f418fd-d41c-4f3d-ac1a-75b62f12433d	4	4	4	4	2025-12-15 09:05:32.554043	https://eservices.himachaltourism.gov.in/
c6e9dac6-a4de-4bb7-9235-9a9fbd8fc874	4	4	4	4	2025-12-15 10:05:32.608848	https://eservices.himachaltourism.gov.in/
4d098b51-5168-4448-9401-1d3a301817d2	4	4	4	4	2025-12-15 11:05:32.629919	https://eservices.himachaltourism.gov.in/
a3aecdf0-3a67-49f5-991f-cbd74dacbc3f	4	4	4	4	2025-12-15 12:05:32.596463	https://eservices.himachaltourism.gov.in/
c267d10d-2330-4b08-96a9-c52b9ec5e48a	4	4	4	4	2025-12-15 13:05:32.656078	https://eservices.himachaltourism.gov.in/
b1a06e46-d377-4f3e-9e78-fb54bfca92a9	4	4	4	4	2025-12-15 14:05:32.610863	https://eservices.himachaltourism.gov.in/
2125f633-dd60-4d20-bfb6-ce84f4ff2376	4	4	4	4	2025-12-15 15:05:32.600567	https://eservices.himachaltourism.gov.in/
32b32d8c-c2ba-4b50-9631-7ba0338925ed	4	4	4	4	2025-12-15 16:05:32.568885	https://eservices.himachaltourism.gov.in/
39376260-6fb0-460d-9bfe-357ab178ff0b	4	4	4	4	2025-12-15 17:05:32.61185	https://eservices.himachaltourism.gov.in/
f3830b15-e9d4-43d9-89cb-f3f50e0bb8cf	4	4	4	4	2025-12-15 18:05:32.607145	https://eservices.himachaltourism.gov.in/
755db46d-7974-46ec-aa16-7534487be48f	4	4	4	4	2025-12-15 19:05:32.593349	https://eservices.himachaltourism.gov.in/
5dc933ce-7219-41ff-966e-5b0b8fadb737	4	4	4	4	2025-12-15 20:05:32.609729	https://eservices.himachaltourism.gov.in/
4f47bd37-af6e-471b-a711-080d34cd3d3d	4	4	4	4	2025-12-15 21:05:32.65432	https://eservices.himachaltourism.gov.in/
4fcd1acc-6a38-4806-9a50-2394bb258c93	4	4	4	4	2025-12-15 22:05:32.60708	https://eservices.himachaltourism.gov.in/
8ff0cda5-6b2b-4ee7-8f1d-87ee4f9848e1	4	4	4	4	2025-12-15 23:05:32.628408	https://eservices.himachaltourism.gov.in/
b02a9d2c-396c-45f7-a6b7-16cbd857c85a	4	4	4	4	2025-12-16 00:05:32.683291	https://eservices.himachaltourism.gov.in/
7d151849-2f59-4d14-b2b2-f2f13534518a	4	4	4	4	2025-12-16 01:05:32.624499	https://eservices.himachaltourism.gov.in/
ba850e73-b0e8-427c-9db5-da1f87801f2b	4	4	4	4	2025-12-16 02:05:32.67701	https://eservices.himachaltourism.gov.in/
d2c38bb9-0749-4cbb-80c0-14ebc01995db	4	4	4	4	2025-12-16 03:05:32.658636	https://eservices.himachaltourism.gov.in/
31dd46bc-8294-42ae-a74b-211b32a6349c	4	4	4	4	2025-12-16 04:05:32.636733	https://eservices.himachaltourism.gov.in/
93219bad-4409-408f-adb6-2a580e3c27c5	4	4	4	4	2025-12-16 05:05:32.650879	https://eservices.himachaltourism.gov.in/
640b45ca-e4e8-40f5-889b-0ae2988b1fcb	4	4	4	4	2025-12-16 06:05:32.648016	https://eservices.himachaltourism.gov.in/
2f020da4-efa6-4ddf-8e99-bb41a812766a	4	4	4	4	2025-12-16 07:05:32.646868	https://eservices.himachaltourism.gov.in/
863615d9-fb62-48f8-b1b2-6629aa04000a	4	4	4	4	2025-12-16 08:05:32.636145	https://eservices.himachaltourism.gov.in/
b27e8ca3-33c0-497c-a42d-cae54825d8ad	4	4	4	4	2025-12-16 09:05:32.651002	https://eservices.himachaltourism.gov.in/
18c4297d-afd0-41d7-87eb-5f0e644cc187	4	4	4	4	2025-12-16 10:05:32.651969	https://eservices.himachaltourism.gov.in/
8d8979bf-94c0-45f2-b32d-ef5da5611419	4	4	4	4	2025-12-16 11:05:32.690977	https://eservices.himachaltourism.gov.in/
d4687f49-cf00-4eff-817c-12b3040f1d4c	4	4	4	4	2025-12-16 12:05:32.687704	https://eservices.himachaltourism.gov.in/
ef2ccf28-c3b7-46f1-9a19-cf84dd5d8afc	4	4	4	4	2025-12-16 13:05:32.656964	https://eservices.himachaltourism.gov.in/
c83a86c6-5a6d-4439-9ad4-25dfe567b801	4	4	4	4	2025-12-16 14:05:32.635977	https://eservices.himachaltourism.gov.in/
a20cc66b-77ec-40b6-b0a2-64b6e4d09149	4	4	4	4	2025-12-16 15:05:32.649054	https://eservices.himachaltourism.gov.in/
6fdca649-d5e7-46f7-a605-037f63b72393	4	4	4	4	2025-12-16 16:05:32.678059	https://eservices.himachaltourism.gov.in/
80423d2f-001c-407f-b86b-dc1868dea381	4	4	4	4	2025-12-16 17:05:32.655003	https://eservices.himachaltourism.gov.in/
87594267-ed08-4e95-8e65-189357f0de27	4	4	4	4	2025-12-16 18:05:33.708696	https://eservices.himachaltourism.gov.in/
01dcfebe-65d8-444c-b9ac-38cd6b7668e1	4	4	4	4	2025-12-16 19:05:32.668075	https://eservices.himachaltourism.gov.in/
44076e48-0c1b-4f8d-9d47-3f6de4c6c567	4	4	4	4	2025-12-16 20:05:32.704579	https://eservices.himachaltourism.gov.in/
f36d2781-74e4-4352-b61f-8b5b7a7704dc	4	4	4	4	2025-12-16 21:05:32.643995	https://eservices.himachaltourism.gov.in/
f38d9439-9000-4eec-bdcc-1f4dc1a0f93d	4	4	4	4	2025-12-16 22:05:32.6586	https://eservices.himachaltourism.gov.in/
d793739d-d6fa-4da9-b815-97e9250130da	4	4	4	4	2025-12-16 23:05:32.682449	https://eservices.himachaltourism.gov.in/
ba572db5-c26a-4d9c-921c-d290268ac493	4	4	4	4	2025-12-17 00:05:32.669496	https://eservices.himachaltourism.gov.in/
76532c3b-855d-451b-9ad5-b59fd6c27fa7	4	4	4	4	2025-12-17 01:05:32.644097	https://eservices.himachaltourism.gov.in/
66f054be-52ff-44e3-9fcc-bfbffa6646f6	4	4	4	4	2025-12-17 02:05:32.688859	https://eservices.himachaltourism.gov.in/
849fe029-adeb-4ea5-81a6-d8a7ea113631	4	4	4	4	2025-12-17 03:05:32.633809	https://eservices.himachaltourism.gov.in/
85e96db3-1381-4ebc-8e8b-45837a10fd34	4	4	4	4	2025-12-17 03:55:45.487231	https://eservices.himachaltourism.gov.in/
2daf1b21-b11d-4add-9377-a71c268fc52c	4	4	4	4	2025-12-17 04:01:26.513083	https://eservices.himachaltourism.gov.in/
5ed53ba7-a050-4506-8128-7c8d20ef669a	4	4	4	4	2025-12-17 04:49:18.580191	https://eservices.himachaltourism.gov.in/
d80dc450-7dec-4125-9ddc-137ee6f975e1	4	4	4	4	2025-12-17 05:01:26.494528	https://eservices.himachaltourism.gov.in/
0fc2cb4c-bb77-42d1-a8ac-d8f5c15fcc0f	4	4	4	4	2025-12-17 05:49:18.3327	https://eservices.himachaltourism.gov.in/
fa8f744c-18f0-4b66-8bf5-857531eeb65a	4	4	4	4	2025-12-17 06:01:53.825395	https://eservices.himachaltourism.gov.in/
5198e269-7e25-4117-8a4f-4462f5b4b6fd	4	4	4	4	2025-12-17 06:35:01.48112	https://eservices.himachaltourism.gov.in/
d0951551-33a3-4f18-b51f-fe015e3d1840	4	4	4	4	2025-12-17 06:39:18.059367	https://eservices.himachaltourism.gov.in/
0f4f1385-9f28-4ac3-bdfe-8f07655b46a9	4	4	4	4	2025-12-17 07:01:26.502956	https://eservices.himachaltourism.gov.in/
16c44cc6-5a92-42ca-b76b-6eff2dd8d5be	4	4	4	4	2025-12-17 07:30:55.8635	https://eservices.himachaltourism.gov.in/
8cd1a860-5310-4dff-9718-f864a98a8b87	4	4	4	4	2025-12-17 08:00:01.103003	https://eservices.himachaltourism.gov.in/
067007ba-d1fa-4d44-b4bf-bc48734a9285	4	4	4	4	2025-12-17 08:01:26.541816	https://eservices.himachaltourism.gov.in/
7bc5f7bb-6506-4980-9093-b24cca7765d7	4	4	4	4	2025-12-17 08:26:50.098065	https://eservices.himachaltourism.gov.in/
317eb282-5dbd-4040-b0ab-1915b2ee9e60	4	4	4	4	2025-12-17 09:00:17.514506	https://eservices.himachaltourism.gov.in/
d46ec525-9fbb-49c7-b3fc-fb6dd2c6fa2a	4	4	4	4	2025-12-17 09:26:49.973206	https://eservices.himachaltourism.gov.in/
bc2dab49-83c7-46f6-bdb9-6f9f5f5aa4e6	4	4	4	4	2025-12-17 09:28:47.973049	https://eservices.himachaltourism.gov.in/
3324a7da-f66c-4e49-a46e-d8c54497c6fd	4	4	4	4	2025-12-17 10:12:58.558827	https://eservices.himachaltourism.gov.in/
05e03596-dc41-4415-bbb6-0a3c0620d866	4	4	4	4	2025-12-17 10:15:44.332764	https://eservices.himachaltourism.gov.in/
a9cd6bcf-d658-42f6-bfac-72869b558c22	4	4	4	4	2025-12-17 15:11:13.448483	https://eservices.himachaltourism.gov.in/
b80c76bc-04d2-4013-b380-24807773bf98	4	4	4	4	2025-12-17 15:11:54.708456	https://eservices.himachaltourism.gov.in/
d6235b37-31fe-41d8-b9f9-822971edb526	4	4	4	4	2025-12-17 15:16:22.114515	https://eservices.himachaltourism.gov.in/
ed6e37c5-a2f8-424f-9705-db3b4c8b73d8	4	4	4	4	2025-12-17 15:17:30.294893	https://eservices.himachaltourism.gov.in/
f2eaa348-9d55-4425-8318-166ecc1ae454	4	4	4	4	2025-12-17 15:17:39.0564	https://eservices.himachaltourism.gov.in/
d7590693-2b84-4ba8-9ff7-be091c4879ac	4	4	4	4	2025-12-17 15:17:48.302803	https://eservices.himachaltourism.gov.in/
f9dd0c2d-a6bd-4be1-8988-0cc77b7219de	4	4	4	4	2025-12-17 15:19:01.939976	https://eservices.himachaltourism.gov.in/
a5f23744-0416-406c-865f-0d4d96c27dd8	4	4	4	4	2025-12-17 15:25:50.486349	https://eservices.himachaltourism.gov.in/
42a62949-8f5e-4960-8e0d-d03216eeb821	4	4	4	4	2025-12-17 15:27:46.964885	https://eservices.himachaltourism.gov.in/
c6636155-0237-48b6-90a2-5d3949dd2f7e	4	4	4	4	2025-12-17 15:32:51.533405	https://eservices.himachaltourism.gov.in/
455ee62b-54dc-4a1e-b6af-440d0fcccaa3	4	4	4	4	2025-12-17 15:58:13.685099	https://eservices.himachaltourism.gov.in/
4e54c562-40ee-471b-a1df-7c0fcfa68eb8	4	4	4	4	2025-12-17 16:00:45.082573	https://eservices.himachaltourism.gov.in/
0b1796f9-6d06-4b93-9ba0-1deebe23e556	4	4	4	4	2025-12-17 16:04:29.048036	https://eservices.himachaltourism.gov.in/
c34aab3d-e03e-461b-b469-71bf9d2d9bf3	4	4	4	4	2025-12-17 16:18:00.228293	https://eservices.himachaltourism.gov.in/
97388d05-8818-4dc2-aa65-cd36db7daa54	4	4	4	4	2025-12-17 16:18:50.084293	https://eservices.himachaltourism.gov.in/
9a15a50f-19bb-4c3f-96b8-ec72a4ecef49	4	4	4	4	2025-12-17 16:19:01.655308	https://eservices.himachaltourism.gov.in/
f1385332-bd76-4be4-946c-588cc8d04301	4	4	4	4	2025-12-17 16:21:04.442292	https://eservices.himachaltourism.gov.in/
d990bf5a-06af-45fc-a166-f477fac20d6b	4	4	4	4	2025-12-17 16:24:48.92127	https://eservices.himachaltourism.gov.in/
d82e3520-7242-4e38-8da5-6b936e1422d9	4	4	4	4	2025-12-17 16:34:50.32123	https://eservices.himachaltourism.gov.in/
55e5bb98-17cc-40a4-89b6-998ef2426fe0	4	4	4	4	2025-12-17 16:38:07.351656	https://eservices.himachaltourism.gov.in/
c7cde134-0f96-4851-9380-809fafb4915b	4	4	4	4	2025-12-17 16:40:55.927464	https://eservices.himachaltourism.gov.in/
6e3521d8-246b-4477-b3e8-21a67440d0be	4	4	4	4	2025-12-17 16:41:13.553974	https://eservices.himachaltourism.gov.in/
b7ecca03-af27-44bf-9567-12895adaccb1	4	4	4	4	2025-12-17 16:41:22.230228	https://eservices.himachaltourism.gov.in/
43f69506-9f89-4d8a-aa80-730321558554	4	4	4	4	2025-12-17 16:41:31.416895	https://eservices.himachaltourism.gov.in/
90f2f2c9-a0c0-4bd1-8b90-ad471a512060	4	4	4	4	2025-12-17 16:41:40.824901	https://eservices.himachaltourism.gov.in/
a0080b03-bd16-4cec-ae74-04731da7e9d6	4	4	4	4	2025-12-17 16:41:48.221024	https://eservices.himachaltourism.gov.in/
f749e787-e86a-4255-9d9b-9557e0c7289a	4	4	4	4	2025-12-17 16:43:32.759295	https://eservices.himachaltourism.gov.in/
c45d1b73-049e-4542-9e62-0b0e5cb21112	4	4	4	4	2025-12-17 16:47:23.286992	https://eservices.himachaltourism.gov.in/
a8afa90a-cacb-4a75-b2db-cc17afa00d17	4	4	4	4	2025-12-17 16:48:52.689902	https://eservices.himachaltourism.gov.in/
156284ef-b003-4b3c-8603-34a4e4d57705	4	4	4	4	2025-12-17 17:21:32.40501	https://eservices.himachaltourism.gov.in/
a712848f-fe4a-432a-91aa-00d9e61caad6	4	4	4	4	2025-12-17 17:21:54.992531	https://eservices.himachaltourism.gov.in/
fcf0ba53-41d6-4df0-b20a-b350a4feaca7	4	4	4	4	2025-12-17 17:22:05.518006	https://eservices.himachaltourism.gov.in/
27294da5-ef55-4f11-810c-4616abccd118	4	4	4	4	2025-12-17 17:22:17.087295	https://eservices.himachaltourism.gov.in/
d7df5027-a153-4031-8278-3ccea8153a87	4	4	4	4	2025-12-17 17:22:25.550964	https://eservices.himachaltourism.gov.in/
a09ec557-e918-4856-b76c-6129691724a5	4	4	4	4	2025-12-17 17:22:33.981311	https://eservices.himachaltourism.gov.in/
f27c44d0-949b-41e7-a8dd-4f46f2579267	4	4	4	4	2025-12-17 17:22:53.636363	https://eservices.himachaltourism.gov.in/
50edaf5b-52d9-41e8-9a95-d8edd6251458	4	4	4	4	2025-12-17 17:23:13.698127	https://eservices.himachaltourism.gov.in/
18652c68-39b7-465e-82fc-c6b83555d0e3	4	4	4	4	2025-12-17 17:23:51.198738	https://eservices.himachaltourism.gov.in/
43cf0631-57bc-46ec-8216-e2e81ad7deee	4	4	4	4	2025-12-17 17:23:57.897964	https://eservices.himachaltourism.gov.in/
7b88613c-d702-4e8c-8051-d081238f7938	4	4	4	4	2025-12-17 17:24:10.271334	https://eservices.himachaltourism.gov.in/
30a93260-ec34-4bdc-826b-eb805172bc98	4	4	4	4	2025-12-17 17:24:17.940634	https://eservices.himachaltourism.gov.in/
1072a0d4-ce14-4dd8-9a1b-b46d644fd460	4	4	4	4	2025-12-17 17:24:25.058911	https://eservices.himachaltourism.gov.in/
edf9914b-48a3-490c-a6ab-89e8b07ca644	4	4	4	4	2025-12-17 17:24:34.727502	https://eservices.himachaltourism.gov.in/
14add0fc-0f60-4501-a7a6-7ef4abf5c665	4	4	4	4	2025-12-17 17:24:43.046053	https://eservices.himachaltourism.gov.in/
08c52a07-921c-4f3f-b746-b40794011882	4	4	4	4	2025-12-17 17:24:50.805817	https://eservices.himachaltourism.gov.in/
edf45c12-3a5c-477d-b909-f989fe13e65a	4	4	4	4	2025-12-17 17:24:58.362675	https://eservices.himachaltourism.gov.in/
c689384e-7584-423b-a83c-603fa0c39d30	4	4	4	4	2025-12-17 17:25:15.212691	https://eservices.himachaltourism.gov.in/
f9307f72-d052-4426-acb3-44776baac45e	4	4	4	4	2025-12-17 17:36:31.712913	https://eservices.himachaltourism.gov.in/
a56e9af5-b797-4944-883a-01e4e37cf3e9	4	4	4	4	2025-12-17 17:41:55.460034	https://eservices.himachaltourism.gov.in/
f51f674d-2441-4f84-aabb-0f85053a1e9f	4	4	4	4	2025-12-17 18:04:50.304933	https://eservices.himachaltourism.gov.in/
68b85e97-62a3-494a-870d-0cfe04bf75b7	4	4	4	4	2025-12-17 18:06:20.710337	https://eservices.himachaltourism.gov.in/
4f1513a7-81e5-466a-8d5f-7017b55f6147	4	4	4	4	2025-12-17 18:07:17.983295	https://eservices.himachaltourism.gov.in/
dbe9fdbc-aa14-48ee-9623-4ac9b0f31ad7	4	4	4	4	2025-12-17 18:07:41.87008	https://eservices.himachaltourism.gov.in/
e16a30e9-e2f7-4b57-940b-20228e122cee	4	4	4	4	2025-12-17 18:10:25.986332	https://eservices.himachaltourism.gov.in/
adab64cf-e381-4602-b57e-03b6311e79a4	4	4	4	4	2025-12-17 18:42:32.23753	https://eservices.himachaltourism.gov.in/
c918c853-36cf-4701-b5f4-1467e7a6b5e3	4	4	4	4	2025-12-17 19:42:31.830149	https://eservices.himachaltourism.gov.in/
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reviews (id, application_id, user_id, rating, review_text, is_verified_stay, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.session (sid, sess, expire) FROM stdin;
t8Q_IqaB1-D50TItl5MWMirhT1GBLKC4	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T20:33:10.967Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"5","captchaIssuedAt":1765571590966}	2025-12-19 20:33:11
Dv6mXwam28uZi5JdNdhow57VxOJmKBrh	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T20:43:19.138Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"3","captchaIssuedAt":1765572199138}	2025-12-19 20:43:20
0L5PFU0f6_tpwZkqMkMmgZtkGFLhTA0t	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T20:43:27.914Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"11","captchaIssuedAt":1765572207913}	2025-12-19 20:43:28
Nza1gzUsXysxZ3TDH610fN7FrjHjxRgB	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T20:45:06.031Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"35","captchaIssuedAt":1765572306031}	2025-12-19 20:45:07
rwgdD3BqQPVWTwwEcJfCadHvX7JYzbLO	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T20:45:09.144Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"9","captchaIssuedAt":1765572309144}	2025-12-19 20:45:10
gpQpcLimgxxtCLgCuuYRf-EE0D_4gET_	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T20:46:45.548Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"2","captchaIssuedAt":1765572405547}	2025-12-19 20:46:46
KdOcpQeZTkK_20FEPUBpu4NAjhTuhRd1	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T20:46:49.214Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"0","captchaIssuedAt":1765572409214}	2025-12-19 20:46:50
WcX26EU3b1w9T4q1DEtZHw50yS8h0jn6	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T20:48:42.534Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"72","captchaIssuedAt":1765572522534}	2025-12-19 20:48:43
uZu0hmWjfM6YAYwaMsdBCK_7vWr3R1W4	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T20:48:56.574Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"1","captchaIssuedAt":1765572536574}	2025-12-19 20:48:57
G9RHjAj_CtZnb7twZ4HQveNh_bDWTfni	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T20:50:40.513Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"5","captchaIssuedAt":1765572640513}	2025-12-19 20:50:41
ZI5neX5XAgkJHobnKeMDEHvK0OapWAhe	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T20:50:42.696Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"14","captchaIssuedAt":1765572642695}	2025-12-19 20:50:43
sbxh3q8HLd5Czb-WHTozcJP62v6drbXQ	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:00:21.087Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"-3","captchaIssuedAt":1765573221087}	2025-12-19 21:00:22
bc5XKVaDLNWbKxKejeZcw-yTlxI47dZu	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:01:19.927Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"3","captchaIssuedAt":1765573279927}	2025-12-19 21:01:20
690xoQLWDJq63KpruZE5tCEB6yyaOvZ2	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:01:22.988Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"9","captchaIssuedAt":1765573282988}	2025-12-19 21:01:23
Hs1qWDIBauS55-ntWsJXxhe9idCcIMJp	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:04:01.453Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"-2","captchaIssuedAt":1765573441453}	2025-12-19 21:04:02
HV2PwJiqrVBxg4K-gZDDUBcKAB9I7VNL	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:04:04.838Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"-3","captchaIssuedAt":1765573444838}	2025-12-19 21:04:05
GqmXsRm15ePL1A1xOCcyHzVOBN5Ztl2F	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:04:08.516Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"32","captchaIssuedAt":1765573448516}	2025-12-19 21:04:09
AXs9XYKV3rXD9cSXq3KLmdoo1q14S60K	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:04:12.179Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"40","captchaIssuedAt":1765573452179}	2025-12-19 21:04:13
9D39Hg3bO1LWv-YI0I97-4EklzBAByiW	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:04:15.790Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"3","captchaIssuedAt":1765573455790}	2025-12-19 21:04:16
Rc8ydIi0l05xbYMX0F5o9pQIdzRccFO_	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:04:31.628Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"-3","captchaIssuedAt":1765573471628}	2025-12-19 21:04:32
Xs2lfOYBtIfHncx22FSwWIJLjRFHUuEo	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:06:24.759Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"12","captchaIssuedAt":1765573584758}	2025-12-19 21:06:25
57UvIrnTkBg41IQbZAJqIZPuOtEmEpev	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:06:28.169Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"30","captchaIssuedAt":1765573588168}	2025-12-19 21:06:29
RpxL74obiOXcDd7GWOYj6B77Ei9zA_Tq	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:06:31.813Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"4","captchaIssuedAt":1765573591813}	2025-12-19 21:06:32
gTf-x5KUfjXIMTkcJORF7vKryeS7LVax	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:06:35.460Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"0","captchaIssuedAt":1765573595460}	2025-12-19 21:06:36
lmU72-uzFuKe2YyurOPxrgVQpUDHrWxZ	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:06:38.809Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"9","captchaIssuedAt":1765573598809}	2025-12-19 21:06:39
Sj5_F8ymHj474Ap78xQP9sCZm551eNsY	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:06:42.409Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"20","captchaIssuedAt":1765573602409}	2025-12-19 21:06:43
ZTTr7LqNvBEjhDQNl_A7UPaJizgYK8jK	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:06:46.051Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"2","captchaIssuedAt":1765573606051}	2025-12-19 21:06:47
WzBr7kl6HqCo9ze0RIXweO35mWSo2rP_	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:06:49.660Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"4","captchaIssuedAt":1765573609660}	2025-12-19 21:06:50
DZ58jwJZtdlvMwvPt7-rNxqpnmt27FFr	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:06:53.365Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"-1","captchaIssuedAt":1765573613364}	2025-12-19 21:06:54
QzOjsHm0fsD5LX64HkZKxrJHNk34Supo	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:06:55.902Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"7","captchaIssuedAt":1765573615902}	2025-12-19 21:06:56
X36yInLz99GTYj6c_R0qsUKyOpBerCJB	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:08:18.680Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"-7","captchaIssuedAt":1765573698680}	2025-12-19 21:08:19
sDwwIPmTbOHOZNhgrsGn6Ro0d6JwYG-3	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:08:22.056Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"1","captchaIssuedAt":1765573702056}	2025-12-19 21:08:23
qATHkg058j5tiFTC5cNeJKh3B9Lz9714	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:08:25.442Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"11","captchaIssuedAt":1765573705442}	2025-12-19 21:08:26
kKulq8psF_2rLBHxeH0Opb30r4vBGF6E	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:08:29.052Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"16","captchaIssuedAt":1765573709052}	2025-12-19 21:08:30
p94s26aj_A79PqJB1EfvsGRVI4AfZrJR	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:08:32.752Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"7","captchaIssuedAt":1765573712752}	2025-12-19 21:08:33
TAhP3vHyUwrGWOQnVh4d9vrjJpuIeJIf	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:08:36.420Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"-1","captchaIssuedAt":1765573716419}	2025-12-19 21:08:37
flyQkkjr6kCQT2yKURO79_C05_XA-E3A	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:08:39.762Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"16","captchaIssuedAt":1765573719762}	2025-12-19 21:08:40
Jj-M1UgkRjhDWlarcE0YiGKkkB2byFA0	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:08:43.441Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"-1","captchaIssuedAt":1765573723441}	2025-12-19 21:08:44
JYzJU6Si6aAD4KVtCd54zQ_hUjogpADw	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:08:47.118Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"9","captchaIssuedAt":1765573727118}	2025-12-19 21:08:48
I3eRZUhwrkU-C12NcjcqXMH5N8ueytvl	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:08:48.198Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"18","captchaIssuedAt":1765573728198}	2025-12-19 21:08:49
yY4pfBfRQYy5azulKMXybHNbJC5pDl9Q	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:08:51.836Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"-2","captchaIssuedAt":1765573731836}	2025-12-19 21:08:52
pz2btX1dmGtE6kmNASpPxQ-4TjZx0xVj	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:08:55.204Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"54","captchaIssuedAt":1765573735204}	2025-12-19 21:08:56
gqK_ZO0Pe-ldiplJqnVnVkDObygDwusu	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:08:57.923Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"81","captchaIssuedAt":1765573737923}	2025-12-19 21:08:58
PAz17y_5MwKcTO4FZ7HphvKYpqP9Mbg_	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:09:59.338Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"81","captchaIssuedAt":1765573799338}	2025-12-19 21:10:00
nGruT9kmBd8VGYclSvlK9TWkRJqCgDV-	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:10:01.489Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"-7","captchaIssuedAt":1765573801489}	2025-12-19 21:10:02
ohdFPUyeHh6sHPrDWiHu-SsRjJc_Qnes	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:10:14.759Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"2","captchaIssuedAt":1765573814759}	2025-12-19 21:10:15
3NI7T6_JiUaIDDTQd_rr7czYjQjTNJW-	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:10:18.195Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"13","captchaIssuedAt":1765573818194}	2025-12-19 21:10:19
VipWGLFZ_Jv-UGNXpooBE0Hti0n05K_C	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:10:21.621Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"9","captchaIssuedAt":1765573821621}	2025-12-19 21:10:22
WROMivjQmaBEnlOp13K1OrNX1QaTIegu	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:10:25.309Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"-3","captchaIssuedAt":1765573825309}	2025-12-19 21:10:26
MUYWHkXz9R5PnUjnmoSivmNvNCgddYBY	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:10:28.956Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"1","captchaIssuedAt":1765573828956}	2025-12-19 21:10:29
oL2WvN9IYUOzEGruxK6DsM8eK9xzF1yf	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:10:32.312Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"-1","captchaIssuedAt":1765573832311}	2025-12-19 21:10:33
fOLwJAnu9MQA_ZQMKbFV-U-oPXo5qjZs	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:10:35.738Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"28","captchaIssuedAt":1765573835738}	2025-12-19 21:10:36
TNt-tVEcVGwxgWomQXrik7eOmrDtItP6	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:10:39.077Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"15","captchaIssuedAt":1765573839077}	2025-12-19 21:10:40
Ljp3TAUXq9GCD3ZFl6B1KMZNhvuYUoMw	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:10:42.503Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"35","captchaIssuedAt":1765573842503}	2025-12-19 21:10:43
tQvlEC-2celjpKgs3CCbGljndeiY0R-r	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:10:43.901Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"42","captchaIssuedAt":1765573843901}	2025-12-19 21:10:44
Z5sMiRM6ZmVfmKdvqn0b9f9YC-Uhz8-F	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:10:47.493Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"-6","captchaIssuedAt":1765573847493}	2025-12-19 21:10:48
H8oFlRrBAu9vvqVakPU-WlZiGL4AIN6X	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:10:51.157Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"16","captchaIssuedAt":1765573851157}	2025-12-19 21:10:52
cxwZaxamWRmLLAbKDxw_sU8_05Wt2RiD	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:10:56.753Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"8","captchaIssuedAt":1765573856753}	2025-12-19 21:10:57
e3iC8qDPecBkq_rltWI-ocvS6x3Ariom	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:12:09.795Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"5","captchaIssuedAt":1765573929795}	2025-12-19 21:12:10
K_CuM1a_3jJdWD4fNkG9uEpCpG8kTh_5	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:12:13.145Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"-2","captchaIssuedAt":1765573933145}	2025-12-19 21:12:14
n_r0-6aoeblFq5wlyjgwlNrBaG9mn1gQ	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:12:16.799Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"27","captchaIssuedAt":1765573936798}	2025-12-19 21:12:17
cu_wSect1hd0DvhZAshOovk1UHVGiUcl	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:12:20.212Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"-2","captchaIssuedAt":1765573940212}	2025-12-19 21:12:21
41So2jYIyZKqqiJJMkJmBZuJNcSmmPWt	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:12:23.874Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"28","captchaIssuedAt":1765573943874}	2025-12-19 21:12:24
sKV_xtNC2gbfU9Nv-amUD0t5CYI7O2gv	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:12:27.235Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"9","captchaIssuedAt":1765573947234}	2025-12-19 21:12:28
G5atG51TIn6-4QvRhPMOw5kjKYXbBCyT	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:12:30.610Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"12","captchaIssuedAt":1765573950610}	2025-12-19 21:12:31
GoXepeETJ_uRpSxbhhxmpNgHyLuKIKFB	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:12:34.245Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"6","captchaIssuedAt":1765573954245}	2025-12-19 21:12:35
MISANhW4MIKqSqSR8L5zpXgTz9lffkcC	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:12:37.899Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"24","captchaIssuedAt":1765573957898}	2025-12-19 21:12:38
QNufvmsfPs2o0E662DGAZ7zHH0ugN84t	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:12:38.994Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"1","captchaIssuedAt":1765573958993}	2025-12-19 21:12:39
c05VT8wAcYYBarhvyv5CKU_wbPJjwFN4	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:12:42.331Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"1","captchaIssuedAt":1765573962331}	2025-12-19 21:12:43
SkMUTcfXSe1e9oLUbznufZid853bCVDc	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:12:45.741Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"5","captchaIssuedAt":1765573965741}	2025-12-19 21:12:46
aLur4pxSLxGlBbfJ5JvtQoIsj4vhFXvT	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:41:14.591Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"e52010b9-7546-42a1-882e-4334de63c8ca"}	2025-12-20 02:41:15
N-iEOjEE35POjLOlmwMEQMpdWpeLo3yR	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:05:34.364Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97"}	2025-12-20 02:05:35
Fl72n-6nDuohSnUptgINJ6IgD1bo6852	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:05:23.666Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97"}	2025-12-20 02:05:24
u07iJMQPqgeRERWwS-4KA3E6J1F5wjp5	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-19T21:19:31.362Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"17","captchaIssuedAt":1765574371361}	2025-12-19 21:19:32
23iMbW_hEYzoTZrhr2-iNEqL0n9lJneJ	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T01:57:45.058Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"5","captchaIssuedAt":1765591065058}	2025-12-20 01:57:46
XM0lr1z4S2mh_eZSgFeeoc19wCJN3RBA	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T01:57:48.868Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"7","captchaIssuedAt":1765591068868}	2025-12-20 01:57:49
6P-aiEe54RAQ1tlM6ALXaauFDoVheYDJ	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T01:57:52.682Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"5","captchaIssuedAt":1765591072682}	2025-12-20 01:57:53
mzr00E0BVcmKJzHTLGf1dnmZF6-DOAk7	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T01:57:56.460Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"10","captchaIssuedAt":1765591076460}	2025-12-20 01:57:57
tfwsVi7cAE5pGZF3f7yUpllPdgmQlnY1	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T01:58:00.199Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"-4","captchaIssuedAt":1765591080199}	2025-12-20 01:58:01
Es6x-oKbFy4wg6CReE-_8tiDlKJQQKeZ	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T01:58:03.677Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"-4","captchaIssuedAt":1765591083677}	2025-12-20 01:58:04
KrO43tYvq2jp5W78-2xpSEKgdbP91nXi	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T01:58:07.161Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"28","captchaIssuedAt":1765591087161}	2025-12-20 01:58:08
FXJPdatjenSOXdxDUtvb31I1qDzNkpc9	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T01:58:10.892Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"-6","captchaIssuedAt":1765591090892}	2025-12-20 01:58:11
fHwbowWFH9ICxWWfitWWKoSDcmaFVFVu	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T01:58:14.496Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"28","captchaIssuedAt":1765591094496}	2025-12-20 01:58:15
Ls2hGKr7N5gcD9HdhbLZDsYt1pxoRhmt	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T01:58:15.715Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"-3","captchaIssuedAt":1765591095715}	2025-12-20 01:58:16
rITsuWrOibd7-bM5a7RufhILTGOsukoE	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T01:58:19.420Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"11","captchaIssuedAt":1765591099420}	2025-12-20 01:58:20
FxeYei2S3s4UsWedfrib4_u441SsNO4l	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T01:58:22.909Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"30","captchaIssuedAt":1765591102909}	2025-12-20 01:58:23
3D_c_OWOqyzXAwnTpYczsm_y3Ctx-cSa	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:05:27.090Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97"}	2025-12-20 02:05:28
GwCUVjEM1YUGEVyWjKKNKMFyqV5Winl3	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T01:58:31.264Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":"12","captchaIssuedAt":1765591111264}	2025-12-20 01:58:32
rhlvO5tIqXB2y4zNmqdYbBkIO5vvcne5	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:05:52.979Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null}	2025-12-20 02:05:54
9L4TQbYn1daYVatbiT1R5Pp-NsfYQMpf	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:05:30.804Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97"}	2025-12-20 02:05:33
3C5QUmDo3SAIfuMbBsY1ZDRAGAU2_PHX	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:05:41.408Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842"}	2025-12-20 02:05:42
obK27Il2gZOTA6LcQBt6Y2bc12Yq96dK	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:05:37.852Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842"}	2025-12-20 02:05:38
dMV0ipRRHf7Z7OMFLCHJh79UTFgybwrx	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:05:45.273Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842"}	2025-12-20 02:05:46
9x652i8Yq9AX4j30Q8diQ4r42nVhkKXu	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:05:48.755Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842"}	2025-12-20 02:05:49
3xtsIGJi8fVYtM_ug7ru2N8X-LMRwm4s	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:05:51.476Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null}	2025-12-20 02:05:52
WZbJSB_xBoJtbdGlOidL0HqcBnXlUarR	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:05:56.756Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null}	2025-12-20 02:05:58
qg9PPqORTFLTFBMnSrBEhc7t0LSdIOcY	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:06:00.170Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null}	2025-12-20 02:06:01
WFxba9aegTuSnxIzSk1bJpNjDdt9c20W	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:08:44.230Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842"}	2025-12-20 02:08:45
mjsCnYCVgF1rOEOBwFsJe6iOD7HPXE8E	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:06:07.344Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null}	2025-12-20 02:06:09
kSY802TIR9yJLSz_54YREzk2dUbBY3dY	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:08:29.343Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97"}	2025-12-20 02:08:32
Xi2lNjbZb1mP4lVNUo4HLJpO4esaeMwc	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:10:06.694Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null}	2025-12-20 02:10:08
mdbihdyuXyTDoYhcqvOIdy65_TDOkU6Z	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:08:52.954Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"3e2499ee-8bf4-4dd8-9fcc-01a1bc075668"}	2025-12-20 02:08:56
tA5v5N-z3KdC3kQ4FP1nhlmYIJd8lnZJ	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:08:22.062Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97"}	2025-12-20 02:08:23
_dWvvqPgpkhZVGHgopLfK_tsaaRI7M7X	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:08:33.016Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97"}	2025-12-20 02:08:34
tcUsjbiEZhtboGFmV5clX2l14ZFN0d63	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:08:25.807Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97"}	2025-12-20 02:08:26
8Q_6eeNHLHvNHG6smOgrRqkUVrktusAj	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:08:47.841Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842"}	2025-12-20 02:08:48
qCSzdGLBJ1uXzd5JjA65gwdXVXDQztSi	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:08:36.682Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842"}	2025-12-20 02:08:37
1sorVQUHomEPE323oq12G_Z9soCYUAKP	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:08:50.548Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null}	2025-12-20 02:08:51
2uQQ5xa7-awrBmoi1BrWP1uaphhqKbaF	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:08:40.416Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842"}	2025-12-20 02:08:41
yUL8ZiU3QBtbXWZow7alMAovuvtNKOd2	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:09:56.054Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null}	2025-12-20 02:09:57
VBY3JjozVFtQXV08o4UBYVSY4dcSWXFp	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:09:59.880Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null}	2025-12-20 02:10:01
4V6mhTOHESmurNKNdm4XJ4yOsP1z4ru6	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:11:06.572Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null}	2025-12-20 02:11:08
vpC6cDXzC1tHzEYk39r-LaLl-X48GC6n	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:11:10.390Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null}	2025-12-20 02:11:12
LQl8CUu46nkmMhyMRGq4n1UmfrYpjanV	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:11:14.113Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null}	2025-12-20 02:11:15
wBC05msoAOaGdMFV-0hJu9BzWtilgeSD	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:11:17.568Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null}	2025-12-20 02:11:19
Y_10mDGmjY5CLov2ARJobCjFiBKBFr9w	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:11:21.065Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null}	2025-12-20 02:11:22
tw9rFi2e6tNWGsXKCKIFVdTiV4wZcMDQ	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:15:57.128Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97"}	2025-12-20 02:15:58
x3_zTU6_TJmy1N0BVqnp-QnW1MGnFNhA	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:15:53.541Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97"}	2025-12-20 02:15:54
ydNkJ2byxs2NVeSKDo86afNNWkEZM424	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:13:39.063Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null}	2025-12-20 02:13:40
EYA17GK6Nn7H55zrxZjjo7pnuVVI9skM	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:16:00.545Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97"}	2025-12-20 02:16:03
lBB4fhs4pk-T0T-vQRv5KWSVyo2oTW2h	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:16:04.129Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97"}	2025-12-20 02:16:05
TIqJBipS_f19GyePr5_arRS9N6f9IJTh	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:16:07.540Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842"}	2025-12-20 02:16:08
8Y1_Y2QUehRUK08Iwy-hwg2gatMTjlam	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:16:11.345Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842"}	2025-12-20 02:16:12
88cgmYgw_cZdMFyTqQWA2JOGZ9H2ssZ4	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:16:18.679Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842"}	2025-12-20 02:16:19
BKc1yUfgynHwTEpQIF81wo9uV_BR2k8w	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:50:26.945Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"9def5322-010c-43a4-9712-10977499b1da"}	2025-12-20 02:50:44
Ze3d-miVBaEiUBHaAv_kTh6owvM1VZo0	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:16:15.135Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"3b2fa85b-806a-44b8-93ce-07ad7aa8a842"}	2025-12-20 02:16:16
W0hHoiL7bU18p5An0aCHuzvbrj9_ahMc	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:16:21.657Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null}	2025-12-20 02:16:22
u81ZJqLp4FD4vXAny-S_55mkKwBj_-NV	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:16:39.988Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null}	2025-12-20 02:16:41
oNfGCqQHzozeIszviXWMRxVOq3JqEtqN	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:16:24.117Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"3e2499ee-8bf4-4dd8-9fcc-01a1bc075668"}	2025-12-20 02:16:27
eSJzNYO68Zz21r46DfeON92Gh5gHs9Ev	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:16:28.887Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"3e2499ee-8bf4-4dd8-9fcc-01a1bc075668"}	2025-12-20 02:16:32
M5HpMzbZnkmlOnEjZJnQ3bREtuCZzuzl	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T02:16:32.725Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null}	2025-12-20 02:16:34
8ZUIoFOfjgwp9ZoVc6R_BfhJ2HKRLUhW	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-24T09:39:36.967Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"3e2499ee-8bf4-4dd8-9fcc-01a1bc075668"}	2025-12-24 11:00:00
ftwsLa0RJDfvCDBs5qYz4vS7Gkq9BT_Y	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-20T12:35:54.673Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null}	2025-12-20 12:35:55
CgyzO0nTjibWTVjf47OI71UyjCd0pAub	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-24T18:19:18.640Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"3e2499ee-8bf4-4dd8-9fcc-01a1bc075668"}	2025-12-24 18:41:54
SdUOcLhIM3C6VFniH-diV9tDz67NQsWd	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-24T04:53:53.214Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"3e2499ee-8bf4-4dd8-9fcc-01a1bc075668"}	2025-12-24 06:03:51
rmq1P5QR7d304TEY8wRIXNWPSkz_1U9F	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-21T20:24:37.291Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"486a4663-dcc8-49fb-8c4c-9aeafef4bb97"}	2025-12-21 20:24:38
VIRe-JX-OkcyPFiwHfUD1-eDSDP44H1X	{"cookie":{"originalMaxAge":604800000,"expires":"2025-12-24T04:47:43.775Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"captchaAnswer":null,"captchaIssuedAt":null,"userId":"3e2499ee-8bf4-4dd8-9fcc-01a1bc075668"}	2025-12-24 11:00:00
\.


--
-- Data for Name: storage_objects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.storage_objects (id, object_key, storage_provider, file_type, category, mime_type, size_bytes, checksum_sha256, uploaded_by, application_id, document_id, created_at, last_accessed_at) FROM stdin;
4c57c4c5-3d50-44a7-acf3-5be378b6fe47	additional-documents/828f36dc-39fe-4633-9f25-d69fa3e33017	local	additional-document	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	\N	\N	2025-12-11 20:03:22.819442	\N
18e1941f-9629-4333-87d0-647c78992786	revenue-paperss/0bba7fb9-84a2-4c7c-844c-ec24c2068ac2	local	revenue-papers	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	2f7b7a16-ed13-429e-ac57-25763f62fe12	\N	\N	2025-12-12 03:08:26.946416	\N
b97d86a4-0745-4842-a67f-23a718973af9	affidavit-section29s/5b7e232e-3357-42c2-93a8-24bc0e2331cd	local	affidavit-section29	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	2f7b7a16-ed13-429e-ac57-25763f62fe12	\N	\N	2025-12-12 03:08:35.094343	\N
3c51402a-bbe9-47d0-9d64-7488d2e96aef	undertaking-form-cs/96be4f11-3c84-45cb-8b56-14efa60341ed	local	undertaking-form-c	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	2f7b7a16-ed13-429e-ac57-25763f62fe12	\N	\N	2025-12-12 03:08:39.618538	\N
0a1ecc8d-822e-43ef-9efa-80e328a4436e	property-photos/b950cf16-32ac-4833-929a-a91b7bac3740	local	property-photo	photos	image/jpeg	96524	02f226a52cfa9b5054adcfe008a6b8885b9a5f56adc2d53ad3382d9502cbd6dd	2f7b7a16-ed13-429e-ac57-25763f62fe12	\N	\N	2025-12-12 03:08:45.752616	\N
14c6efea-d09e-4c82-b465-aa9e24cd7cd3	property-photos/01ed9aca-d3ae-4d69-8a9b-d03cae82f379	local	property-photo	photos	image/jpeg	13584	12434b6deb0704e02e9f467b990ca3498923894c9c205a1ab3acff0f3eb8a846	2f7b7a16-ed13-429e-ac57-25763f62fe12	\N	\N	2025-12-12 03:08:46.168973	\N
ce5b7c94-f4cb-4683-9a35-ce7af7a332f7	revenue-paperss/ee3d3e04-5947-46dd-893c-45716547e3da	local	revenue-papers	revenue_papers	application/pdf	61398	\N	\N	\N	\N	2025-12-11 20:03:00.719186	\N
ec982ef9-5404-4f6a-b062-b67b6aeaf53b	affidavit-section29s/d143268e-dd22-43f5-89f1-16764d626fe4	local	affidavit-section29	affidavit_section_29	application/pdf	61398	\N	\N	\N	\N	2025-12-11 20:03:05.109574	\N
fffb6b68-705b-4308-8153-a5e117233333	undertaking-form-cs/ae659c3a-8734-44fd-8711-56d21c7f6a31	local	undertaking-form-c	undertaking_form_c	application/pdf	61398	\N	\N	\N	\N	2025-12-11 20:03:09.218634	\N
75bbafa2-68bd-46b1-8632-77917ac7b634	property-photos/c06596bb-dffc-4f21-aecc-6fa5d08c718e	local	property-photo	property_photo	image/jpeg	96524	\N	\N	\N	\N	2025-12-11 20:03:15.738652	\N
e4d17ffb-2b20-4359-952c-ed831942d0ef	property-photos/ecbe8272-bd9e-49a0-a82e-63a436915384	local	property-photo	property_photo	image/jpeg	13584	\N	\N	\N	\N	2025-12-11 20:03:15.802272	\N
65ba9b9d-708d-4475-a43a-2ee16f0c1b38	revenue-paperss/dff9d713-5794-4ff6-aacc-a027134644ae	local	revenue-papers	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	\N	\N	2025-12-12 10:47:38.391683	\N
226618f8-c838-42f5-bbe9-3513c18ecb9b	affidavit-section29s/1fe3a58d-d7a4-48a9-96c3-83d76969e1c0	local	affidavit-section29	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	\N	\N	2025-12-12 10:47:42.121746	\N
a568b79e-a415-4661-9d2f-9914085dd812	undertaking-form-cs/73705ddf-acdc-476f-a07d-82342ea0ca25	local	undertaking-form-c	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	\N	\N	2025-12-12 10:47:45.686639	\N
d72748c1-49e8-41d3-8a7b-8cdf67ec70a1	commercial-electricity-bills/8e0e0e11-8dff-4b78-b9d7-742056453b4d	local	commercial-electricity-bill	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	\N	\N	2025-12-12 10:47:49.832267	\N
3a226f9c-f481-46b4-afec-e0e8a4bbb42a	commercial-water-bills/bf3a6629-d377-4974-90e3-b6bb5b6471cc	local	commercial-water-bill	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	\N	\N	2025-12-12 10:47:54.385231	\N
31a797f4-24af-4831-9d58-20e12c494ef8	property-photos/b4e34401-b8ae-49ff-a27b-88629cdd811d	local	property-photo	photos	image/jpeg	96524	02f226a52cfa9b5054adcfe008a6b8885b9a5f56adc2d53ad3382d9502cbd6dd	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	\N	\N	2025-12-12 10:47:59.965814	\N
74f48237-b71a-41f7-a4f7-3ba4a8f36a80	property-photos/4c48d44d-51e1-4574-8582-2acb0b34945d	local	property-photo	photos	image/jpeg	13584	12434b6deb0704e02e9f467b990ca3498923894c9c205a1ab3acff0f3eb8a846	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	\N	\N	2025-12-12 10:48:00.047528	\N
d3c86044-35ff-4ff9-b54b-7422fce3d54c	additional-documents/dc883afc-6c19-4bf8-91cc-e3d1bd4696c3	local	additional-document	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	\N	\N	2025-12-12 10:48:04.510886	\N
01b0f7b6-3e48-44cb-8af7-5570491c4458	revenue-paperss/e0742dab-7c19-4ff5-b57d-1e540540b50b	local	revenue-papers	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	e52010b9-7546-42a1-882e-4334de63c8ca	\N	\N	2025-12-12 15:51:42.076812	\N
b0d89b56-9507-4619-be9a-f0d71e842b12	affidavit-section29s/74187c67-f680-42ab-9423-036ec7dd0fb8	local	affidavit-section29	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	e52010b9-7546-42a1-882e-4334de63c8ca	\N	\N	2025-12-12 15:51:46.758061	\N
4d854886-3f33-43f4-a583-07083fcd9632	undertaking-form-cs/bee6932a-b107-40eb-889c-9383174b4150	local	undertaking-form-c	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	e52010b9-7546-42a1-882e-4334de63c8ca	\N	\N	2025-12-12 15:51:51.0992	\N
cf067f6f-e1c0-4299-b9a1-2d302df4c2cf	property-photos/21c5b2d5-9cb7-485e-abfa-e86d823d87ec	local	property-photo	photos	image/jpeg	96524	02f226a52cfa9b5054adcfe008a6b8885b9a5f56adc2d53ad3382d9502cbd6dd	e52010b9-7546-42a1-882e-4334de63c8ca	\N	\N	2025-12-12 15:51:57.155022	\N
91053f3b-0ab8-4a47-8bd2-8c9e637d9a83	property-photos/12caf16a-89b5-4879-8636-f69cb1387a9d	local	property-photo	photos	image/jpeg	13584	12434b6deb0704e02e9f467b990ca3498923894c9c205a1ab3acff0f3eb8a846	e52010b9-7546-42a1-882e-4334de63c8ca	\N	\N	2025-12-12 15:51:57.228125	\N
8b1b66f3-ce25-43cd-b43e-38f1d9d7d729	additional-documents/2cc0a8b3-1985-409b-995e-36a2a6162f7f	local	additional-document	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	e52010b9-7546-42a1-882e-4334de63c8ca	\N	\N	2025-12-12 15:52:02.721205	\N
d8c62cbe-6205-4f8e-9a82-73a7e6cb638a	documents/f24bbde6-c25d-437b-a0da-6bb285b3b5e3	local	document	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	62bed697-2b04-4591-a351-82d7611368f9	\N	\N	2025-12-12 19:36:46.905471	\N
478cf267-7e7d-4f89-8c2c-b1c530a14d0a	documents/4a555720-2e5c-4b25-98ec-92f135ea9e21	local	document	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	62bed697-2b04-4591-a351-82d7611368f9	\N	\N	2025-12-12 19:36:51.91858	\N
621ca0cb-55a7-4674-a813-30faaf92c4e5	documents/82ff6100-7616-401e-92ac-f8d0e09d00fd	local	document	photos	image/jpeg	123434	ad3fabdc279096be6f6b0bc398e6af4b54e24c2fb6417090f892d073729ed9a2	62bed697-2b04-4591-a351-82d7611368f9	\N	\N	2025-12-12 19:37:07.768776	\N
a9da065a-0823-44d4-a1b6-83b77f455125	documents/2c8bc15a-84bb-4df7-982e-46f7756c26c8	local	document	photos	image/jpeg	117294	f59b32cc0c72de69f0c6264f07482c24b5b955c0a2da79a9bb36b6fdc357fdfe	62bed697-2b04-4591-a351-82d7611368f9	\N	\N	2025-12-12 19:37:32.878846	\N
9c46246d-a09f-427d-8388-c691c20b0ee0	documents/47afaafe-acd3-4435-941e-73c65e969277	local	document	photos	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	62bed697-2b04-4591-a351-82d7611368f9	\N	\N	2025-12-12 20:26:40.472451	\N
f49712f0-9716-41bd-a9b3-87911845e759	documents/b1664e6d-ade1-4e07-a1e4-437c8801a679	local	document	photos	image/jpeg	96524	02f226a52cfa9b5054adcfe008a6b8885b9a5f56adc2d53ad3382d9502cbd6dd	62bed697-2b04-4591-a351-82d7611368f9	\N	\N	2025-12-12 20:26:50.90843	\N
fd594b57-a812-44c7-b9ab-6ec9d13f2e10	documents/4c9356f0-d3ef-4def-aa82-37c431673973	local	document	photos	image/jpeg	13584	12434b6deb0704e02e9f467b990ca3498923894c9c205a1ab3acff0f3eb8a846	62bed697-2b04-4591-a351-82d7611368f9	\N	\N	2025-12-12 20:26:57.327923	\N
c76ae1d0-5223-45f9-81f8-6c69542d5314	documents/2ec85148-b3c0-4605-9229-721d4a45565e	local	document	legacy_certificate	application/pdf	61398	\N	\N	cefe6037-d38c-4923-a2d4-cdac09d844c6	6b7df36a-2f25-45c1-b023-095ddab6db94	2025-12-12 20:08:50.837511	\N
b970cad4-a8b0-4be1-8380-e88db6bdca9d	documents/8ce66739-04b9-49e7-a433-b62c76bdec98	local	document	owner_identity_proof	application/pdf	61398	\N	\N	cefe6037-d38c-4923-a2d4-cdac09d844c6	88e670e6-ae40-413b-812a-de7473d68f54	2025-12-12 20:26:30.160728	\N
d0bf8438-8167-4956-9d53-6cdf35e24544	revenue-paperss/e7830124-53be-4b0c-9ee0-4e4228829426	local	revenue-papers	documents	application/pdf	304514	f0ae7845b4a37729e9c01a027e5081793349cecda2b74d1e5d7cf7bccf2391c0	7b64dd49-04e2-4afe-86bb-2fa6c2d17816	\N	\N	2025-12-13 11:36:05.647574	\N
7ce45655-ad0b-4cae-a98d-887e400446bc	affidavit-section29s/c4c6e0d6-cd95-4d59-8dd0-3c5194d4375b	local	affidavit-section29	documents	application/pdf	304514	f0ae7845b4a37729e9c01a027e5081793349cecda2b74d1e5d7cf7bccf2391c0	7b64dd49-04e2-4afe-86bb-2fa6c2d17816	\N	\N	2025-12-13 11:36:10.958192	\N
7f22f513-b7bc-4ce3-9e09-ff17612800b1	undertaking-form-cs/0039a457-6f8f-4b81-b326-48077d2aa17d	local	undertaking-form-c	documents	application/pdf	304514	f0ae7845b4a37729e9c01a027e5081793349cecda2b74d1e5d7cf7bccf2391c0	7b64dd49-04e2-4afe-86bb-2fa6c2d17816	\N	\N	2025-12-13 11:36:17.423946	\N
e0096d50-e3e7-456f-a0e2-0e37684e7352	commercial-electricity-bills/af5dae27-4eca-45a9-8db0-dc5b3f0b0ac9	local	commercial-electricity-bill	documents	application/pdf	304514	f0ae7845b4a37729e9c01a027e5081793349cecda2b74d1e5d7cf7bccf2391c0	7b64dd49-04e2-4afe-86bb-2fa6c2d17816	\N	\N	2025-12-13 11:36:24.543549	\N
b29cb942-4a83-4d5e-874a-142416570fb4	commercial-water-bills/b3ee96ee-30fd-42ac-8e8d-691ee2953327	local	commercial-water-bill	documents	application/pdf	304514	f0ae7845b4a37729e9c01a027e5081793349cecda2b74d1e5d7cf7bccf2391c0	7b64dd49-04e2-4afe-86bb-2fa6c2d17816	\N	\N	2025-12-13 11:36:31.187943	\N
33137be6-e273-4252-9614-af2347a9f57c	property-photos/2cbb1f92-8a33-43e8-8141-5442c09c8796	local	property-photo	photos	application/pdf	304514	f0ae7845b4a37729e9c01a027e5081793349cecda2b74d1e5d7cf7bccf2391c0	7b64dd49-04e2-4afe-86bb-2fa6c2d17816	\N	\N	2025-12-13 11:36:42.743953	\N
5e1c3e7d-21bb-413f-88e0-90b71ed08270	property-photos/7a2fada3-1d12-4e2d-8cda-090557cc93e6	local	property-photo	photos	application/pdf	304514	f0ae7845b4a37729e9c01a027e5081793349cecda2b74d1e5d7cf7bccf2391c0	7b64dd49-04e2-4afe-86bb-2fa6c2d17816	\N	\N	2025-12-13 11:36:52.864145	\N
ca09fd89-f3c7-4c78-a5cd-32bfa917d019	revenue-paperss/013e11ad-845b-447d-885c-926f3067f4cc	local	revenue-papers	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	\N	\N	2025-12-17 06:48:24.609308	\N
7f1defa8-f8a6-4e79-a1d6-ef5a88c9885b	affidavit-section29s/565ef2ce-ca03-4edc-8454-d90d78e3e9d1	local	affidavit-section29	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	\N	\N	2025-12-17 06:48:29.574726	\N
2db158c5-e3bf-4849-a4e0-46e9896b08c9	undertaking-form-cs/9a6b2fc0-eb31-44cf-9e4f-e4935d4ef03d	local	undertaking-form-c	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	\N	\N	2025-12-17 06:48:36.372838	\N
b805f3f2-13b1-45fe-a996-1177518d8f1e	commercial-electricity-bills/02f0fb1f-f89b-46ef-ad4a-6ba1c58b38df	local	commercial-electricity-bill	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	\N	\N	2025-12-17 06:48:40.511434	\N
8b3a25f4-0fb6-4565-9dc1-dabed74937c6	commercial-water-bills/8667a2d6-ce4d-4f57-8cc6-fbae38534505	local	commercial-water-bill	documents	application/pdf	61398	f24b77cf89cfbf9bd0ff84929c0f12e3575b4cef18561eb1f18cb735ec63c58b	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	\N	\N	2025-12-17 06:48:44.438392	\N
da27928d-ed2e-433c-b25a-65bbb92400db	property-photos/9e3a5565-8184-4c45-b3d6-08154794dfc8	local	property-photo	photos	image/jpeg	96524	02f226a52cfa9b5054adcfe008a6b8885b9a5f56adc2d53ad3382d9502cbd6dd	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	\N	\N	2025-12-17 06:48:51.344987	\N
6c275cd9-428e-40b0-b6d1-b2a6d7a5cd9d	property-photos/b8043eca-7018-41fb-844c-92cb7838cdc2	local	property-photo	photos	image/jpeg	13584	12434b6deb0704e02e9f467b990ca3498923894c9c205a1ab3acff0f3eb8a846	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	\N	\N	2025-12-17 06:48:51.453896	\N
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_settings (id, setting_key, setting_value, description, category, updated_by, created_at, updated_at) FROM stdin;
ff98916f-d942-44c7-a11f-1a9d9ab1a34b	comm_sms_gateway	{"nic": {"postUrl": "https://msdgweb.mgov.gov.in/esms/sendsmsrequestDLT", "password": "Tour@sml352", "senderId": "hpgovt", "username": "hpgovt-TACA", "templateId": "1007739248479536901", "departmentKey": "a63f7853-6297-44c7-820b-392541a47fc1"}, "provider": "nic"}	SMS gateway configuration	communications	9def5322-010c-43a4-9712-10977499b1da	2025-12-11 20:18:31.087509	2025-12-11 20:18:31.087509
0917cbdc-ec1a-4eab-825c-9edbe7ab1f46	comm_email_gateway	{"custom": {"host": "mail.smtp2go.com", "port": 2525, "password": "osipl@2025", "username": "osipl.dev", "fromEmail": "hptourism@osipl.dev"}, "provider": "custom"}	Email gateway configuration	communications	9def5322-010c-43a4-9712-10977499b1da	2025-12-11 20:18:52.906864	2025-12-11 20:18:52.906864
d15a5f03-9be2-4006-8830-c0aa5324b19e	auth_captcha_enabled	{"enabled": false}	Toggle captcha requirement	auth	9def5322-010c-43a4-9712-10977499b1da	2025-12-13 02:02:37.005108	2025-12-13 02:02:37.005108
724eabea-395e-4a59-ac3e-02423d187944	admin_super_console_enabled	{"enabled": true}	Enable/disable super console	admin	9def5322-010c-43a4-9712-10977499b1da	2025-12-11 20:10:31.766081	2025-12-14 18:09:34.173
cad7c7ff-deec-4ea8-a40f-0ab7bf501757	payment_test_mode	{"enabled": true}	When enabled, payment requests send ₹1 to gateway instead of actual amount (for testing)	payment	9def5322-010c-43a4-9712-10977499b1da	2025-12-14 18:42:23.259102	2025-12-14 18:42:23.259102
94a8eb4b-2374-4a9a-a87d-98e81f066230	payment_workflow	{"workflow": "upfront", "upfrontSubmitMode": "auto"}	Payment workflow: 'upfront' = pay before submission, 'on_approval' = pay after approval	payment	9def5322-010c-43a4-9712-10977499b1da	2025-12-12 02:48:22.295042	2025-12-14 18:44:15.351
4beb436b-de6b-4ae5-ae20-a358b31768eb	multi_service_hub_enabled	{"enabled": true}	\N	general	9def5322-010c-43a4-9712-10977499b1da	2025-12-14 18:59:04.0206	2025-12-14 19:12:20.239
63888f6d-f607-4790-b627-67435ba4b756	backup_configuration	{"enabled": true, "schedule": "0 2 * * *", "includeFiles": true, "lastBackupAt": "2025-12-16T20:30:00.041Z", "retentionDays": 30, "backupDirectory": "/home/subhash.thakur.india/Projects/hptourism-rc5dev/backups", "includeDatabase": true, "lastBackupStatus": "success"}	\N	general	\N	2025-12-11 20:30:01.849248	2025-12-16 20:30:02.347
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_profiles (id, user_id, full_name, gender, aadhaar_number, mobile, email, district, tehsil, block, gram_panchayat, urban_body, ward, address, pincode, telephone, fax, created_at, updated_at) FROM stdin;
3ed80222-2c3b-4654-8e1e-3a0ced60291a	3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	Test AAAA	male	666666666671	8091441005	test@test.com			\N							\N	2025-12-11 20:02:09.522613	2025-12-11 20:07:33.316
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, mobile, full_name, first_name, last_name, username, email, alternate_phone, designation, department, employee_id, office_address, office_phone, role, aadhaar_number, district, password, is_active, created_at, updated_at, sso_id) FROM stdin;
7454e60f-eae5-4b7c-9f7e-5860b037cb4c	9999999999	Admin Admin	Admin	Admin	admin	\N	\N	\N	\N	\N	\N	\N	admin	\N	\N	$2b$10$3Oc9unjl6Ht7mzXr7cazkO36gyOBiqg6yxJEYi88YYqQPIB13Pf9S	t	2025-12-11 10:57:28.118588	2025-12-11 10:57:28.118588	\N
9def5322-010c-43a4-9712-10977499b1da	9999999998	Super Admin	Super	Admin	superadmin	superadmin@himachaltourism.gov.in	\N	\N	\N	\N	\N	\N	super_admin	\N	\N	$2b$10$RahzsVePrPgYeTfb3.giXOLQf8CC5ndpcJVAYvS2UPiIGmFLmpz52	t	2025-12-11 10:57:28.226419	2025-12-11 10:57:28.226419	\N
ce14f7d4-6232-4185-bacf-600afbf5aa7a	7900001001	DTDO Chamba	DTDO	Chamba	dtdo_chamba	dtdo.chamba@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Chamba HQ	$2b$10$RdrhSA7xtmRL/WaX5cokjeF.cwFaQ4rD6rX19f5yk9fT2Q66oSFBW	t	2025-12-11 10:57:28.356315	2025-12-11 10:57:28.356315	\N
7d133c62-f506-45a9-b6f7-88897210ccb5	7800001002	DA Bharmour	DA	Bharmour	da_bharmour	da.bharmour@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Bharmour Sub-Division	$2b$10$C4qDd1q75FgXpRXVWU5dzO0sbwVa1LSCkaWcNqkV.51tYWE4JG3by	t	2025-12-11 10:57:28.420115	2025-12-11 10:57:28.420115	\N
f887aa41-650c-478d-aeca-e54c1ade64fe	7900001002	DTDO Bharmour	DTDO	Bharmour	dtdo_bharmour	dtdo.bharmour@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Bharmour Sub-Division	$2b$10$rnVrv7GMkq3O6e4brlXFxuYMA.jLnJsEe75nwiZIXULwBjyReWbyq	t	2025-12-11 10:57:28.484735	2025-12-11 10:57:28.484735	\N
86e9a1bf-b1e6-4009-a796-5230b29a238b	7800001003	DA Shimla Hq	DA	Shimla Hq	da_shimla_hq	da.shimla-hq@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Shimla HQ (AC Tourism)	$2b$10$DpuVq1TzYnyUdzyz3eeYpeIcNXGWLr0dorL9VUk5DdPBTaBV21Fw.	t	2025-12-11 10:57:28.549707	2025-12-11 10:57:28.549707	\N
d9667ab6-056c-4933-9959-5516661b0c43	7900001003	DTDO Shimla Hq	DTDO	Shimla Hq	dtdo_shimla_hq	dtdo.shimla-hq@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Shimla HQ (AC Tourism)	$2b$10$9A10tgzX26vfVBXXKKASqOCT1ZABZQlDJvYKi6Y2VJT23vgxQ1V8.	t	2025-12-11 10:57:28.614474	2025-12-11 10:57:28.614474	\N
e618e427-7635-4319-b33b-b4f7c450bac8	7800001004	DA Hamirpur	DA	Hamirpur	da_hamirpur	da.hamirpur@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Hamirpur (serving Una)	$2b$10$Zzv3fdFLZj5rD8m83SlQ5uhMi/8bPVNJAZFflDTyjzCZuo32rd7Ma	t	2025-12-11 10:57:28.679604	2025-12-11 10:57:28.679604	\N
71a0d808-c635-4212-ac93-bd72b772ef6d	7900001004	DTDO Hamirpur	DTDO	Hamirpur	dtdo_hamirpur	dtdo.hamirpur@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Hamirpur (serving Una)	$2b$10$GL4XjXQHoGoawDtwp61va.Y.XHl7kAbidAaTX3PaxVge/vrM2FiR6	t	2025-12-11 10:57:28.745268	2025-12-11 10:57:28.745268	\N
1e92acf4-d2f8-4dc4-842e-2277be44ea2b	7800001005	DA Kullu Manali	DA	Kullu Manali	da_kullu_manali	da.kullu-manali@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Kullu (Bhuntar/Manali)	$2b$10$wBCdWTXE2g0IIOZWDvaU8er43QK7YaF3r61qWNX55r8ebYNfZ7Sgq	t	2025-12-11 10:57:28.811465	2025-12-11 10:57:28.811465	\N
94a9a69c-38b4-4e83-90bd-7820cc413958	7900001005	DTDO Kullu Manali	DTDO	Kullu Manali	dtdo_kullu_manali	dtdo.kullu-manali@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Kullu (Bhuntar/Manali)	$2b$10$SOKVHm9Rso6Ve0W2YYDBM.XYrKmrhPMyOouNDp1SB2OPV2HAI0Er2	t	2025-12-11 10:57:28.880845	2025-12-11 10:57:28.880845	\N
53672c24-b63b-43a8-818d-88c0967eaee2	7800001006	DA Kullu Dhalpur	DA	Kullu Dhalpur	da_kullu_dhalpur	da.kullu-dhalpur@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Kullu Dhalpur	$2b$10$CtBoDNAk4NWKOsDbpnVT8OHZy63L59NwTJCCTFJ/loXstlGTipxy6	t	2025-12-11 10:57:28.946984	2025-12-11 10:57:28.946984	\N
b49484b5-5833-49c9-a238-3b53fb27e6c2	7900001006	DTDO Kullu Dhalpur	DTDO	Kullu Dhalpur	dtdo_kullu_dhalpur	dtdo.kullu-dhalpur@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Kullu Dhalpur	$2b$10$pD6gmwiw69H7vmbum9N5TO5cyLHa7vWwIVMlGWOg9y4f5G/8Nvxre	t	2025-12-11 10:57:29.012314	2025-12-11 10:57:29.012314	\N
77d45a12-3d6f-4985-adf5-6991b154b70d	7800001007	DA Dharamsala	DA	Dharamsala	da_dharamsala	da.dharamsala@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Dharamsala (Kangra)	$2b$10$qhyZkFZbOIhNGORuMMd/yu.7W58GhWc4.Lga7cfACutOuZNO0KUWq	t	2025-12-11 10:57:29.077171	2025-12-11 10:57:29.077171	\N
0713100b-5a61-4bc8-b7f2-941d5ca3d97f	7900001007	DTDO Dharamsala	DTDO	Dharamsala	dtdo_dharamsala	dtdo.dharamsala@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Dharamsala (Kangra)	$2b$10$vnhhi6voNRuBDUnZ6hAw6ej0jxhIMZcUujt4RffwFwY4gw6CIHzqC	t	2025-12-11 10:57:29.142867	2025-12-11 10:57:29.142867	\N
a6496ab6-d7af-40f4-81b2-0018d4ac99e0	7800001008	DA Kinnaur	DA	Kinnaur	da_kinnaur	da.kinnaur@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Kinnaur (Reckong Peo)	$2b$10$uWsSiBM9RJJ.PLK66u58s.WupA0WWPqRQHtRVG0y1Pc3xQT/zukZ6	t	2025-12-11 10:57:29.207842	2025-12-11 10:57:29.207842	\N
32ad65d2-21c8-4a12-ac73-e9230a4ac437	7900001008	DTDO Kinnaur	DTDO	Kinnaur	dtdo_kinnaur	dtdo.kinnaur@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Kinnaur (Reckong Peo)	$2b$10$OeBlbbHb0AsgqPLh2fbiTes0ASFc0Cp.iDLQPRae0SQ.zaerUr0Xu	t	2025-12-11 10:57:29.272639	2025-12-11 10:57:29.272639	\N
1779be4e-4dfd-4e3d-b735-0f8f79c13a7b	7800001009	DA Kaza	DA	Kaza	da_kaza	da.kaza@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Kaza (Spiti ITDP)	$2b$10$YveBOS2WYvDzGB1R7UFhKeBuwjmhEVd9fVK7dWcMsWFj04Ry/sJwq	t	2025-12-11 10:57:29.338431	2025-12-11 10:57:29.338431	\N
323109fd-0f71-4440-ace7-e72c58083f17	7900001009	DTDO Kaza	DTDO	Kaza	dtdo_kaza	dtdo.kaza@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Kaza (Spiti ITDP)	$2b$10$oron8HIIxbMOO5B6EdwPYuGYB2aqsq/uEGnWupgD9nQ1h.LBDx3Ku	t	2025-12-11 10:57:29.40419	2025-12-11 10:57:29.40419	\N
cc9dee09-fa3f-450a-9b7a-57422aee9654	7800001010	DA Lahaul	DA	Lahaul	da_lahaul	da.lahaul@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Lahaul (Keylong)	$2b$10$KjlCMI75I2timCeK.YNQxeAWr3zEHiDyTaJuveUmMFfowG5hQOSlm	t	2025-12-11 10:57:29.469047	2025-12-11 10:57:29.469047	\N
ff06075b-a496-4556-8899-d0f855595cd8	7900001010	DTDO Lahaul	DTDO	Lahaul	dtdo_lahaul	dtdo.lahaul@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Lahaul (Keylong)	$2b$10$CfL35I.nAX2Djjp/Af5VCuwhdLvvglwos8k9G6g9Em6SZE/tKAB/y	t	2025-12-11 10:57:29.533531	2025-12-11 10:57:29.533531	\N
ec07c1a6-5120-4947-ae02-de9c93012613	7800001011	DA Mandi	DA	Mandi	da_mandi	da.mandi@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Mandi Division	$2b$10$nhcvHvkaohpcbspYjN6VDehlmYUQgsrSc1E.E6jqq3KIWwGCkhjaC	t	2025-12-11 10:57:29.598946	2025-12-11 10:57:29.598946	\N
813c56af-d7e8-47af-a014-43817214b853	7900001011	DTDO Mandi	DTDO	Mandi	dtdo_mandi	dtdo.mandi@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Mandi Division	$2b$10$Iu57Lvlik3LPSWAtg1pB/uPSHX3dax9lFMwXAHFEdRpDaUshVBjom	t	2025-12-11 10:57:29.663946	2025-12-11 10:57:29.663946	\N
6c101e40-2e70-4c47-adee-bde3b7644710	7800001012	DA Pangi	DA	Pangi	da_pangi	da.pangi@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Pangi (ITDP)	$2b$10$6o1qTN3ZQFuC9XcMKqYYEOqLGTmjJ5OLyZAS7bhQKQWM93gDp30GW	t	2025-12-11 10:57:29.729057	2025-12-11 10:57:29.729057	\N
5e0a634e-a2c9-4836-b738-f23938ef0a19	7900001012	DTDO Pangi	DTDO	Pangi	dtdo_pangi	dtdo.pangi@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Pangi (ITDP)	$2b$10$4JBhuaIOdBShczehYn5gIuAPzj2w9br4L8MlI1vWiIXoS9i7a8I.y	t	2025-12-11 10:57:29.794094	2025-12-11 10:57:29.794094	\N
5dffdaad-0838-4c27-b4ab-b3b8e455f3a1	7800001001	DA Chamba	DA	Chamba	da_chamba	da.chamba@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Chamba HQ	$2b$10$EdAWgs.IKowVdfGI7u.BReoq6IDc5fem3mzykShub197QdwFLGWPG	t	2025-12-11 10:57:28.292761	2025-12-11 10:57:28.292761	\N
486a4663-dcc8-49fb-8c4c-9aeafef4bb97	7800001013	DA Shimla	DA	Shimla	da_shimla	da.shimla@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Shimla Division	$2b$10$TUZaRPcSmUi8J96B/3uOEOUwTvPdMQKliWS2n6g3IRgABAMHpe/cm	t	2025-12-11 10:57:29.858697	2025-12-11 10:57:29.858697	\N
3b2fa85b-806a-44b8-93ce-07ad7aa8a842	7900001013	DTDO Shimla	DTDO	Shimla	dtdo_shimla	dtdo.shimla@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Shimla Division	$2b$10$Js.idd/l4UNdhvNif5WzYe3rEWhEChwx4xropOhAqCUu8R29fzHKC	t	2025-12-11 10:57:29.924036	2025-12-11 10:57:29.924036	\N
cb5552a8-4bb2-4b6f-818b-609aaad2073e	7800001014	DA Sirmaur	DA	Sirmaur	da_sirmaur	da.sirmaur@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Sirmaur (Nahan)	$2b$10$qUBaY8.4jaPZ0CH3zU/DCOST8DST8GsFhr4pfd/L9/bdGKL7VQv4m	t	2025-12-11 10:57:29.990139	2025-12-11 10:57:29.990139	\N
2f56774b-a9e3-4578-badd-9a9c5fa794c2	7900001014	DTDO Sirmaur	DTDO	Sirmaur	dtdo_sirmaur	dtdo.sirmaur@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Sirmaur (Nahan)	$2b$10$lb2/0vjD8wyENCfFBS5zyOtS2ofIIrcl.kuIZ1./Kr9HdpTHNlpla	t	2025-12-11 10:57:30.055262	2025-12-11 10:57:30.055262	\N
7fe7f335-48ac-497f-9043-3ff1f258ae59	7800001015	DA Solan	DA	Solan	da_solan	da.solan@himachaltourism.gov.in	\N	Dealing Assistant	\N	\N	\N	\N	dealing_assistant	\N	Solan Division	$2b$10$vDClsxeefycExBqAAePcBe.C84Y0MkpODdVERKJ8RjTAPZ0wt4Z7q	t	2025-12-11 10:57:30.120711	2025-12-11 10:57:30.120711	\N
287368b2-eb02-475c-9859-f53667a38332	7900001015	DTDO Solan	DTDO	Solan	dtdo_solan	dtdo.solan@himachaltourism.gov.in	\N	District Tourism Development Officer	\N	\N	\N	\N	district_tourism_officer	\N	Solan Division	$2b$10$0hxe0W0bldfJFCIdoJoOLOE1.v6lTBCl8mneYVtUBunJEzBME0Fe2	t	2025-12-11 10:57:30.186022	2025-12-11 10:57:30.186022	\N
3e2499ee-8bf4-4dd8-9fcc-01a1bc075668	8091441005	Test AAAA	Test	AAA	\N	test@test.com	\N	\N	\N	\N	\N	\N	property_owner	666666666671	\N	$2b$10$bahTXJbcrqbaFstcIeRvV.Wk.kl8i.vhbc8Ts76ZZR2Nl10Y9RNSO	t	2025-12-11 19:53:22.617296	2025-12-11 20:07:33.318	\N
19315e09-df3b-4cf6-a068-6b601e289c46	6666666662	Test AAA	Test	AAA	\N	test@test.com	\N	\N	\N	\N	\N	\N	property_owner	666666666672	\N	$2b$10$8kpssTFIati3wnTTGchvOO8zly2AxDPK7pXVXvnEFtVEGQ0BtX13u	t	2025-12-11 21:24:42.316947	2025-12-11 21:24:42.316947	\N
2f7b7a16-ed13-429e-ac57-25763f62fe12	8091444005	Test  PPP	Test 	PPP	\N	microaistudio@gmail.com	\N	\N	\N	\N	\N	\N	property_owner	666666666675	\N	$2b$10$x/D8n28QzziDCRLo2Ch6revuEld57FA6ptjnu7.OBqgQA9tOYgL76	t	2025-12-12 02:57:29.244706	2025-12-12 02:57:29.244706	\N
e52010b9-7546-42a1-882e-4334de63c8ca	6666666681	Test XXX	Test	XXX	\N	microaistudio@gmail.com	\N	\N	\N	\N	\N	\N	property_owner	666666666681	\N	$2b$10$PQdHsBuJ.ldzjRtPlIl3w.kBjqR4bVWx5dkNPNhBWT6Ix05AuK4mi	t	2025-12-12 15:49:44.028924	2025-12-12 15:49:44.028924	\N
62bed697-2b04-4591-a351-82d7611368f9	6666666682	Test HHH	Test	HHH	\N	microaistudio@gmail.com	\N	\N	\N	\N	\N	\N	property_owner	666666666682	\N	$2b$10$kA21UCmTiyVK3FGZH0D8ietDFx.OglY8K1gaPVy4c7z/fHNNBkrTa	t	2025-12-12 19:35:41.350342	2025-12-12 19:35:41.350342	\N
7b64dd49-04e2-4afe-86bb-2fa6c2d17816	8091443005	Subhash Thakur	Subhash	Thakur	\N	subhash.thakur2010@gmail.com	\N	\N	\N	\N	\N	\N	property_owner	666666665682	\N	$2b$10$NS5hRf5BW6HybZDse96iUeXke9EHNae3YJoksyoILt4aDaZ5PB7bu	t	2025-12-13 11:34:38.502593	2025-12-13 11:34:38.502593	\N
e0e74d53-cd5a-4746-a125-8951e18e7764	6666666683	Test  XXX	Test 	XXX	\N	microaistudio@gmail.com	\N	\N	\N	\N	\N	\N	property_owner	666666666683	\N	$2b$10$bkQIrILj6QhuKyCr2JDuw.KDzrqiXnMoWkFQtj1c4dDbP1Hxfcj0q	t	2025-12-14 18:19:13.528312	2025-12-14 18:19:13.528312	\N
\.


--
-- Name: application_actions application_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_actions
    ADD CONSTRAINT application_actions_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: certificates certificates_application_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_application_id_unique UNIQUE (application_id);


--
-- Name: certificates certificates_certificate_number_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_certificate_number_unique UNIQUE (certificate_number);


--
-- Name: certificates certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_pkey PRIMARY KEY (id);


--
-- Name: clarifications clarifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_pkey PRIMARY KEY (id);


--
-- Name: ddo_codes ddo_codes_district_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ddo_codes
    ADD CONSTRAINT ddo_codes_district_unique UNIQUE (district);


--
-- Name: ddo_codes ddo_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ddo_codes
    ADD CONSTRAINT ddo_codes_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: himkosh_transactions himkosh_transactions_app_ref_no_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_app_ref_no_unique UNIQUE (app_ref_no);


--
-- Name: himkosh_transactions himkosh_transactions_ech_txn_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_ech_txn_id_unique UNIQUE (ech_txn_id);


--
-- Name: himkosh_transactions himkosh_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_pkey PRIMARY KEY (id);


--
-- Name: homestay_applications homestay_applications_application_number_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_application_number_unique UNIQUE (application_number);


--
-- Name: homestay_applications homestay_applications_certificate_number_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_certificate_number_unique UNIQUE (certificate_number);


--
-- Name: homestay_applications homestay_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_pkey PRIMARY KEY (id);


--
-- Name: inspection_orders inspection_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_pkey PRIMARY KEY (id);


--
-- Name: inspection_reports inspection_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_pkey PRIMARY KEY (id);


--
-- Name: lgd_blocks lgd_blocks_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_blocks lgd_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_pkey PRIMARY KEY (id);


--
-- Name: lgd_districts lgd_districts_district_name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_districts
    ADD CONSTRAINT lgd_districts_district_name_unique UNIQUE (district_name);


--
-- Name: lgd_districts lgd_districts_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_districts
    ADD CONSTRAINT lgd_districts_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_districts lgd_districts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_districts
    ADD CONSTRAINT lgd_districts_pkey PRIMARY KEY (id);


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_pkey PRIMARY KEY (id);


--
-- Name: lgd_tehsils lgd_tehsils_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_tehsils
    ADD CONSTRAINT lgd_tehsils_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_tehsils lgd_tehsils_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_tehsils
    ADD CONSTRAINT lgd_tehsils_pkey PRIMARY KEY (id);


--
-- Name: lgd_urban_bodies lgd_urban_bodies_lgd_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_urban_bodies
    ADD CONSTRAINT lgd_urban_bodies_lgd_code_unique UNIQUE (lgd_code);


--
-- Name: lgd_urban_bodies lgd_urban_bodies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_urban_bodies
    ADD CONSTRAINT lgd_urban_bodies_pkey PRIMARY KEY (id);


--
-- Name: login_otp_challenges login_otp_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_otp_challenges
    ADD CONSTRAINT login_otp_challenges_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: objections objections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_pkey PRIMARY KEY (id);


--
-- Name: password_reset_challenges password_reset_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_challenges
    ADD CONSTRAINT password_reset_challenges_pkey PRIMARY KEY (id);


--
-- Name: payments payments_gateway_transaction_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_gateway_transaction_id_unique UNIQUE (gateway_transaction_id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: payments payments_receipt_number_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_receipt_number_unique UNIQUE (receipt_number);


--
-- Name: production_stats production_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_stats
    ADD CONSTRAINT production_stats_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: storage_objects storage_objects_object_key_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_object_key_unique UNIQUE (object_key);


--
-- Name: storage_objects storage_objects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_setting_key_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_setting_key_unique UNIQUE (setting_key);


--
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_user_id_unique UNIQUE (user_id);


--
-- Name: users users_aadhaar_number_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_aadhaar_number_unique UNIQUE (aadhaar_number);


--
-- Name: users users_mobile_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_mobile_unique UNIQUE (mobile);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_sso_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_sso_id_key UNIQUE (sso_id);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_session_expire" ON public.session USING btree (expire);


--
-- Name: application_actions application_actions_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_actions
    ADD CONSTRAINT application_actions_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: application_actions application_actions_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.application_actions
    ADD CONSTRAINT application_actions_officer_id_users_id_fk FOREIGN KEY (officer_id) REFERENCES public.users(id);


--
-- Name: audit_logs audit_logs_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: certificates certificates_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: certificates certificates_issued_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_issued_by_users_id_fk FOREIGN KEY (issued_by) REFERENCES public.users(id);


--
-- Name: certificates certificates_renewal_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_renewal_application_id_homestay_applications_id_fk FOREIGN KEY (renewal_application_id) REFERENCES public.homestay_applications(id);


--
-- Name: certificates certificates_revoked_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_revoked_by_users_id_fk FOREIGN KEY (revoked_by) REFERENCES public.users(id);


--
-- Name: clarifications clarifications_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: clarifications clarifications_objection_id_objections_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_objection_id_objections_id_fk FOREIGN KEY (objection_id) REFERENCES public.objections(id) ON DELETE CASCADE;


--
-- Name: clarifications clarifications_reviewed_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_reviewed_by_users_id_fk FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: clarifications clarifications_submitted_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clarifications
    ADD CONSTRAINT clarifications_submitted_by_users_id_fk FOREIGN KEY (submitted_by) REFERENCES public.users(id);


--
-- Name: documents documents_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: documents documents_verified_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_verified_by_users_id_fk FOREIGN KEY (verified_by) REFERENCES public.users(id);


--
-- Name: himkosh_transactions himkosh_transactions_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.himkosh_transactions
    ADD CONSTRAINT himkosh_transactions_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: homestay_applications homestay_applications_da_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_da_id_users_id_fk FOREIGN KEY (da_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_district_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_district_officer_id_users_id_fk FOREIGN KEY (district_officer_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_dtdo_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_dtdo_id_users_id_fk FOREIGN KEY (dtdo_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_site_inspection_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_site_inspection_officer_id_users_id_fk FOREIGN KEY (site_inspection_officer_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_state_officer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_state_officer_id_users_id_fk FOREIGN KEY (state_officer_id) REFERENCES public.users(id);


--
-- Name: homestay_applications homestay_applications_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.homestay_applications
    ADD CONSTRAINT homestay_applications_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: inspection_orders inspection_orders_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: inspection_orders inspection_orders_assigned_to_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_assigned_to_users_id_fk FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: inspection_orders inspection_orders_scheduled_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_orders
    ADD CONSTRAINT inspection_orders_scheduled_by_users_id_fk FOREIGN KEY (scheduled_by) REFERENCES public.users(id);


--
-- Name: inspection_reports inspection_reports_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: inspection_reports inspection_reports_inspection_order_id_inspection_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_inspection_order_id_inspection_orders_id_fk FOREIGN KEY (inspection_order_id) REFERENCES public.inspection_orders(id) ON DELETE CASCADE;


--
-- Name: inspection_reports inspection_reports_submitted_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_reports
    ADD CONSTRAINT inspection_reports_submitted_by_users_id_fk FOREIGN KEY (submitted_by) REFERENCES public.users(id);


--
-- Name: lgd_blocks lgd_blocks_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: lgd_blocks lgd_blocks_tehsil_id_lgd_tehsils_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_blocks
    ADD CONSTRAINT lgd_blocks_tehsil_id_lgd_tehsils_id_fk FOREIGN KEY (tehsil_id) REFERENCES public.lgd_tehsils(id) ON DELETE SET NULL;


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_block_id_lgd_blocks_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_block_id_lgd_blocks_id_fk FOREIGN KEY (block_id) REFERENCES public.lgd_blocks(id) ON DELETE CASCADE;


--
-- Name: lgd_gram_panchayats lgd_gram_panchayats_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_gram_panchayats
    ADD CONSTRAINT lgd_gram_panchayats_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: lgd_tehsils lgd_tehsils_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_tehsils
    ADD CONSTRAINT lgd_tehsils_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: lgd_urban_bodies lgd_urban_bodies_district_id_lgd_districts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lgd_urban_bodies
    ADD CONSTRAINT lgd_urban_bodies_district_id_lgd_districts_id_fk FOREIGN KEY (district_id) REFERENCES public.lgd_districts(id) ON DELETE CASCADE;


--
-- Name: login_otp_challenges login_otp_challenges_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_otp_challenges
    ADD CONSTRAINT login_otp_challenges_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: notifications notifications_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: objections objections_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE CASCADE;


--
-- Name: objections objections_inspection_report_id_inspection_reports_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_inspection_report_id_inspection_reports_id_fk FOREIGN KEY (inspection_report_id) REFERENCES public.inspection_reports(id);


--
-- Name: objections objections_raised_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_raised_by_users_id_fk FOREIGN KEY (raised_by) REFERENCES public.users(id);


--
-- Name: objections objections_resolved_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.objections
    ADD CONSTRAINT objections_resolved_by_users_id_fk FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: password_reset_challenges password_reset_challenges_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_challenges
    ADD CONSTRAINT password_reset_challenges_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payments payments_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: reviews reviews_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id);


--
-- Name: reviews reviews_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: storage_objects storage_objects_application_id_homestay_applications_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_application_id_homestay_applications_id_fk FOREIGN KEY (application_id) REFERENCES public.homestay_applications(id) ON DELETE SET NULL;


--
-- Name: storage_objects storage_objects_document_id_documents_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_document_id_documents_id_fk FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: storage_objects storage_objects_uploaded_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.storage_objects
    ADD CONSTRAINT storage_objects_uploaded_by_users_id_fk FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: system_settings system_settings_updated_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_updated_by_users_id_fk FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: user_profiles user_profiles_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict aQ004uh0CFEh20WZO8iTuHBUUHFi08gwMv3ttIfjCBYDE1g3D6btShD0z4nBM6e

